
#include "header.h"

;


size_t get_num_class(void) {
  return 1;
}

size_t get_num_feature(void) {
  return 8;
}

const char* get_pred_transform(void) {
  return "identity";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_ratio_c(void) {
  return 1.0;
}

float get_global_bias(void) {
  return 0.5;
}

const char* get_threshold_type(void) {
  return "float32";
}

const char* get_leaf_output_type(void) {
  return "float32";
}


static inline float pred_transform(float margin) {
  return margin;
}
float predict(union Entry* data, int pred_margin) {
  float sum = (float)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.19456240535)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24310539663)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1228266954)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.018712650985)) {
              sum += (float)0.066864028573;
            } else {
              sum += (float)0.23987670243;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050498813)) {
              sum += (float)-0.14914286137;
            } else {
              sum += (float)17.027893066;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.53908771276)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.4591155052)) {
              sum += (float)0.593524158;
            } else {
              sum += (float)17.479816437;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.19132985175)) {
              sum += (float)0.6261280179;
            } else {
              sum += (float)24.88732338;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0663852692)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.9923017621)) {
              sum += (float)0.38560503721;
            } else {
              sum += (float)-0.011696308851;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0780823231)) {
              sum += (float)2.5701534748;
            } else {
              sum += (float)0.14137536287;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)79.896713257;
            } else {
              sum += (float)-0.07500000298;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
              sum += (float)2.8277654648;
            } else {
              sum += (float)-0.14936974645;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.14800000191;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)86.393547058;
        } else {
          sum += (float)-0.13333334029;
        }
      }
    }
  } else {
    sum += (float)101.25832367;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14954979718)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.65191912651)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.0798200369)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68993473053)) {
              sum += (float)0.061383008957;
            } else {
              sum += (float)0.37533208728;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
              sum += (float)-0.44779542089;
            } else {
              sum += (float)12.633296967;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.99824893475)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5135872364)) {
              sum += (float)1.0445491076;
            } else {
              sum += (float)-0.18014930189;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.98635458946)) {
              sum += (float)0.76552528143;
            } else {
              sum += (float)-0.012383558787;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.19456240535)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.7693881989)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21444743872)) {
              sum += (float)0.25173076987;
            } else {
              sum += (float)2.2523775101;
            }
          } else {
            sum += (float)85.377113342;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
              sum += (float)0.026101337746;
            } else {
              sum += (float)0.27247488499;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.0192017555)) {
              sum += (float)45.232299805;
            } else {
              sum += (float)0.74094700813;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.10419200361;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)69.114845276;
        } else {
          sum += (float)-0.097777791321;
        }
      }
    }
  } else {
    sum += (float)78.475204468;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0023200512)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4849374294)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.89282774925)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0788956881)) {
              sum += (float)-0.057617999613;
            } else {
              sum += (float)0.60055321455;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1736098528)) {
              sum += (float)5.013012886;
            } else {
              sum += (float)-0.19263842702;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.0382537842)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
              sum += (float)-0.13935537636;
            } else {
              sum += (float)0.07810087502;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.0566852093)) {
              sum += (float)1.9067685604;
            } else {
              sum += (float)-0.14171004295;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21210804582)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21444743872)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24310539663)) {
              sum += (float)0.076165661216;
            } else {
              sum += (float)0.7358596921;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.25209575891)) {
              sum += (float)0.074537798762;
            } else {
              sum += (float)9.3094930649;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2143182755)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1879115105)) {
              sum += (float)-0.14099062979;
            } else {
              sum += (float)4.2948470116;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.10800385475)) {
              sum += (float)-0.13788162172;
            } else {
              sum += (float)0.039030555636;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.073351167142;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)55.291873932;
        } else {
          sum += (float)-0.071703709662;
        }
      }
    }
  } else {
    sum += (float)60.818283081;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7148797512)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7267739773)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.9367890358)) {
              sum += (float)-0.83592987061;
            } else {
              sum += (float)-0.18055707216;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91510391235)) {
              sum += (float)6.7663631439;
            } else {
              sum += (float)-0.2052859813;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87356364727)) {
              sum += (float)-0.18344686925;
            } else {
              sum += (float)1.5098850727;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2978332043)) {
              sum += (float)-0.2004866749;
            } else {
              sum += (float)-0.098058842123;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.254904747)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2572441101)) {
              sum += (float)0.098262868822;
            } else {
              sum += (float)1.5611225367;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.415060997)) {
              sum += (float)0.036228034645;
            } else {
              sum += (float)-0.17902565002;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)61.121505737;
            } else {
              sum += (float)-6.854449749;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.199154377)) {
              sum += (float)2.1866846085;
            } else {
              sum += (float)-0.38676169515;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.051639225334;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)44.23349762;
        } else {
          sum += (float)-0.052582722157;
        }
      }
    }
  } else {
    sum += (float)47.134170532;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15063539147)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18487560749)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.055341646075)) {
              sum += (float)0.0059806243517;
            } else {
              sum += (float)0.1133043468;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1831253022)) {
              sum += (float)2.3996407986;
            } else {
              sum += (float)0.26322162151;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20021480322)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.9783551693)) {
              sum += (float)0.13432765007;
            } else {
              sum += (float)-0.12390954792;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20196935534)) {
              sum += (float)1.1529842615;
            } else {
              sum += (float)0.019454730675;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.78995519876)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
              sum += (float)-0.18750865757;
            } else {
              sum += (float)1.4170171022;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8383939266)) {
              sum += (float)4.3966393471;
            } else {
              sum += (float)0.65823072195;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.95385813713)) {
              sum += (float)-0.24414792657;
            } else {
              sum += (float)0.074405051768;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.620408535)) {
              sum += (float)54.358551025;
            } else {
              sum += (float)-0.29332196712;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.036354012787;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)35.386798859;
        } else {
          sum += (float)-0.038560658693;
        }
      }
    }
  } else {
    sum += (float)36.52898407;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2241075039)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4759800434)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4794890881)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.482147336)) {
              sum += (float)0.1528916657;
            } else {
              sum += (float)-0.17235440016;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
              sum += (float)1.8680318594;
            } else {
              sum += (float)-0.23585805297;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7148797512)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7297475338)) {
              sum += (float)-0.20349153876;
            } else {
              sum += (float)1.4792865515;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
              sum += (float)-0.1400155127;
            } else {
              sum += (float)-0.22769376636;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.83090376854)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11087074876)) {
              sum += (float)0.11308745295;
            } else {
              sum += (float)-0.092728957534;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.7879879475)) {
              sum += (float)-0.0082907639444;
            } else {
              sum += (float)0.094229258597;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)51.95035553;
            } else {
              sum += (float)-5.8292007446;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.54937326908)) {
              sum += (float)1.5765007734;
            } else {
              sum += (float)-0.41457056999;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        sum += (float)-0.02559322305;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
          sum += (float)28.309434891;
        } else {
          sum += (float)-0.028277816251;
        }
      }
    }
  } else {
    sum += (float)28.309955597;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.37554126978)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.37217026949)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.15549695492)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1105390787)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.14764100313)) {
              sum += (float)-0.010566824116;
            } else {
              sum += (float)0.20734857023;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
              sum += (float)-0.34097236395;
            } else {
              sum += (float)9.5107545853;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.63375717402)) {
            sum += (float)72.487220764;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.90227949619)) {
              sum += (float)5.0495262146;
            } else {
              sum += (float)0.18965645134;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41681280732)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1105390787)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.44371068478)) {
              sum += (float)0.12800328434;
            } else {
              sum += (float)-0.11151171476;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1351143122)) {
              sum += (float)3.0937604904;
            } else {
              sum += (float)-0.13731648028;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20392009616)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2413508594)) {
              sum += (float)-0.15179538727;
            } else {
              sum += (float)-0.46028375626;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2637062073)) {
              sum += (float)-0.056525863707;
            } else {
              sum += (float)0.27360382676;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38148838282)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.52391171455)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24076594412)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30334544182)) {
              sum += (float)0.44048509002;
            } else {
              sum += (float)-0.24394863844;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051774010062)) {
              sum += (float)2.6200773716;
            } else {
              sum += (float)-0.6004755497;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
            sum += (float)150.81723022;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21093834937)) {
              sum += (float)-0.49020129442;
            } else {
              sum += (float)-0.10904403031;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.8253031373)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
              sum += (float)-0.17874655128;
            } else {
              sum += (float)0.8435947299;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.76610517502)) {
              sum += (float)28.226421356;
            } else {
              sum += (float)-0.2016017437;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.62594938278)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18929874897)) {
              sum += (float)-0.27541923523;
            } else {
              sum += (float)-0.1282517463;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72151684761)) {
              sum += (float)1.8635492325;
            } else {
              sum += (float)0.034536615014;
            }
          }
        }
      }
    }
  } else {
    sum += (float)21.940216064;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.99824893475)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1105390787)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75055044889)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2524504662)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1626694202)) {
              sum += (float)-0.031033456326;
            } else {
              sum += (float)-0.18752273917;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.8316681385)) {
              sum += (float)3.9632618427;
            } else {
              sum += (float)0.053350608796;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0018820763)) {
              sum += (float)-0.1412345022;
            } else {
              sum += (float)-2.4746789932;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0780200958)) {
              sum += (float)14.582352638;
            } else {
              sum += (float)-0.19575087726;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050498813)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4894822836)) {
              sum += (float)0.097177319229;
            } else {
              sum += (float)0.15213747323;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1721006632)) {
              sum += (float)-6.0279984474;
            } else {
              sum += (float)-0.21041317284;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            sum += (float)-4.451089859;
          } else {
            sum += (float)14.015221596;
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9672087431)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5948765278)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6288356781)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.99533116817)) {
              sum += (float)-0.16804052889;
            } else {
              sum += (float)-1.1108722687;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1648370028)) {
              sum += (float)4.97245121;
            } else {
              sum += (float)-0.15329372883;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67156821489)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.80666935444)) {
              sum += (float)-0.048154566437;
            } else {
              sum += (float)-0.31703323126;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63125658035)) {
              sum += (float)3.9767279625;
            } else {
              sum += (float)-0.036792062223;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0023747683)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20684435964)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5695059299)) {
              sum += (float)-0.040533494204;
            } else {
              sum += (float)-0.15486299992;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.19631695747)) {
              sum += (float)0.8780900836;
            } else {
              sum += (float)-0.018415879458;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.83767598867)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.95429623127)) {
              sum += (float)1.3268444538;
            } else {
              sum += (float)0.12358818203;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.78869622946)) {
              sum += (float)-0.082925714552;
            } else {
              sum += (float)0.023843660951;
            }
          }
        }
      }
    }
  } else {
    sum += (float)17.003664017;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0162498951)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.73856580257)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.15549695492)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.23350065947)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.2194982022)) {
              sum += (float)0.007277960889;
            } else {
              sum += (float)0.78477478027;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.90987169743)) {
              sum += (float)0.79025071859;
            } else {
              sum += (float)-0.083793282509;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.16144409776)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.47305762768)) {
              sum += (float)61.626583099;
            } else {
              sum += (float)-0.9205429554;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21152320504)) {
              sum += (float)0.14982832968;
            } else {
              sum += (float)-0.010947675444;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5123929977)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3992979527)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.074341952801)) {
              sum += (float)0.55839520693;
            } else {
              sum += (float)-0.058420334011;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.6852966547)) {
              sum += (float)-0.20042285323;
            } else {
              sum += (float)2.4675512314;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.5890301466)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.5574367046)) {
              sum += (float)-0.19494709373;
            } else {
              sum += (float)12.334318161;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)4.8899250031)) {
              sum += (float)-0.23370657861;
            } else {
              sum += (float)0.021430563182;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.7850143909)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.64782178402)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.83644485474)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.010951199569)) {
              sum += (float)0.010256110691;
            } else {
              sum += (float)-0.13502827287;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6391904354)) {
              sum += (float)0.0010292404331;
            } else {
              sum += (float)1.2312110662;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7249196768)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2628521919)) {
              sum += (float)-0.18471048772;
            } else {
              sum += (float)-0.018379513174;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
              sum += (float)24.180288315;
            } else {
              sum += (float)-0.015799449757;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9485607147)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9247721434)) {
              sum += (float)-0.29070287943;
            } else {
              sum += (float)17.350618362;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.815325737)) {
              sum += (float)-0.074919551611;
            } else {
              sum += (float)0.70401638746;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3997039795)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.796908617)) {
              sum += (float)1.1957153082;
            } else {
              sum += (float)-0.13854901493;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
              sum += (float)7.5214400291;
            } else {
              sum += (float)-0.036002315581;
            }
          }
        }
      }
    }
  } else {
    sum += (float)13.177840233;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.371781826)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3706121445)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7003444433)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5528931618)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.0657095909)) {
              sum += (float)0.0051242187619;
            } else {
              sum += (float)0.75161910057;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.7160041332)) {
              sum += (float)-0.19343607128;
            } else {
              sum += (float)-0.035707004368;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1537370682)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2703170776)) {
              sum += (float)-0.012951943092;
            } else {
              sum += (float)0.69430655241;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8185088634)) {
              sum += (float)2.6572861671;
            } else {
              sum += (float)-0.13575096428;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.7425043583)) {
            sum += (float)-0.23224422336;
          } else {
            sum += (float)1.8763599396;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3460154533)) {
            sum += (float)8.6792821884;
          } else {
            sum += (float)-0.2909450829;
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.20413661)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.513767004)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.9030900002)) {
              sum += (float)0.077703759074;
            } else {
              sum += (float)4.8149957657;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
              sum += (float)-0.019622717053;
            } else {
              sum += (float)-0.26651293039;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.415060997)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
              sum += (float)-0.18897300959;
            } else {
              sum += (float)9.1847171783;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.1291017532)) {
              sum += (float)-0.26472499967;
            } else {
              sum += (float)-0.1596557945;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.2906588614)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3452409506)) {
              sum += (float)-0.0099744964391;
            } else {
              sum += (float)-1.1461036205;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
              sum += (float)-0.012883725576;
            } else {
              sum += (float)-0.023053385317;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5444312096)) {
            sum += (float)21.131578445;
          } else {
            sum += (float)-0.02670452185;
          }
        }
      }
    }
  } else {
    sum += (float)10.212831497;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4105226994)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.6256725788)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.6435139179)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.4335923195)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
              sum += (float)2.3084104061;
            } else {
              sum += (float)-0.12365853786;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2765552998)) {
              sum += (float)-0.14207294583;
            } else {
              sum += (float)-0.41114297509;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5670104027)) {
            sum += (float)-1.1407337189;
          } else {
            sum += (float)15.558245659;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7640135288)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0779503584)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2765552998)) {
              sum += (float)-0.17525990307;
            } else {
              sum += (float)-0.34406983852;
            }
          } else {
            sum += (float)-1.0432173014;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17272660136)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.9923017621)) {
              sum += (float)-0.1829868257;
            } else {
              sum += (float)-0.11786183715;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.57897531986)) {
              sum += (float)-0.6515699625;
            } else {
              sum += (float)-0.12078204751;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4096474648)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2657215595)) {
          sum += (float)4.3632268906;
        } else {
          sum += (float)-0.088747665286;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0642418861)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2977836132)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0409359932)) {
              sum += (float)-0.052106108516;
            } else {
              sum += (float)-0.24872851372;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.84957027435)) {
              sum += (float)0.018462739885;
            } else {
              sum += (float)0.22916358709;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94200730324)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0355840921)) {
              sum += (float)-0.032154031098;
            } else {
              sum += (float)-0.18180896342;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.89989763498)) {
              sum += (float)0.32507327199;
            } else {
              sum += (float)0.002877160674;
            }
          }
        }
      }
    }
  } else {
    sum += (float)7.9149403572;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67364668846)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.75563287735)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
              sum += (float)-0.018819211051;
            } else {
              sum += (float)0.72129195929;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96868157387)) {
              sum += (float)-0.30556312203;
            } else {
              sum += (float)1.8260720968;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.1401004791)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
              sum += (float)-1.5124714375;
            } else {
              sum += (float)10.086684227;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0020465851)) {
              sum += (float)-0.016098739579;
            } else {
              sum += (float)-0.19026874006;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9524407387)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
            sum += (float)21.768327713;
          } else {
            sum += (float)-0.49772563577;
          }
        } else {
          sum += (float)-0.67958664894;
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.66719245911)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0236456394)) {
          sum += (float)2.7251462936;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26006615162)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.5975997448)) {
              sum += (float)-0.11661210656;
            } else {
              sum += (float)-0.40839058161;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
              sum += (float)1.4390962124;
            } else {
              sum += (float)-0.11835535616;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3800637722)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3841576576)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
              sum += (float)-0.23935610056;
            } else {
              sum += (float)0.26318213344;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1273925304)) {
              sum += (float)-0.31127613783;
            } else {
              sum += (float)3.5922691822;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.92212212086)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.71812438965)) {
              sum += (float)-0.11149512231;
            } else {
              sum += (float)-0.22583277524;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68408608437)) {
              sum += (float)0.16133958101;
            } else {
              sum += (float)0.00068005587673;
            }
          }
        }
      }
    }
  } else {
    sum += (float)6.1340794563;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0013763905)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3284003735)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.61342704296)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.5301669836)) {
              sum += (float)0.0014015806373;
            } else {
              sum += (float)0.19950951636;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1795613766)) {
              sum += (float)-0.08097282052;
            } else {
              sum += (float)0.45885655284;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8606183529)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8582789898)) {
              sum += (float)0.38595885038;
            } else {
              sum += (float)3.7150146961;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1918489933)) {
              sum += (float)-0.19162417948;
            } else {
              sum += (float)1.7975472212;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18132030964)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28256416321)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.6420764923)) {
              sum += (float)-0.20804190636;
            } else {
              sum += (float)0.54936468601;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18520379066)) {
              sum += (float)-0.34918755293;
            } else {
              sum += (float)-0.75631541014;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.091015353799)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.089647904038)) {
              sum += (float)-0.076153770089;
            } else {
              sum += (float)65.492843628;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.5385460854)) {
              sum += (float)-0.04432348907;
            } else {
              sum += (float)2.0145797729;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
          sum += (float)44.149383545;
        } else {
          sum += (float)-4.9632368088;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.56224012375)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2472877502)) {
              sum += (float)5.2484192848;
            } else {
              sum += (float)-1.3473769426;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
              sum += (float)1.1427304745;
            } else {
              sum += (float)-1.1569020748;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.3249573708)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.5092150569)) {
              sum += (float)-0.078478321433;
            } else {
              sum += (float)-1.0340533257;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41279524565)) {
              sum += (float)-0.02308258228;
            } else {
              sum += (float)-0.24439971149;
            }
          }
        }
      }
    }
  } else {
    sum += (float)4.7539081573;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.2164242268)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.306063205)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.58194887638)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0990782976)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
              sum += (float)0.020009040833;
            } else {
              sum += (float)2.155069828;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.84208858013)) {
              sum += (float)29.491603851;
            } else {
              sum += (float)-0.089701376855;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.75563287735)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
              sum += (float)-0.086900308728;
            } else {
              sum += (float)0.13016244769;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730372906)) {
              sum += (float)-0.16075064242;
            } else {
              sum += (float)-0.03783204034;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.08955720067)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5589373112)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18421924114)) {
              sum += (float)-0.028008924797;
            } else {
              sum += (float)0.3143414855;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.20388586819)) {
              sum += (float)52.381076813;
            } else {
              sum += (float)-0.12969762087;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50233614445)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1734175682)) {
              sum += (float)0.11251813918;
            } else {
              sum += (float)3.2764794827;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.33288529515)) {
              sum += (float)-0.17059551179;
            } else {
              sum += (float)-0.002344118664;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.088335894048)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17974489927)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.26377665997)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0841646194)) {
              sum += (float)-0.029059959576;
            } else {
              sum += (float)-0.0010027497774;
            }
          } else {
            sum += (float)-0.03489484638;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.69197010994)) {
            sum += (float)-0.08906275034;
          } else {
            sum += (float)-0.14018270373;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2191557884)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.74114209414)) {
              sum += (float)-0.34067124128;
            } else {
              sum += (float)-0.77603822947;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0521175861)) {
              sum += (float)-1.0918685198;
            } else {
              sum += (float)-0.32184463739;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.5992903709)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.119772315)) {
              sum += (float)-0.28299000859;
            } else {
              sum += (float)-0.21085290611;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.29226458073;
            } else {
              sum += (float)-0.10458166897;
            }
          }
        }
      }
    }
  } else {
    sum += (float)3.684278965;
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15063539147)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18389105797)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.74767094851)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3705714047)) {
              sum += (float)-0.016427308321;
            } else {
              sum += (float)0.076284214854;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.26414820552)) {
              sum += (float)32.736568451;
            } else {
              sum += (float)-0.1513029933;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.8030211926)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.93372160196)) {
              sum += (float)-0.40820169449;
            } else {
              sum += (float)-0.17855660617;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.33370575309)) {
              sum += (float)0.50557237864;
            } else {
              sum += (float)-0.11082448065;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1831253022)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.39672535658)) {
            sum += (float)-0.82477879524;
          } else {
            sum += (float)13.309188843;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.6495796442)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.69402867556)) {
              sum += (float)-0.26234558225;
            } else {
              sum += (float)0.8730481863;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15112765133)) {
              sum += (float)-0.19125139713;
            } else {
              sum += (float)1.4891802073;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12432619929)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.45582771301)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.11762654781)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.89848577976)) {
              sum += (float)-0.29531425238;
            } else {
              sum += (float)-0.12641054392;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50519752502)) {
              sum += (float)-0.48202696443;
            } else {
              sum += (float)-0.2614543736;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18403500319)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.10746614635)) {
              sum += (float)-0.7193826437;
            } else {
              sum += (float)-1.0529260635;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.27560791373)) {
              sum += (float)0.14036458731;
            } else {
              sum += (float)-0.34823226929;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12328694761)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.48511007428)) {
              sum += (float)-0.064970672131;
            } else {
              sum += (float)5.4033637047;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20099580288)) {
              sum += (float)-0.57706397772;
            } else {
              sum += (float)-0.11551980674;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.20902124047)) {
              sum += (float)-0.020176922902;
            } else {
              sum += (float)-0.10429661721;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.68001616001)) {
              sum += (float)1.3234372139;
            } else {
              sum += (float)0.021051779389;
            }
          }
        }
      }
    }
  } else {
    sum += (float)2.8553192616;
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9360260963)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.3833770752)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1448163986)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7104598284)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0556092262)) {
              sum += (float)0.0027390890755;
            } else {
              sum += (float)0.35597169399;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
              sum += (float)0.066016018391;
            } else {
              sum += (float)-0.15311852098;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
              sum += (float)0.40581774712;
            } else {
              sum += (float)17.77703476;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2674307823)) {
              sum += (float)0.44131058455;
            } else {
              sum += (float)-0.2652054131;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.7365572453)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.20413661)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.46749424934)) {
              sum += (float)-0.014437725767;
            } else {
              sum += (float)-0.1943038553;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.415060997)) {
              sum += (float)2.3263118267;
            } else {
              sum += (float)-0.25203964114;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87039124966)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.94401323795)) {
              sum += (float)-0.427641958;
            } else {
              sum += (float)18.430770874;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0801143646)) {
              sum += (float)-0.019728153944;
            } else {
              sum += (float)0.80244904757;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.35202920437)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5716178417)) {
            sum += (float)-0.61906903982;
          } else {
            sum += (float)2.9667775631;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3108546734)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.68479269743)) {
              sum += (float)-0.35758772492;
            } else {
              sum += (float)-0.58900111914;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5600476265)) {
              sum += (float)2.7216861248;
            } else {
              sum += (float)-0.16985526681;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
          sum += (float)73.42086792;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.3797140121)) {
            sum += (float)-8.4136924744;
          } else {
            sum += (float)-0.074152901769;
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
        sum += (float)37.524166107;
      } else {
        sum += (float)-4.2215576172;
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.56224012375)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2472877502)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41681274772)) {
              sum += (float)-0.9700652957;
            } else {
              sum += (float)3.9558229446;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.13960596919)) {
              sum += (float)-0.21600775421;
            } else {
              sum += (float)-1.061650157;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.6739474535)) {
              sum += (float)-0.93028026819;
            } else {
              sum += (float)1.7196115255;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2054443359)) {
              sum += (float)-1.1875902414;
            } else {
              sum += (float)-0.61340653896;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.199154377)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.5092150569)) {
              sum += (float)-0.040757462382;
            } else {
              sum += (float)-0.91421043873;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41279524565)) {
              sum += (float)-0.026573607698;
            } else {
              sum += (float)-0.20890335739;
            }
          }
        } else {
          sum += (float)2.2128708363;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2926151752)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.20633813739)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.47707509995)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1043952703)) {
              sum += (float)0.010213537142;
            } else {
              sum += (float)0.79027187824;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.17016214132)) {
              sum += (float)-0.083307959139;
            } else {
              sum += (float)0.01111749094;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30334544182)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30685460567)) {
              sum += (float)0.055162686855;
            } else {
              sum += (float)1.0800603628;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.27059355378)) {
              sum += (float)-0.1936095804;
            } else {
              sum += (float)0.015582872555;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884688616)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.10495034605)) {
              sum += (float)-0.0028472242411;
            } else {
              sum += (float)0.070065222681;
            }
          } else {
            sum += (float)-1.987401247;
          }
        } else {
          sum += (float)16.337406158;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9524407387)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
          sum += (float)15.666155815;
        } else {
          sum += (float)-0.40906205773;
        }
      } else {
        sum += (float)-0.47659549117;
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.39422810078)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0337355137)) {
        sum += (float)-1.4445523024;
      } else {
        sum += (float)-0.56168425083;
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.688958168)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0541777611)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.3734778166)) {
            sum += (float)-0.33459055424;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2162103653)) {
              sum += (float)0.028386222199;
            } else {
              sum += (float)-0.1635221988;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9100894928)) {
            sum += (float)-0.40169328451;
          } else {
            sum += (float)-0.063029967248;
          }
        }
      } else {
        sum += (float)-0.68899416924;
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.0725882053)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75055044889)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.063987202942)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.0798200369)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0459370613)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.6564587355)) {
              sum += (float)0.072868816555;
            } else {
              sum += (float)-0.12600925565;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0213618279)) {
              sum += (float)2.131064415;
            } else {
              sum += (float)0.059116322547;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4894822836)) {
              sum += (float)-0.16209383309;
            } else {
              sum += (float)-0.11290824413;
            }
          } else {
            sum += (float)-4.6323862076;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.73028969765)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3408350945)) {
            sum += (float)-3.1234228611;
          } else {
            sum += (float)-0.13568693399;
          }
        } else {
          sum += (float)7.013068676;
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5176045895)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.44663494825)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.81099963188)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.9233710766)) {
              sum += (float)-0.1437022835;
            } else {
              sum += (float)0.022685017437;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.3461568356)) {
              sum += (float)-0.41578614712;
            } else {
              sum += (float)-0.82608753443;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70591783524)) {
            sum += (float)-0.53437381983;
          } else {
            sum += (float)7.5750174522;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0018820763)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7594833374)) {
              sum += (float)-0.058412555605;
            } else {
              sum += (float)-0.14228969812;
            }
          } else {
            sum += (float)-1.919986248;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0780200958)) {
            sum += (float)10.719254494;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1838583946)) {
              sum += (float)-0.51117300987;
            } else {
              sum += (float)-0.071950793266;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.83864915371)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84668409824)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3991457224)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2916893959)) {
              sum += (float)-0.0015590459807;
            } else {
              sum += (float)-0.17793653905;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1736098528)) {
              sum += (float)1.9925471544;
            } else {
              sum += (float)-0.1482590735;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67156821489)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.68294513226)) {
              sum += (float)-0.088226549327;
            } else {
              sum += (float)-0.45163300633;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.66494989395)) {
              sum += (float)1.9112644196;
            } else {
              sum += (float)0.054227691144;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.41082829237)) {
          sum += (float)-0.21252673864;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
            sum += (float)-0.22792685032;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
              sum += (float)5.0313358307;
            } else {
              sum += (float)-0.18930631876;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3794789314)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3841576576)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4426431656)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4537554979)) {
              sum += (float)0.056954454631;
            } else {
              sum += (float)1.0845733881;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3905911446)) {
              sum += (float)-0.27887052298;
            } else {
              sum += (float)0.4607283771;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1273925304)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.66991460323)) {
              sum += (float)-0.22558993101;
            } else {
              sum += (float)-0.05658608675;
            }
          } else {
            sum += (float)2.5285482407;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.135594368)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75897371769)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0775829554)) {
              sum += (float)-0.041668325663;
            } else {
              sum += (float)-0.22636111081;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75323057175)) {
              sum += (float)0.70128375292;
            } else {
              sum += (float)-0.18235604465;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1338397264)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81257677078)) {
              sum += (float)-0.29384821653;
            } else {
              sum += (float)1.4757860899;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2819730043)) {
              sum += (float)0.15513139963;
            } else {
              sum += (float)-0.0042177950963;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2739112377)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.029404900968)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.4335923195)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
          sum += (float)1.8350814581;
        } else {
          sum += (float)-0.1068348363;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1761181355)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.6795990467)) {
              sum += (float)-0.03654621169;
            } else {
              sum += (float)-0.084841690958;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2917506695)) {
              sum += (float)-0.16976591945;
            } else {
              sum += (float)-0.11897926778;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1520131826)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0092118979)) {
              sum += (float)-0.39187481999;
            } else {
              sum += (float)-0.099758386612;
            }
          } else {
            sum += (float)-0.19851674139;
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4131499529)) {
        sum += (float)-2.3035244942;
      } else {
        sum += (float)-0.20048420131;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.097797751427)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.097250804305)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.089647904038)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.61342704296)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.52421987057)) {
              sum += (float)0.0069289677776;
            } else {
              sum += (float)0.16799890995;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72151684761)) {
              sum += (float)0.39283296466;
            } else {
              sum += (float)-0.06458248198;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.665127039)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.09156230092)) {
              sum += (float)-0.36695030332;
            } else {
              sum += (float)-0.14252457023;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7342915535)) {
              sum += (float)74.666763306;
            } else {
              sum += (float)-7.0797667503;
            }
          }
        }
      } else {
        sum += (float)34.008338928;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.38063514233)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.37522774935)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47897458076)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.91077333689)) {
              sum += (float)-0.30981463194;
            } else {
              sum += (float)-0.13094173372;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.91796243191)) {
              sum += (float)2.7346212864;
            } else {
              sum += (float)0.39627411962;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0856707096)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0556092262)) {
              sum += (float)-0.089972577989;
            } else {
              sum += (float)1.5205398798;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.10647089779)) {
              sum += (float)-0.31941688061;
            } else {
              sum += (float)-0.15211543441;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.38151031733)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.21995586157)) {
            sum += (float)-0.1926484257;
          } else {
            sum += (float)11.224664688;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.23998805881)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.90987169743)) {
              sum += (float)1.6468344927;
            } else {
              sum += (float)-0.10829103738;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.89282774925)) {
              sum += (float)4.4596323967;
            } else {
              sum += (float)0.020052650943;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.253287077)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9360260963)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5988488197)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5383296013)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4951019287)) {
              sum += (float)0.00030146708013;
            } else {
              sum += (float)-4.7428050041;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4026768208)) {
              sum += (float)3.6243462563;
            } else {
              sum += (float)-0.17734260857;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7003444433)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11218350381)) {
              sum += (float)0.026249146089;
            } else {
              sum += (float)-0.17915247381;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9927957058)) {
              sum += (float)-0.82049077749;
            } else {
              sum += (float)-0.26042580605;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.35202920437)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5716178417)) {
              sum += (float)-0.4509974122;
            } else {
              sum += (float)2.311226368;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3108546734)) {
              sum += (float)-0.33060908318;
            } else {
              sum += (float)-0.05674656108;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
            sum += (float)62.403022766;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.3797140121)) {
              sum += (float)-7.1563515663;
            } else {
              sum += (float)-0.055950693786;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
          sum += (float)31.890825272;
        } else {
          sum += (float)-3.5930364132;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.56224012375)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2472877502)) {
              sum += (float)2.6467530727;
            } else {
              sum += (float)-0.74264127016;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
              sum += (float)0.60184431076;
            } else {
              sum += (float)-0.58950412273;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.3249573708)) {
              sum += (float)-0.41600641608;
            } else {
              sum += (float)-0.062100704759;
            }
          } else {
            sum += (float)1.7079071999;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9872171879)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.5789089203)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.4473019838)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
              sum += (float)-0.045742873102;
            } else {
              sum += (float)-0.11726364493;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.4114995003)) {
              sum += (float)-0.210592255;
            } else {
              sum += (float)-0.45157590508;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)3.7585196495)) {
            sum += (float)-0.55768883228;
          } else {
            sum += (float)-0.079827308655;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606681347)) {
            sum += (float)-0.90877217054;
          } else {
            sum += (float)-0.22374360263;
          }
        } else {
          sum += (float)-3.0761671066;
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.2655746937)) {
        sum += (float)-0.45132407546;
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.09621155262)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.7730731964)) {
            sum += (float)-0.13919357955;
          } else {
            sum += (float)-0.23813001812;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.9257378578)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.18151204288;
            } else {
              sum += (float)-0.11020184308;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2962539196)) {
              sum += (float)-0.074471600354;
            } else {
              sum += (float)-0.16405238211;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.306063205)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25335603952)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28305643797)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.56536054611)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.76889014244)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.77005982399)) {
              sum += (float)0.00020041098469;
            } else {
              sum += (float)0.6961145997;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1228266954)) {
              sum += (float)-0.18743997812;
            } else {
              sum += (float)-0.66055434942;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.56360602379)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260761976)) {
              sum += (float)-0.30750918388;
            } else {
              sum += (float)5.9615917206;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.4168073535)) {
              sum += (float)0.20182366669;
            } else {
              sum += (float)-0.032638262957;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28092330694)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.02109348774)) {
            sum += (float)0.99831020832;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60865819454)) {
              sum += (float)-0.16560946405;
            } else {
              sum += (float)0.85466969013;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.35071873665)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.033580549061)) {
              sum += (float)0.075222663581;
            } else {
              sum += (float)2.2441968918;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.70690727234)) {
              sum += (float)-0.081963270903;
            } else {
              sum += (float)-0.20474672318;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1127524376)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.35520145297)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.020381852984)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
              sum += (float)-0.2573479116;
            } else {
              sum += (float)-0.12826170027;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.89417386055)) {
              sum += (float)1.9532148838;
            } else {
              sum += (float)0.025021513924;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.36748337746)) {
            sum += (float)1.2144048214;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.046492550522)) {
              sum += (float)0.20125545561;
            } else {
              sum += (float)-0.15027174354;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0548100471)) {
          sum += (float)23.265962601;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.144203186)) {
            sum += (float)-0.47889614105;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18052589893)) {
              sum += (float)-0.23098821938;
            } else {
              sum += (float)-0.08326920867;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68467092514)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.15970164537)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.98766297102)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.107375145)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1503818035)) {
              sum += (float)0.012509298511;
            } else {
              sum += (float)6.3743777275;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.30540668964)) {
              sum += (float)-0.14017166197;
            } else {
              sum += (float)-0.29625925422;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050498813)) {
              sum += (float)-0.023107090965;
            } else {
              sum += (float)-1.698928237;
            }
          } else {
            sum += (float)5.0473842621;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.15375450253)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.69695293903)) {
            sum += (float)-0.16414567828;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.40094009042)) {
              sum += (float)6.6612071991;
            } else {
              sum += (float)-0.44108733535;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.078379496932)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418975949)) {
              sum += (float)0.75026410818;
            } else {
              sum += (float)-0.050427399576;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
              sum += (float)8.493393898;
            } else {
              sum += (float)-0.64835953712;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60747015476)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.43002104759)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.60357356071)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.62384605408)) {
              sum += (float)-0.15503334999;
            } else {
              sum += (float)-0.017042148858;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60226726532)) {
              sum += (float)2.2328622341;
            } else {
              sum += (float)0.00077968172263;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.1052974463)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52848124504)) {
              sum += (float)-0.27872174978;
            } else {
              sum += (float)-0.089029237628;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.52247738838)) {
              sum += (float)-0.36622661352;
            } else {
              sum += (float)-0.23745642602;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.58758503199)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.071345902979)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.19367074966)) {
              sum += (float)0.53051626682;
            } else {
              sum += (float)-0.19023197889;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.009645299986)) {
              sum += (float)3.9760410786;
            } else {
              sum += (float)1.1222791672;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32907903194)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.54547548294)) {
              sum += (float)0.020424436778;
            } else {
              sum += (float)-0.13302472234;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.3279093504)) {
              sum += (float)1.2965762615;
            } else {
              sum += (float)0.010087452829;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.96606761217)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.46301090717)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.47061401606)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60747015476)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77603924274)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78057909012)) {
              sum += (float)-0.018183642998;
            } else {
              sum += (float)1.980292201;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.39251890779)) {
              sum += (float)-0.14751818776;
            } else {
              sum += (float)0.02863988094;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.55468392372)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0060936213)) {
              sum += (float)-0.22829918563;
            } else {
              sum += (float)18.612771988;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.44348233938)) {
              sum += (float)0.90629076958;
            } else {
              sum += (float)-0.25917109847;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.33646300435)) {
          sum += (float)5.2174344063;
        } else {
          sum += (float)-0.33021140099;
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12421679497)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.59789156914)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.61927801371)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.25070852041)) {
              sum += (float)-0.22857354581;
            } else {
              sum += (float)0.037305340171;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.51355683804)) {
              sum += (float)1.9238086939;
            } else {
              sum += (float)-0.053894560784;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.3487790823)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.54813915491)) {
              sum += (float)-0.37738344073;
            } else {
              sum += (float)-0.1301484108;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.44988054037)) {
              sum += (float)-1.1091789007;
            } else {
              sum += (float)-0.41475537419;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12202890217)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051774010062)) {
            sum += (float)3.8005433083;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.49716255069)) {
              sum += (float)-0.0086298482493;
            } else {
              sum += (float)-0.4151455462;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2004109621)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20859894156)) {
              sum += (float)-0.28432962298;
            } else {
              sum += (float)-3.4807467461;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.99064284563)) {
              sum += (float)-0.097824640572;
            } else {
              sum += (float)0.099862381816;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.254904747)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.97177219391)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84605115652)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4257395267)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0488671064)) {
              sum += (float)-0.075687766075;
            } else {
              sum += (float)0.37941271067;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0237065554)) {
              sum += (float)-0.076700203121;
            } else {
              sum += (float)-0.24567261338;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3689515591)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3841576576)) {
              sum += (float)0.26594501734;
            } else {
              sum += (float)1.106400013;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.193652153)) {
              sum += (float)-0.20262679458;
            } else {
              sum += (float)0.25559690595;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.88531649113)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1010907888)) {
            sum += (float)1.9954109192;
          } else {
            sum += (float)-0.1691070497;
          }
        } else {
          sum += (float)-0.24746654928;
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.69613492489)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5778076649)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.039759650826)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.80838942528)) {
              sum += (float)-0.017569791526;
            } else {
              sum += (float)-0.11673001945;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
              sum += (float)1.0589703321;
            } else {
              sum += (float)0.065016917884;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.42083024979)) {
            sum += (float)43.855121613;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4576333761)) {
              sum += (float)2.5072584152;
            } else {
              sum += (float)-0.096550792456;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15008839965)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18389105797)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.10746614635)) {
              sum += (float)0.065951257944;
            } else {
              sum += (float)-0.025839978829;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18241424859)) {
              sum += (float)9.3744153976;
            } else {
              sum += (float)0.13339473307;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.034787449986)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38148838282)) {
              sum += (float)-0.03405335173;
            } else {
              sum += (float)-0.22689472139;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.010884450749)) {
              sum += (float)0.20257379115;
            } else {
              sum += (float)-0.0053553362377;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9446716309)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2828502655)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2678084373)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6346924305)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6285662651)) {
              sum += (float)-0.00059931492433;
            } else {
              sum += (float)37.276851654;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6593060493)) {
              sum += (float)-1.2607693672;
            } else {
              sum += (float)-0.17881338298;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5181523561)) {
            sum += (float)-0.22036446631;
          } else {
            sum += (float)7.3054232597;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.32244950533)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.83090388775)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1881706715)) {
              sum += (float)-0.11154630035;
            } else {
              sum += (float)-0.038501821458;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17331144214)) {
              sum += (float)2.0058064461;
            } else {
              sum += (float)-0.099282629788;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.78789722919)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.7402477264)) {
              sum += (float)-0.17365503311;
            } else {
              sum += (float)0.070185467601;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2962536812)) {
              sum += (float)-0.32263708115;
            } else {
              sum += (float)-0.13198976219;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
          sum += (float)27.106485367;
        } else {
          sum += (float)-3.0547907352;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.56224012375)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2472877502)) {
              sum += (float)1.8864811659;
            } else {
              sum += (float)-0.54278320074;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
              sum += (float)0.44361689687;
            } else {
              sum += (float)-0.41973158717;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.40074282885)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.66303133965)) {
              sum += (float)-0.063933826983;
            } else {
              sum += (float)0.11362551898;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.5680886507)) {
              sum += (float)-0.48999807239;
            } else {
              sum += (float)-0.068642936647;
            }
          }
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.35202920437)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5716178417)) {
            sum += (float)-0.33430990577;
          } else {
            sum += (float)1.7947446108;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.018712650985)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.0068183499388)) {
              sum += (float)-0.11786360294;
            } else {
              sum += (float)2.0734245777;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.52539420128)) {
              sum += (float)-0.41889071465;
            } else {
              sum += (float)-0.14255405962;
            }
          }
        }
      } else {
        sum += (float)1.3225570917;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
        sum += (float)53.041862488;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.3797140121)) {
          sum += (float)-6.0836081505;
        } else {
          sum += (float)-0.048267908394;
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.20633813739)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.11377675086)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.49396544695)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6108994484)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.046696051955)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.60542500019)) {
              sum += (float)0.013952261768;
            } else {
              sum += (float)-0.054059661925;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1166828871)) {
              sum += (float)0.033587846905;
            } else {
              sum += (float)0.82209181786;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6776294708)) {
            sum += (float)31.685321808;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.59358227253)) {
              sum += (float)-0.3869586885;
            } else {
              sum += (float)0.021320447326;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2541341782)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3810100555)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91510391235)) {
              sum += (float)2.3943500519;
            } else {
              sum += (float)-0.39253473282;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4951019287)) {
              sum += (float)-0.099679946899;
            } else {
              sum += (float)-0.82056152821;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2965245247)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5181523561)) {
              sum += (float)-0.15661618114;
            } else {
              sum += (float)5.22914505;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-2.3054175377)) {
              sum += (float)-1.307086587;
            } else {
              sum += (float)-0.061408601701;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26065099239)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.39932984114)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60980951786)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
              sum += (float)0.012805619277;
            } else {
              sum += (float)-0.088080763817;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11847364902)) {
              sum += (float)-0.32675850391;
            } else {
              sum += (float)-0.090907812119;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.18951885402)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.13570314646)) {
              sum += (float)-0.4452367723;
            } else {
              sum += (float)-0.36705559492;
            }
          } else {
            sum += (float)-0.27452552319;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11355090141)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.13843795657)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3106586933)) {
              sum += (float)-0.15471580625;
            } else {
              sum += (float)0.78499269485;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051774010062)) {
              sum += (float)2.6789464951;
            } else {
              sum += (float)-0.29277536273;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.25869420171)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41681274772)) {
              sum += (float)-0.17668002844;
            } else {
              sum += (float)-1.4297735691;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.44610148668)) {
              sum += (float)-0.24467326701;
            } else {
              sum += (float)-0.075169526041;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.61036741734)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.6465896368)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32732450962)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.13486094773)) {
              sum += (float)-0.11593224108;
            } else {
              sum += (float)6.4040455818;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52323031425)) {
              sum += (float)-0.48249143362;
            } else {
              sum += (float)-0.084587775171;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.19986841083)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.057121448219)) {
              sum += (float)-0.10236146301;
            } else {
              sum += (float)0.39120388031;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
              sum += (float)2.4782218933;
            } else {
              sum += (float)0.93365257978;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
          sum += (float)113.81494904;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30334544182)) {
            sum += (float)-8.9360151291;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.58387970924)) {
              sum += (float)-0.12303946912;
            } else {
              sum += (float)0.430357337;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.53437173367)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.025539299473)) {
              sum += (float)-0.09582991153;
            } else {
              sum += (float)0.87028217316;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.17576345801)) {
              sum += (float)-0.64386665821;
            } else {
              sum += (float)4.5689177513;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.68661636114)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.10890164971)) {
              sum += (float)1.2678643465;
            } else {
              sum += (float)0.24943684042;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
              sum += (float)-0.082615405321;
            } else {
              sum += (float)-0.7135130167;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.5301669836)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4323462248)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.20902124047)) {
              sum += (float)-0.0076377317309;
            } else {
              sum += (float)-0.10626343638;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4644532204)) {
              sum += (float)1.0074732304;
            } else {
              sum += (float)-0.032888770103;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.53611409664)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
              sum += (float)3.6132624149;
            } else {
              sum += (float)-0.19953145087;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21152320504)) {
              sum += (float)0.57033634186;
            } else {
              sum += (float)0.0055209994316;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7740701437)) {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7003444433)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.3202571869)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1150808334)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4914550781)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4791674614)) {
              sum += (float)0.0027738958597;
            } else {
              sum += (float)0.63284623623;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2249832153)) {
              sum += (float)-0.10238537937;
            } else {
              sum += (float)0.051050525159;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.067080617)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.37057095766)) {
              sum += (float)0.035164237022;
            } else {
              sum += (float)-0.18576622009;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5181524754)) {
              sum += (float)8.0163192749;
            } else {
              sum += (float)-0.1492061466;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0541777611)) {
              sum += (float)-0.062576584518;
            } else {
              sum += (float)1.4246474504;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.371781826)) {
              sum += (float)3.4809632301;
            } else {
              sum += (float)-0.15186925232;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
            sum += (float)45.084751129;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.3797140121)) {
              sum += (float)-5.1718950272;
            } else {
              sum += (float)-0.041855871677;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0774880648)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.56824535131)) {
              sum += (float)1.3900657892;
            } else {
              sum += (float)-0.93043136597;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.4874769449)) {
              sum += (float)-0.18595351279;
            } else {
              sum += (float)-2.8404483795;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7400509119)) {
            sum += (float)-0.52522349358;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.4874769449)) {
              sum += (float)-0.11083906144;
            } else {
              sum += (float)14.274414062;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.90692830086)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8114905357)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0764243603)) {
              sum += (float)-0.19326023757;
            } else {
              sum += (float)-0.54918813705;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8354697227)) {
              sum += (float)0.8034747839;
            } else {
              sum += (float)-0.13770644367;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.96922087669)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1269190311)) {
              sum += (float)0.69138622284;
            } else {
              sum += (float)-0.11305146664;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
              sum += (float)0.16821812093;
            } else {
              sum += (float)2.3760652542;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.5673160553)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57710677385)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.091633051634)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
              sum += (float)0.22745513916;
            } else {
              sum += (float)-0.12983770669;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.5678267479)) {
              sum += (float)-0.066823497415;
            } else {
              sum += (float)3.1516954899;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.181379199)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
              sum += (float)-0.11377750337;
            } else {
              sum += (float)0.077393189073;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.2225680351)) {
              sum += (float)-1.2207660675;
            } else {
              sum += (float)-0.13105371594;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.25589895248)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.26283535361)) {
            sum += (float)-0.17747281492;
          } else {
            sum += (float)-1.0212382078;
          }
        } else {
          sum += (float)11.097887993;
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.55541956425)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.6852966547)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.38387328386)) {
              sum += (float)-0.088391169906;
            } else {
              sum += (float)-0.13441561162;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
              sum += (float)-0.00048321814393;
            } else {
              sum += (float)-0.063959762454;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3951759338)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050450385)) {
              sum += (float)-0.39883735776;
            } else {
              sum += (float)-0.53920298815;
            }
          } else {
            sum += (float)-0.36876016855;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5484774113)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.9215214252)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2746958733)) {
              sum += (float)-0.23359833658;
            } else {
              sum += (float)0.16727663577;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.0505414009)) {
              sum += (float)3.7317147255;
            } else {
              sum += (float)-0.13585995138;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.28633415699)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2184436321)) {
              sum += (float)0.18550974131;
            } else {
              sum += (float)0.013574841432;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49161559343)) {
              sum += (float)0.35310667753;
            } else {
              sum += (float)-0.16240845621;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.70560777187)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14954979718)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.111615181)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1127848625)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67156821489)) {
              sum += (float)-0.028062498197;
            } else {
              sum += (float)0.093187578022;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70783221722)) {
              sum += (float)-0.2527115047;
            } else {
              sum += (float)1.4178225994;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.070551753)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40661621094)) {
              sum += (float)-0.17940506339;
            } else {
              sum += (float)-1.3509398699;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1182222366)) {
              sum += (float)-0.054590769112;
            } else {
              sum += (float)0.4496473968;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.88537824154)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.91578966379)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.182929039)) {
              sum += (float)0.66206771135;
            } else {
              sum += (float)-0.26448205113;
            }
          } else {
            sum += (float)4.6474170685;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.62852489948)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.29741764069)) {
              sum += (float)-0.30405664444;
            } else {
              sum += (float)1.7117832899;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.41078990698)) {
              sum += (float)-0.39457789063;
            } else {
              sum += (float)-0.062040816993;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.7817569375)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.35793665051)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
            sum += (float)-0.33532831073;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67003667355)) {
              sum += (float)-0.15500676632;
            } else {
              sum += (float)-0.28344663978;
            }
          }
        } else {
          sum += (float)-0.95376652479;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.35793665051)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
            sum += (float)-0.20447832346;
          } else {
            sum += (float)-0.10498902947;
          }
        } else {
          sum += (float)-0.20715038478;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1741946936)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1923252344)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0127671957)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.94712132215)) {
              sum += (float)-1.0879607201;
            } else {
              sum += (float)-0.2175245285;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.5075621605)) {
              sum += (float)-0.74264162779;
            } else {
              sum += (float)2.0373208523;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.427437067)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4789042473)) {
              sum += (float)-0.12981127203;
            } else {
              sum += (float)-0.577904284;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.2153196335)) {
              sum += (float)0.024236604571;
            } else {
              sum += (float)-0.063600294292;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.84654712677)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2830127478)) {
            sum += (float)2.8646035194;
          } else {
            sum += (float)-0.11149445921;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6115444899)) {
            sum += (float)-0.89247649908;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1879115105)) {
              sum += (float)-0.14451724291;
            } else {
              sum += (float)-0.048135083169;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.5700545311)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.19559618831)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.37177473307)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
              sum += (float)0.016849165782;
            } else {
              sum += (float)-3.128020525;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.57900774479)) {
              sum += (float)2.2746331692;
            } else {
              sum += (float)0.26584085822;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.9738188982)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.080076448619)) {
              sum += (float)2.2874245644;
            } else {
              sum += (float)-0.046417605132;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.1600574553)) {
              sum += (float)-0.053255748004;
            } else {
              sum += (float)0.21036455035;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.69613492489)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5778076649)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57792723179)) {
              sum += (float)-0.06921133399;
            } else {
              sum += (float)-0.14264251292;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.13486096263)) {
              sum += (float)26.932106018;
            } else {
              sum += (float)0.14172269404;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.94149237871)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.92935442924)) {
              sum += (float)-0.20108704269;
            } else {
              sum += (float)-0.029262527823;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.85603350401)) {
              sum += (float)0.37212321162;
            } else {
              sum += (float)0.0066354912706;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7567405701)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3144659996)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2109465599)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5383296013)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4951019287)) {
              sum += (float)4.4935753976e-05;
            } else {
              sum += (float)-1.7554782629;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.51819777489)) {
              sum += (float)2.0099802017;
            } else {
              sum += (float)-0.074523605406;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6178984642)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6722466946)) {
              sum += (float)0.24034924805;
            } else {
              sum += (float)-0.22699196637;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
              sum += (float)-0.64245164394;
            } else {
              sum += (float)4.4351272583;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6696254015)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4407947063)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.3826674819)) {
              sum += (float)-0.10380959511;
            } else {
              sum += (float)-0.20030491054;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.540605545)) {
              sum += (float)-0.040979579091;
            } else {
              sum += (float)0.03755204007;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.8149881363)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.8266443014)) {
              sum += (float)-0.36881890893;
            } else {
              sum += (float)-0.16630318761;
            }
          } else {
            sum += (float)-0.65464901924;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.83941841125)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.2605659962)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.38668495417)) {
              sum += (float)-0.5439760685;
            } else {
              sum += (float)-0.09921836108;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.44516456127)) {
              sum += (float)0.15245836973;
            } else {
              sum += (float)-0.10449798405;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.3795316219)) {
            sum += (float)0.5095153451;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.9072030783)) {
              sum += (float)-0.074190497398;
            } else {
              sum += (float)0.075455628335;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4914550781)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.5628529787)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.61036741734)) {
              sum += (float)-0.29919877648;
            } else {
              sum += (float)-0.049449130893;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6091265678)) {
              sum += (float)0.76750153303;
            } else {
              sum += (float)-0.10085117817;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.5574367046)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.93708097935)) {
              sum += (float)-0.29143282771;
            } else {
              sum += (float)-0.16594845057;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.157037735)) {
              sum += (float)-1.1583696604;
            } else {
              sum += (float)-0.12917336822;
            }
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.6125497818)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2042880058)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
              sum += (float)5.5356144905;
            } else {
              sum += (float)-2.0153086185;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.3232307434)) {
              sum += (float)0.75429815054;
            } else {
              sum += (float)-0.061108570546;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8220179081)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.4476566315)) {
              sum += (float)-2.3001785278;
            } else {
              sum += (float)-0.54250204563;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4220795631)) {
              sum += (float)-0.34597098827;
            } else {
              sum += (float)0.021145556122;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8454122543)) {
          sum += (float)10.319662094;
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1918489933)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
              sum += (float)1.2058269978;
            } else {
              sum += (float)-0.16939692199;
            }
          } else {
            sum += (float)6.2110185623;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3448784351)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1905374527)) {
            sum += (float)-2.5897517204;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3997039795)) {
              sum += (float)-0.10752113909;
            } else {
              sum += (float)-1.312117815;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3624351025)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
              sum += (float)-0.57712525129;
            } else {
              sum += (float)12.778504372;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.371781826)) {
              sum += (float)1.1610041857;
            } else {
              sum += (float)-0.085935018957;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.620408535)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
            sum += (float)38.321044922;
          } else {
            sum += (float)-4.3971061707;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.4680986404)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.34699654579)) {
              sum += (float)-0.0072998418473;
            } else {
              sum += (float)0.0036351510789;
            }
          } else {
            sum += (float)-0.036572813988;
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.89943528175)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9143127799)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4849374294)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0788956881)) {
              sum += (float)-0.013805937953;
            } else {
              sum += (float)0.35015836358;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20684435964)) {
              sum += (float)-0.068031609058;
            } else {
              sum += (float)0.038664322346;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.8253031373)) {
              sum += (float)0.15590077639;
            } else {
              sum += (float)6.0525579453;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.40043139458)) {
              sum += (float)-0.2661935091;
            } else {
              sum += (float)0.04945448786;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0999181271)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2363951206)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.90829610825)) {
              sum += (float)0.40681320429;
            } else {
              sum += (float)0.14192123711;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.67794954777)) {
              sum += (float)-0.18748818338;
            } else {
              sum += (float)-0.24410806596;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.029229052365)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.90227949619)) {
              sum += (float)2.2746431828;
            } else {
              sum += (float)0.63903576136;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2657215595)) {
              sum += (float)-1.0607475042;
            } else {
              sum += (float)-0.12898674607;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.79179185629)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.8577952385)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.0717082024)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84605115652)) {
              sum += (float)-0.35828784108;
            } else {
              sum += (float)1.064784646;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.4760035276)) {
              sum += (float)0.41406646371;
            } else {
              sum += (float)-0.14458468556;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9840228558)) {
            sum += (float)13.345689774;
          } else {
            sum += (float)-0.26879870892;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77981328964)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78057909012)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.84319150448)) {
              sum += (float)-0.12952367961;
            } else {
              sum += (float)0.062256872654;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.76031148434)) {
              sum += (float)3.1786472797;
            } else {
              sum += (float)-0.079597704113;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.73069548607)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2481455803)) {
              sum += (float)0.24661265314;
            } else {
              sum += (float)-0.16740547121;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.73042201996)) {
              sum += (float)1.2262368202;
            } else {
              sum += (float)0.0018541790778;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
        sum += (float)23.03827095;
      } else {
        sum += (float)-2.5988185406;
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.56224012375)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2472877502)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.41681274772)) {
              sum += (float)-1.1034580469;
            } else {
              sum += (float)1.496250391;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.13960596919)) {
              sum += (float)0.045721955597;
            } else {
              sum += (float)-0.45896342397;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.69201421738)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359526873)) {
              sum += (float)-0.36914685369;
            } else {
              sum += (float)-0.76236623526;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
              sum += (float)0.58288139105;
            } else {
              sum += (float)-0.18104663491;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.12755359709)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.0743551254)) {
              sum += (float)0.088148087263;
            } else {
              sum += (float)-0.078325688839;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.53884589672)) {
              sum += (float)-0.41717198491;
            } else {
              sum += (float)-0.059952706099;
            }
          }
        } else {
          sum += (float)0.94279634953;
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2926151752)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7048155069)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5433813334)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5436549187)) {
              sum += (float)-0.1179144755;
            } else {
              sum += (float)11.321770668;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.91796243191)) {
              sum += (float)-0.10145824403;
            } else {
              sum += (float)-0.24266174436;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6879017353)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.182929039)) {
              sum += (float)3.8259353638;
            } else {
              sum += (float)-0.31151512265;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.5700545311)) {
              sum += (float)0.015867037699;
            } else {
              sum += (float)-0.0046600154601;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884688616)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1553854942)) {
              sum += (float)0.16449509561;
            } else {
              sum += (float)0.068113863468;
            }
          } else {
            sum += (float)-1.0901893377;
          }
        } else {
          sum += (float)10.222431183;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9524407387)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
          sum += (float)11.343835831;
        } else {
          sum += (float)-0.29786476493;
        }
      } else {
        sum += (float)-0.24044163525;
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0337355137)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7056317329)) {
          sum += (float)-0.19403871894;
        } else {
          sum += (float)-1.1448316574;
        }
      } else {
        sum += (float)-0.37993386388;
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.688958168)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2270891666)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
            sum += (float)-0.1606066227;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.9092636108)) {
              sum += (float)0.0092267505825;
            } else {
              sum += (float)-0.079140000045;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3827095032)) {
            sum += (float)-0.5281868577;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)4.0626869202)) {
              sum += (float)-0.23351791501;
            } else {
              sum += (float)-0.031365022063;
            }
          }
        }
      } else {
        sum += (float)-0.44326552749;
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.152874589)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2311394215)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.90750074387)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75027692318)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.85250544548)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7475889921)) {
              sum += (float)-0.11455940455;
            } else {
              sum += (float)0.038412954658;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3607635498)) {
              sum += (float)0.60192847252;
            } else {
              sum += (float)-0.11506160349;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.93674355745)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67206048965)) {
              sum += (float)-0.15355217457;
            } else {
              sum += (float)-0.078190088272;
            }
          } else {
            sum += (float)-0.23712994158;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.89580363035)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4645698071)) {
            sum += (float)-0.24895171821;
          } else {
            sum += (float)5.1106696129;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1212928295)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.317595005)) {
              sum += (float)-0.15714609623;
            } else {
              sum += (float)-0.019262870774;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0048360825)) {
              sum += (float)-0.19257296622;
            } else {
              sum += (float)1.9085570574;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0018820763)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5176045895)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.4887445569)) {
              sum += (float)-0.23716275394;
            } else {
              sum += (float)3.0831580162;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1804907322)) {
              sum += (float)-0.33292451501;
            } else {
              sum += (float)-0.085639089346;
            }
          }
        } else {
          sum += (float)-2.0220429897;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0780200958)) {
          sum += (float)7.3729410172;
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.4698597193)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.66010713577)) {
              sum += (float)-0.36780112982;
            } else {
              sum += (float)-0.053485769778;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.39248323441)) {
              sum += (float)-0.035800684243;
            } else {
              sum += (float)0.094598211348;
            }
          }
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.83172881603)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.84957027435)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1166828871)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.079345948994)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.082270249724)) {
              sum += (float)0.015641612932;
            } else {
              sum += (float)4.8456077576;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.57602787018)) {
              sum += (float)-0.11394732445;
            } else {
              sum += (float)-0.29762908816;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.19711405039)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3747227192)) {
              sum += (float)-0.13993790746;
            } else {
              sum += (float)0.68835580349;
            }
          } else {
            sum += (float)1.6421796083;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1736098528)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4213418961)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.76032418013;
            } else {
              sum += (float)2.3768277168;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.995020926;
            } else {
              sum += (float)-0.25701013207;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0246363878)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1619126797)) {
              sum += (float)-0.068040989339;
            } else {
              sum += (float)-0.15485060215;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.96224868298)) {
              sum += (float)0.63200652599;
            } else {
              sum += (float)0.023000104353;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3572543859)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.76333677769)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9000916481)) {
              sum += (float)-0.41196927428;
            } else {
              sum += (float)-0.26290401816;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.3672046661)) {
              sum += (float)0.027744943276;
            } else {
              sum += (float)-0.57510447502;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81585842371)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.3039770126)) {
              sum += (float)0.061709418893;
            } else {
              sum += (float)-0.10501946509;
            }
          } else {
            sum += (float)-0.27611598372;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60630047321)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.65191912651)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.69110441208)) {
              sum += (float)-0.02807542868;
            } else {
              sum += (float)0.10327374935;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71603679657)) {
              sum += (float)0.0028586285189;
            } else {
              sum += (float)-0.1428989619;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60513067245)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
              sum += (float)1.2043468952;
            } else {
              sum += (float)-0.80236661434;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.3580846786)) {
              sum += (float)-0.33202305436;
            } else {
              sum += (float)0.0053572277538;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4917709827)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.0785353184)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6540744305)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0788956881)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2604854107)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3488701582)) {
              sum += (float)-0.036966949701;
            } else {
              sum += (float)-0.37072765827;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1921880245)) {
              sum += (float)2.6474773884;
            } else {
              sum += (float)-0.21471820772;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0676827431)) {
            sum += (float)4.0408558846;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4372549057)) {
              sum += (float)-0.46900507808;
            } else {
              sum += (float)-0.13668341935;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4511100054)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.7555406094)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0785127878)) {
              sum += (float)-0.21289691329;
            } else {
              sum += (float)-0.50921005011;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.82625091076)) {
              sum += (float)-0.14882169664;
            } else {
              sum += (float)-0.072995454073;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1238907576)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.806423068)) {
              sum += (float)0.02279744111;
            } else {
              sum += (float)-0.10024650395;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0291762352)) {
              sum += (float)0.10199071467;
            } else {
              sum += (float)-0.011979079805;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6893546581)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.508731842)) {
          sum += (float)-0.73762124777;
        } else {
          sum += (float)-0.051392551512;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1442379951)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1589416265)) {
              sum += (float)0.010762723163;
            } else {
              sum += (float)-0.16206039488;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4732153416)) {
              sum += (float)-0.21278963983;
            } else {
              sum += (float)-0.29338976741;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
            sum += (float)-0.66244578362;
          } else {
            sum += (float)-0.26414179802;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4906013012)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
        sum += (float)2.733877182;
      } else {
        sum += (float)-0.27118560672;
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4730556011)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.86443817616)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4933942556)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5510253906)) {
              sum += (float)-0.018096141517;
            } else {
              sum += (float)0.80558997393;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4789042473)) {
              sum += (float)-0.070077344775;
            } else {
              sum += (float)-0.3674774766;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.53718549013;
            } else {
              sum += (float)2.0635612011;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.70214682817;
            } else {
              sum += (float)-0.22640632093;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1128360033)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.85811722279)) {
              sum += (float)-0.017366815358;
            } else {
              sum += (float)-0.14697672427;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.40744966269)) {
              sum += (float)-0.78006529808;
            } else {
              sum += (float)1.247541666;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.447906971)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84266662598)) {
              sum += (float)-0.089434713125;
            } else {
              sum += (float)1.4875054359;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96061265469)) {
              sum += (float)0.070263043046;
            } else {
              sum += (float)-0.001781472587;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3863010406)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3804523945)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.88800442219)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.8801686764)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.6108994484)) {
              sum += (float)-0.0029534748755;
            } else {
              sum += (float)0.43149355054;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9842436314)) {
              sum += (float)0.38059994578;
            } else {
              sum += (float)-0.017371086404;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57059776783)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57858359814)) {
              sum += (float)-0.10075176507;
            } else {
              sum += (float)4.0721940994;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.5432751179)) {
              sum += (float)-0.13751357794;
            } else {
              sum += (float)0.86569708586;
            }
          }
        }
      } else {
        sum += (float)8.1074066162;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87039124966)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87536859512)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8442425728)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.12450620532)) {
              sum += (float)-0.10033283383;
            } else {
              sum += (float)-0.23755694926;
            }
          } else {
            sum += (float)0.015234534629;
          }
        } else {
          sum += (float)9.6417255402;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8606183529)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8571093082)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
              sum += (float)-0.31899365783;
            } else {
              sum += (float)-0.15815848112;
            }
          } else {
            sum += (float)-0.73330754042;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)4.1517648697)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5528931618)) {
              sum += (float)-0.11159298569;
            } else {
              sum += (float)0.012187995017;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1553854942)) {
              sum += (float)0.11767534167;
            } else {
              sum += (float)0.055957812816;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.53553712368)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.53717803955)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9029289484)) {
          sum += (float)-5.9194960594;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.7026052475)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.36767953634)) {
              sum += (float)0.14740440249;
            } else {
              sum += (float)-0.077361814678;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81465518475)) {
              sum += (float)-1.2880091667;
            } else {
              sum += (float)-0.38261935115;
            }
          }
        }
      } else {
        sum += (float)91.049911499;
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.68001616001)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7588536739)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.76843583584)) {
            sum += (float)-0.71944636106;
          } else {
            sum += (float)-0.38540813327;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0343203545)) {
            sum += (float)12.948196411;
          } else {
            sum += (float)-2.8731284142;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2004109621)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.74767094851)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.45212444663)) {
              sum += (float)-6.6408114433;
            } else {
              sum += (float)-0.050632182509;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91510391235)) {
              sum += (float)1.0232019424;
            } else {
              sum += (float)-0.16644956172;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73971998692)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73807907104)) {
              sum += (float)0.046705361456;
            } else {
              sum += (float)4.9794001579;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.91546100378)) {
              sum += (float)-0.14766925573;
            } else {
              sum += (float)-7.6505253674e-05;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.78175342083)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.29945790768)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5233843327)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28305643797)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.10746614635)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.40289723873)) {
              sum += (float)-0.010422681458;
            } else {
              sum += (float)-0.13644677401;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.33168196678)) {
              sum += (float)-0.21102629602;
            } else {
              sum += (float)-2.0877583027;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.21583405137)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.082987502217)) {
              sum += (float)0.006459673401;
            } else {
              sum += (float)1.0958473682;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.53908771276)) {
              sum += (float)-0.06644808501;
            } else {
              sum += (float)0.36363402009;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.10892424732)) {
          sum += (float)22.827444077;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.8808283806)) {
            sum += (float)-0.9590035677;
          } else {
            sum += (float)-0.1884316951;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.2940505743)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.95377999544)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.52247738838)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60337615013)) {
              sum += (float)-0.13973385096;
            } else {
              sum += (float)2.5727527142;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1688132286)) {
              sum += (float)-0.024050706998;
            } else {
              sum += (float)-0.39513540268;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
              sum += (float)-0.46746703982;
            } else {
              sum += (float)72.839942932;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3104596138)) {
              sum += (float)-1.155744791;
            } else {
              sum += (float)4.657271862;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.057369098067)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73069500923)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.7717602253)) {
              sum += (float)-0.073506712914;
            } else {
              sum += (float)-0.56123077869;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73917299509)) {
              sum += (float)1.0403411388;
            } else {
              sum += (float)0.026298418641;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.059775751084)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.21308159828)) {
              sum += (float)-0.36690735817;
            } else {
              sum += (float)-0.109108679;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.7963203192)) {
              sum += (float)-0.11202596128;
            } else {
              sum += (float)0.08357180655;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.26269370317)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.1673912406)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.60542500019)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.66917717457)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.89112478495)) {
              sum += (float)0.06589487195;
            } else {
              sum += (float)-0.10051161796;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.65188604593)) {
              sum += (float)2.8898532391;
            } else {
              sum += (float)0.29520505667;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.25040608644)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68408608437)) {
              sum += (float)0.053129974753;
            } else {
              sum += (float)-0.078968055546;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.036537252367)) {
              sum += (float)5.0649204254;
            } else {
              sum += (float)-0.096407331526;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.17333839834)) {
          sum += (float)6.128970623;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.90227949619)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.76610517502)) {
              sum += (float)1.3919576406;
            } else {
              sum += (float)-0.16593565047;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.31972146034)) {
              sum += (float)-0.11669977009;
            } else {
              sum += (float)0.11786717921;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.45929551125)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.31762486696)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.32085195184)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.16746294498)) {
              sum += (float)-0.11372648925;
            } else {
              sum += (float)0.58343285322;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70607197285)) {
              sum += (float)9.5010156631;
            } else {
              sum += (float)-0.17134177685;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.0088064502925)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.95067858696)) {
              sum += (float)-0.33010107279;
            } else {
              sum += (float)-0.19348119199;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.1158605963)) {
              sum += (float)0.028628598899;
            } else {
              sum += (float)-0.076848506927;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.023098850623)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.067520901561)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.63375717402)) {
              sum += (float)-0.070153109729;
            } else {
              sum += (float)0.051969215274;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.52563655376)) {
              sum += (float)0.2478569746;
            } else {
              sum += (float)2.3006999493;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.606746912)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
              sum += (float)-0.55997210741;
            } else {
              sum += (float)-0.11734301597;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.64360976219)) {
              sum += (float)0.23413039744;
            } else {
              sum += (float)-0.0065907947719;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5589373112)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.16079765558)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26708444953)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.27408733964)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30100604892)) {
              sum += (float)0.00034254573984;
            } else {
              sum += (float)-0.13729126751;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.2940505743)) {
              sum += (float)2.6274175644;
            } else {
              sum += (float)-0.1443361789;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2004109621)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.45285409689)) {
              sum += (float)0.036065850407;
            } else {
              sum += (float)0.78388828039;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.19690185785)) {
              sum += (float)-0.65941035748;
            } else {
              sum += (float)0.011279513128;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.17946064472)) {
          sum += (float)9.6830177307;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.49716258049)) {
            sum += (float)-1.958707571;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.68007671833)) {
              sum += (float)0.17402431369;
            } else {
              sum += (float)-0.13144822419;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50921499729)) {
        sum += (float)19.403326035;
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.673084259)) {
          sum += (float)-0.19503551722;
        } else {
          sum += (float)0.11495210975;
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.63773190975)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.044355750084)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1043952703)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1626694202)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60337615013)) {
              sum += (float)-0.028714012355;
            } else {
              sum += (float)1.0667327642;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12394329906)) {
              sum += (float)-0.1427616477;
            } else {
              sum += (float)0.014424253255;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.44091773033)) {
            sum += (float)1.1408644915;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.80320036411)) {
              sum += (float)-0.36638098955;
            } else {
              sum += (float)-0.2153802067;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32732450962)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.83090388775)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.34019136429)) {
              sum += (float)-0.20792080462;
            } else {
              sum += (float)-0.44379994273;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38743555546)) {
              sum += (float)-1.2601739168;
            } else {
              sum += (float)4.3896670341;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9634286165)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2869695425)) {
              sum += (float)-0.28006094694;
            } else {
              sum += (float)-0.10946464539;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26084950566)) {
              sum += (float)0.5022469759;
            } else {
              sum += (float)-0.045388795435;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94785583019)) {
        sum += (float)-4.7076497078;
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0531334877)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.055485487)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9976979494)) {
              sum += (float)-0.17537274957;
            } else {
              sum += (float)-0.63898438215;
            }
          } else {
            sum += (float)7.7989063263;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.83515226841)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30334544182)) {
              sum += (float)4.6010165215;
            } else {
              sum += (float)0.052068788558;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.091015353799)) {
              sum += (float)0.076141983271;
            } else {
              sum += (float)-0.028569685295;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0764243603)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0615563393)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.10769785196)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.089647904038)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.119772315)) {
              sum += (float)0.0035588683095;
            } else {
              sum += (float)-0.10796060413;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.090194895864)) {
              sum += (float)31.88401413;
            } else {
              sum += (float)0.27663978934;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70465928316)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5123929977)) {
              sum += (float)-0.053661573678;
            } else {
              sum += (float)2.0459125042;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70553445816)) {
              sum += (float)2.4215505123;
            } else {
              sum += (float)0.0012654889142;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2061655521)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.3596457839)) {
              sum += (float)-0.13185361028;
            } else {
              sum += (float)-0.060749202967;
            }
          } else {
            sum += (float)1.6377215385;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.57853394747)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.2487168014)) {
              sum += (float)-0.18147164583;
            } else {
              sum += (float)0.15567427874;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1423275471)) {
              sum += (float)-0.46965220571;
            } else {
              sum += (float)-0.0015559338499;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1918489933)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.27162432671)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0858738422)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
              sum += (float)-0.47426858544;
            } else {
              sum += (float)-0.28762924671;
            }
          } else {
            sum += (float)-0.035487815738;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3700270653)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.264544487)) {
              sum += (float)0.065169706941;
            } else {
              sum += (float)-0.14214013517;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.08964138478;
            } else {
              sum += (float)0.04789147526;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2025899887)) {
          sum += (float)-0.072951696813;
        } else {
          sum += (float)-0.99343377352;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.6125497818)) {
              sum += (float)0.32316112518;
            } else {
              sum += (float)-0.73722869158;
            }
          } else {
            sum += (float)-1.4197766781;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8454122543)) {
            sum += (float)7.4584989548;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1918489933)) {
              sum += (float)0.047985628247;
            } else {
              sum += (float)4.7926239967;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.59449982643)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1905374527)) {
            sum += (float)-2.2152318954;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.8261613846)) {
              sum += (float)-0.12331211567;
            } else {
              sum += (float)-0.69872498512;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.59996956587)) {
            sum += (float)8.1749153137;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3882997036)) {
              sum += (float)0.065221443772;
            } else {
              sum += (float)-0.1405248642;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.620408535)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
          sum += (float)32.571041107;
        } else {
          sum += (float)-3.7102313042;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.71702075005)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.34699654579)) {
            sum += (float)-0.0083028320223;
          } else {
            sum += (float)-0.001083465293;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.4680986404)) {
            sum += (float)0.055617287755;
          } else {
            sum += (float)0.00022783326858;
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.4439940453)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4822171926)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4599926472)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9515287876)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.665127039)) {
              sum += (float)-0.0023982333951;
            } else {
              sum += (float)0.077767647803;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9846203327)) {
              sum += (float)1.8560223579;
            } else {
              sum += (float)0.044873055071;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.4673894644)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6478359699)) {
              sum += (float)1.3489277363;
            } else {
              sum += (float)-0.14281952381;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.7084387541)) {
              sum += (float)0.29302167892;
            } else {
              sum += (float)-0.089445233345;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.815325737)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.85157501698)) {
              sum += (float)-0.17371222377;
            } else {
              sum += (float)0.37403571606;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.95839899778)) {
              sum += (float)5.9429531097;
            } else {
              sum += (float)-0.22863610089;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.20430520177)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6367483139)) {
              sum += (float)2.2482550144;
            } else {
              sum += (float)-0.14733305573;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0393900871)) {
              sum += (float)-0.32602122426;
            } else {
              sum += (float)-0.052934974432;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2042880058)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8383939266)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
              sum += (float)0.8799277544;
            } else {
              sum += (float)5.3930678368;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0468428135)) {
              sum += (float)-0.17039264739;
            } else {
              sum += (float)1.0753186941;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70553445816)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.67134892941)) {
              sum += (float)-0.10343813151;
            } else {
              sum += (float)3.7142839432;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.4096355438)) {
              sum += (float)-1.1164427996;
            } else {
              sum += (float)-0.3204241991;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.1469101906)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.95057636499)) {
              sum += (float)-0.06051036343;
            } else {
              sum += (float)0.10787490755;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.620408535)) {
              sum += (float)16.354457855;
            } else {
              sum += (float)0.015823559836;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
            sum += (float)-0.59593778849;
          } else {
            sum += (float)6.5399298668;
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.46749424934)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50895452499)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.8170768023)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.66917717457)) {
              sum += (float)-0.65271639824;
            } else {
              sum += (float)-0.24740950763;
            }
          } else {
            sum += (float)-0.84384030104;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9524407387)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
              sum += (float)8.1462907791;
            } else {
              sum += (float)-0.26522341371;
            }
          } else {
            sum += (float)-0.22454476357;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.39422810078)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.5343544483)) {
            sum += (float)4.6074199677;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.35865584016)) {
              sum += (float)-0.60990774632;
            } else {
              sum += (float)2.3103859425;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7400509119)) {
            sum += (float)-0.6563449502;
          } else {
            sum += (float)-0.16102841496;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.07635705173)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.093969449401)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.35865584016)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9413284063)) {
              sum += (float)-0.49935305119;
            } else {
              sum += (float)-0.20187364519;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4316966534)) {
              sum += (float)-0.18117696047;
            } else {
              sum += (float)0.007008405868;
            }
          }
        } else {
          sum += (float)-1.0779075623;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2011525631)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.68437767029)) {
              sum += (float)-0.11309427768;
            } else {
              sum += (float)-0.21793213487;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
              sum += (float)0.45496535301;
            } else {
              sum += (float)-0.12922291458;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3394815922)) {
            sum += (float)-0.55779790878;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.6773881912)) {
              sum += (float)-0.17301061749;
            } else {
              sum += (float)-0.3846333921;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.4944349527)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.306063205)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1858918667)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.83497691154)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.5743044615)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5525921583)) {
              sum += (float)-0.29696452618;
            } else {
              sum += (float)-0.097233258188;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.5638973713)) {
              sum += (float)-0.076804898679;
            } else {
              sum += (float)0.002035724232;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1879115105)) {
            sum += (float)-0.77907496691;
          } else {
            sum += (float)0.12018887699;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.16144409776)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.8079867959)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.98538911343)) {
              sum += (float)0.0023671211675;
            } else {
              sum += (float)0.12265609205;
            }
          } else {
            sum += (float)-0.22647511959;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.5975998044)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
              sum += (float)-0.10017228872;
            } else {
              sum += (float)-0.20768602192;
            }
          } else {
            sum += (float)0.2005789578;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.59752762318)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.83731812239)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.80026638508)) {
            sum += (float)0.075708605349;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0858738422)) {
              sum += (float)-0.15493108332;
            } else {
              sum += (float)0.030957946554;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.19103941321)) {
            sum += (float)0.10771173984;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
              sum += (float)-0.35154655576;
            } else {
              sum += (float)0.0042326813564;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18578960001)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.61236137152)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.58700025082)) {
              sum += (float)-0.53644818068;
            } else {
              sum += (float)-0.24360002577;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.86741173267)) {
              sum += (float)-0.2547262907;
            } else {
              sum += (float)-1.0394841433;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.95839893818)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.8913526535)) {
              sum += (float)0.068445242941;
            } else {
              sum += (float)0.014733788557;
            }
          } else {
            sum += (float)-0.14163641632;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.1348743439)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.0657095909)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2828502655)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2678084373)) {
              sum += (float)0.00072687922511;
            } else {
              sum += (float)1.4355287552;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17331144214)) {
              sum += (float)0.26775577664;
            } else {
              sum += (float)-0.13789311051;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)19.562393188;
            } else {
              sum += (float)-2.2291371822;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.111810565)) {
              sum += (float)-0.4498693347;
            } else {
              sum += (float)0.065331272781;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
          sum += (float)25.232213974;
        } else {
          sum += (float)-5.606865406;
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.38391697407)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.93708097935)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.38869035244)) {
            sum += (float)-0.41952830553;
          } else {
            sum += (float)-0.9054402113;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9494880438)) {
            sum += (float)0.098256789148;
          } else {
            sum += (float)-0.009806977585;
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.030606949702)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.031838051975)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.12353609502)) {
              sum += (float)-0.003925957717;
            } else {
              sum += (float)-0.17634877563;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.2179504931)) {
              sum += (float)0.19043034315;
            } else {
              sum += (float)1.6138925552;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.15549701452)) {
            sum += (float)-1.0279182196;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.3942546844)) {
              sum += (float)-0.096744678915;
            } else {
              sum += (float)0.70046085119;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1666289568)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1522983313)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8079814911)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2390909195)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6459765434)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6296007633)) {
              sum += (float)0.00073961837916;
            } else {
              sum += (float)0.3361286819;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.28345310688;
            } else {
              sum += (float)-0.035120051354;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)4.380068779)) {
              sum += (float)6.9242377281;
            } else {
              sum += (float)-0.092003770173;
            }
          } else {
            sum += (float)-0.21232409775;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8091511726)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
            sum += (float)3.5371408463;
          } else {
            sum += (float)-1.2751041651;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.70538669825)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
              sum += (float)-0.10358563066;
            } else {
              sum += (float)9.1601114273;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
              sum += (float)-0.020434714854;
            } else {
              sum += (float)0.87217831612;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4624342918)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.080114603)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
              sum += (float)0.060584612191;
            } else {
              sum += (float)-0.16184417903;
            }
          } else {
            sum += (float)-0.43081742525;
          }
        } else {
          sum += (float)2.8785662651;
        }
      } else {
        sum += (float)3.2027070522;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.3022770882)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.90186345577)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8477516174)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.2941820621)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.37556955218)) {
              sum += (float)-0.21961799264;
            } else {
              sum += (float)-0.059043474495;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.075326249003)) {
              sum += (float)-0.083013147116;
            } else {
              sum += (float)-0.86319303513;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.3826674819)) {
              sum += (float)3.8393387794;
            } else {
              sum += (float)0.074756599963;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
              sum += (float)-0.1445671618;
            } else {
              sum += (float)-0.35271126032;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.2466250658)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.0740301609)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.7325437069)) {
              sum += (float)-0.19702768326;
            } else {
              sum += (float)-0.056214310229;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.73921406269)) {
              sum += (float)-2.5053846836;
            } else {
              sum += (float)-0.22887663543;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3194284439)) {
            sum += (float)-0.17229011655;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.7117518187)) {
              sum += (float)-0.084079757333;
            } else {
              sum += (float)-0.13340908289;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.3047385216)) {
        sum += (float)4.4012546539;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4835700989)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.76458466053)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
              sum += (float)-0.07104396075;
            } else {
              sum += (float)0.54681324959;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.19861775637)) {
              sum += (float)0.03568380326;
            } else {
              sum += (float)-0.19625101984;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.786164999)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.7117518187)) {
              sum += (float)0.0095806764439;
            } else {
              sum += (float)0.6779281497;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.655919075)) {
              sum += (float)-0.10689929873;
            } else {
              sum += (float)-0.0021037685219;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.12621535361)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5589373112)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.10892424732)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18389105797)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.23043805361)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.23196959496)) {
              sum += (float)0.0023042249959;
            } else {
              sum += (float)1.0535770655;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18438334763)) {
              sum += (float)-0.15110948682;
            } else {
              sum += (float)-0.81375211477;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1831253022)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.39672535658)) {
              sum += (float)-0.40414088964;
            } else {
              sum += (float)6.1391010284;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.48853701353)) {
              sum += (float)0.047293189913;
            } else {
              sum += (float)-0.053334333003;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.24805045128)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3146712482)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.69227409363)) {
              sum += (float)-0.13108643889;
            } else {
              sum += (float)-0.42849579453;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.40094009042)) {
              sum += (float)2.5832705498;
            } else {
              sum += (float)-0.31341406703;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.15078090131)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.44086408615)) {
              sum += (float)-0.023081686348;
            } else {
              sum += (float)-0.072511851788;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22825020552)) {
              sum += (float)0.049721524119;
            } else {
              sum += (float)-0.12044749409;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50921499729)) {
        sum += (float)16.496458054;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730372906)) {
          sum += (float)-0.072613507509;
        } else {
          sum += (float)-0.14731152356;
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.51726841927)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.54866433144)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.24710536)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.39248323441)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63814842701)) {
              sum += (float)-0.121110484;
            } else {
              sum += (float)-0.28768861294;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.42631065845)) {
              sum += (float)0.519089818;
            } else {
              sum += (float)-0.042326454073;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57710677385)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
              sum += (float)0.83010500669;
            } else {
              sum += (float)-0.29312038422;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.25589895248)) {
              sum += (float)-1.683858037;
            } else {
              sum += (float)5.8494901657;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.34518015385)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52459776402)) {
              sum += (float)-0.32580444217;
            } else {
              sum += (float)1.8600763083;
            }
          } else {
            sum += (float)57.351222992;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
            sum += (float)1.3624322414;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52777016163)) {
              sum += (float)-0.066110953689;
            } else {
              sum += (float)0.22009070218;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22622644901)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.2729922533)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26825416088)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.3487790823)) {
              sum += (float)-0.0750137344;
            } else {
              sum += (float)-0.3958106339;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2004109472)) {
              sum += (float)0.23568171263;
            } else {
              sum += (float)-0.056642945856;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.27266409993)) {
            sum += (float)-1.3392888308;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.8923419714)) {
              sum += (float)-0.51555126905;
            } else {
              sum += (float)-0.20299634337;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22540599108)) {
          sum += (float)7.1001787186;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.19751060009)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.24807825685)) {
              sum += (float)0.90241497755;
            } else {
              sum += (float)-0.075418308377;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.79192435741)) {
              sum += (float)-0.048802286386;
            } else {
              sum += (float)0.017876591533;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.99695926905)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1182222366)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.96606761217)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4455674887)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4496614933)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71363008022)) {
              sum += (float)0.026248851791;
            } else {
              sum += (float)-0.13143801689;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1619746685)) {
              sum += (float)-0.37235686183;
            } else {
              sum += (float)0.9591448307;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1626694202)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.7886736393)) {
              sum += (float)-0.023216329515;
            } else {
              sum += (float)-0.97124379873;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.073617301881)) {
              sum += (float)-0.15804234147;
            } else {
              sum += (float)0.0090228933841;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0895206928)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1358013153)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.70560777187)) {
              sum += (float)0.005578649696;
            } else {
              sum += (float)-0.25537741184;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2586295605)) {
              sum += (float)1.0163036585;
            } else {
              sum += (float)0.049139667302;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0435409546)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.64324045181)) {
              sum += (float)-0.19872635603;
            } else {
              sum += (float)4.5111823082;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.92568933964)) {
              sum += (float)-0.12744046748;
            } else {
              sum += (float)0.20279034972;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
        sum += (float)14.795022964;
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.49634763598)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.64197653532)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.3402097225)) {
              sum += (float)-0.25148549676;
            } else {
              sum += (float)-0.052737932652;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6391903162)) {
              sum += (float)-0.053701829165;
            } else {
              sum += (float)0.16138498485;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.0341210365)) {
            sum += (float)-0.38777402043;
          } else {
            sum += (float)-0.16642056406;
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.9738188982)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3011611104)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.90309458971)) {
          sum += (float)-0.22916074097;
        } else {
          sum += (float)6.8837780952;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.60276389122)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25521576405)) {
            sum += (float)-1.5343059301;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1049503535)) {
              sum += (float)-0.40437042713;
            } else {
              sum += (float)-0.11792994291;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.59384310246)) {
            sum += (float)7.1887989044;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.085583150387)) {
              sum += (float)-0.73310762644;
            } else {
              sum += (float)-0.057706985623;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.020759349689)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.046696051955)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5589373112)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.018712650985)) {
              sum += (float)-0.0088824089617;
            } else {
              sum += (float)0.033865593374;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.20388586819)) {
              sum += (float)14.021988869;
            } else {
              sum += (float)-0.076005086303;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.020381852984)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.40688073635)) {
              sum += (float)2.2516965866;
            } else {
              sum += (float)0.068435072899;
            }
          } else {
            sum += (float)3.2703025341;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.29945790768)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.43774145842)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.86915421486)) {
              sum += (float)-0.010858028196;
            } else {
              sum += (float)0.63499450684;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.57658344507)) {
              sum += (float)-0.19512116909;
            } else {
              sum += (float)-0.082267083228;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49604600668)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49735873938)) {
              sum += (float)0.067327350378;
            } else {
              sum += (float)5.1496114731;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.688180089)) {
              sum += (float)0.26979634166;
            } else {
              sum += (float)-0.0061148488894;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.65887725353)) {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.70802772045)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.31838768721)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.59972381592)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.72031533718)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78851008415)) {
              sum += (float)-0.034844733775;
            } else {
              sum += (float)0.0065921009518;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70783221722)) {
              sum += (float)-0.054982408881;
            } else {
              sum += (float)0.55053645372;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.1910533011)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.2940505445)) {
              sum += (float)-0.70004785061;
            } else {
              sum += (float)-0.47492703795;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8410410881)) {
              sum += (float)-0.076142936945;
            } else {
              sum += (float)0.41867390275;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.16356509924)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.36258006096)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.81615191698)) {
              sum += (float)12.348151207;
            } else {
              sum += (float)1.1417833567;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.55678474903)) {
              sum += (float)0.12659998238;
            } else {
              sum += (float)0.019079308957;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.3864951134)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.3862367868)) {
              sum += (float)-0.1508230865;
            } else {
              sum += (float)0.021978260949;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.34064549208)) {
              sum += (float)-0.034905020148;
            } else {
              sum += (float)2.3219144344;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26347494125)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28261885047)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.28579980135)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.13468195498)) {
              sum += (float)-0.055701125413;
            } else {
              sum += (float)-0.19148784876;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.21593829989)) {
              sum += (float)-0.57856488228;
            } else {
              sum += (float)-0.21614256501;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
            sum += (float)1.4431818724;
          } else {
            sum += (float)-0.069241516292;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.08784340322)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.2366719991)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.10721504688)) {
              sum += (float)-0.38753202558;
            } else {
              sum += (float)-0.0076618301682;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
              sum += (float)-0.76562535763;
            } else {
              sum += (float)-0.3906468153;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.0040473490953)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
              sum += (float)-0.16343870759;
            } else {
              sum += (float)-0.031250350177;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
              sum += (float)0.16902704537;
            } else {
              sum += (float)-0.038822125643;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.63430202007)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.43025898933)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.48056674004)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.10721504688)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.53733742237)) {
              sum += (float)0.016069548205;
            } else {
              sum += (float)0.16607858241;
            }
          } else {
            sum += (float)-0.060722898692;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.69511389732)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.53733742237)) {
              sum += (float)-0.057477694005;
            } else {
              sum += (float)-0.23326198757;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.34956783056)) {
              sum += (float)-0.061358340085;
            } else {
              sum += (float)-0.1213291958;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.59200340509)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
            sum += (float)-0.38609686494;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.64580965042)) {
              sum += (float)3.2141838074;
            } else {
              sum += (float)0.024865420535;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18875905871)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.41082829237)) {
              sum += (float)-0.29619136453;
            } else {
              sum += (float)1.0596821308;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.45498234034)) {
              sum += (float)-0.075695946813;
            } else {
              sum += (float)-0.22393144667;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.60972678661)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.83470243216)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.42016485333)) {
            sum += (float)-0.33457005024;
          } else {
            sum += (float)-0.068890921772;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.99288964272)) {
            sum += (float)-0.19303748012;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.4261713028)) {
              sum += (float)-0.089627504349;
            } else {
              sum += (float)-0.21886400878;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.54828882217)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.57286399603)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.0034682005644)) {
              sum += (float)0.045196324587;
            } else {
              sum += (float)-0.11986816674;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
              sum += (float)1.3392816782;
            } else {
              sum += (float)-0.14286695421;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.48685067892)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
              sum += (float)-0.10775455087;
            } else {
              sum += (float)0.90376955271;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.44998779893)) {
              sum += (float)0.25992077589;
            } else {
              sum += (float)-0.00041166733718;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.84208858013)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.76772046089)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.77005982399)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0397932529)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1995322704)) {
              sum += (float)0.030391180888;
            } else {
              sum += (float)-0.060673654079;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.9783551693)) {
              sum += (float)0.14636428654;
            } else {
              sum += (float)0.0086311167106;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.136038065)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.54135489464)) {
              sum += (float)0.025133853778;
            } else {
              sum += (float)0.08857537806;
            }
          } else {
            sum += (float)0.52268064022;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.42733475566)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.96118581295)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.27999293804)) {
              sum += (float)-0.096200540662;
            } else {
              sum += (float)-1.0274271965;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.91596806049)) {
              sum += (float)-0.051112417132;
            } else {
              sum += (float)-0.87267273664;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.9795274734)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70591783524)) {
              sum += (float)-0.64869964123;
            } else {
              sum += (float)5.1337752342;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.59261202812)) {
              sum += (float)-0.069210343063;
            } else {
              sum += (float)0.25951805711;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.904941082)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0990782976)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96061265469)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.51458978653)) {
              sum += (float)0.30584859848;
            } else {
              sum += (float)2.5274984837;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.8341819644)) {
              sum += (float)0.29890033603;
            } else {
              sum += (float)-0.09535934031;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.083361148834)) {
            sum += (float)11.834699631;
          } else {
            sum += (float)-0.032074421644;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.99116194248)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.3147249222)) {
            sum += (float)-1.8869866133;
          } else {
            sum += (float)-0.14228570461;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96228194237)) {
            sum += (float)20.458545685;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.091627955437)) {
              sum += (float)-1.5718597174;
            } else {
              sum += (float)0.022384759039;
            }
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.67307984829)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38148838282)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.51155388355)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77133524418)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78090727329)) {
              sum += (float)-0.084799550474;
            } else {
              sum += (float)0.73737174273;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.0085329497233)) {
              sum += (float)-0.1369304806;
            } else {
              sum += (float)0.23345291615;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.4168073535)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87821292877)) {
              sum += (float)1.1589020491;
            } else {
              sum += (float)0.20980401337;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.36662054062)) {
              sum += (float)-0.080400235951;
            } else {
              sum += (float)0.052804797888;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.13367374241)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.97592878342)) {
              sum += (float)-0.51166653633;
            } else {
              sum += (float)-0.1581377089;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.39399802685)) {
              sum += (float)-0.80105394125;
            } else {
              sum += (float)-0.31299045682;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.33960652351)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.59226387739)) {
              sum += (float)-0.019140098244;
            } else {
              sum += (float)-0.21729776263;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32206085324)) {
              sum += (float)0.35609272122;
            } else {
              sum += (float)-0.081003516912;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.65616619587)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.6639777422)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.68646836281)) {
            sum += (float)-0.39137849212;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.62033689022)) {
              sum += (float)0.040392272174;
            } else {
              sum += (float)-0.11629894376;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1098330021)) {
            sum += (float)1.2877992392;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.24728475511)) {
              sum += (float)-0.11243277043;
            } else {
              sum += (float)-0.028424547985;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.79021519423)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52968454361)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2179636955)) {
              sum += (float)0.049101326615;
            } else {
              sum += (float)-0.37528637052;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.084131196141)) {
              sum += (float)4.3553438187;
            } else {
              sum += (float)-0.39092710614;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.20633813739)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.61512112617)) {
              sum += (float)0.035737860948;
            } else {
              sum += (float)-0.022058160976;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.020381849259)) {
              sum += (float)0.062027264386;
            } else {
              sum += (float)0.0020230975933;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.2472667694)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.0657095909)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.3110620975)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0615563393)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5383296013)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4086461067)) {
              sum += (float)0.00063965568552;
            } else {
              sum += (float)-0.57346636057;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.52202653885)) {
              sum += (float)1.0628939867;
            } else {
              sum += (float)-0.044969767332;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2061655521)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
              sum += (float)-0.029321109876;
            } else {
              sum += (float)1.1466017962;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.74869656563)) {
              sum += (float)0.30366066098;
            } else {
              sum += (float)-0.06402258575;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.95385813713)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.6244413853)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3747227192)) {
              sum += (float)-0.12733381987;
            } else {
              sum += (float)-0.4193367064;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.7106750011)) {
              sum += (float)0.32560390234;
            } else {
              sum += (float)-0.069495782256;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.96107816696)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.1665701866)) {
              sum += (float)-0.44076308608;
            } else {
              sum += (float)15.282318115;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.371781826)) {
              sum += (float)1.0112392902;
            } else {
              sum += (float)-0.054026011378;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
        sum += (float)21.314544678;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.3066898584)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.36458545923)) {
            sum += (float)-0.013145660982;
          } else {
            sum += (float)-0.032872468233;
          }
        } else {
          sum += (float)-4.8986678123;
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.38391697407)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.93708097935)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.38869035244)) {
          sum += (float)-0.28442019224;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.65987426043)) {
            sum += (float)-0.63858258724;
          } else {
            sum += (float)-0.18240362406;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9494880438)) {
          sum += (float)0.081401355565;
        } else {
          sum += (float)-0.010668141767;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.030606949702)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.031838051975)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.049518350512)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.50219619274)) {
              sum += (float)-0.026368334889;
            } else {
              sum += (float)0.12172783166;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.52188515663)) {
              sum += (float)-0.14566718042;
            } else {
              sum += (float)-0.018471000716;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.2179504931)) {
            sum += (float)0.18268753588;
          } else {
            sum += (float)1.2490044832;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.093408301473)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.59972381592)) {
            sum += (float)-0.84354424477;
          } else {
            sum += (float)-0.2145396471;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6327625513)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.3942546844)) {
              sum += (float)-0.052347898483;
            } else {
              sum += (float)0.55886077881;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4296822548)) {
              sum += (float)-0.17956498265;
            } else {
              sum += (float)-0.42226311564;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.9473814964)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.98635458946)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1043952703)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.0131168365)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0636284351)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0716633797)) {
              sum += (float)-0.0016689454205;
            } else {
              sum += (float)0.74595719576;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2823929787)) {
              sum += (float)0.03863946721;
            } else {
              sum += (float)-0.063271202147;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1182222366)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.61156409979)) {
              sum += (float)-0.079031683505;
            } else {
              sum += (float)-0.27732542157;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.40981006622)) {
              sum += (float)9.4676332474;
            } else {
              sum += (float)-0.15880979598;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050498813)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72678053379)) {
              sum += (float)0.15751338005;
            } else {
              sum += (float)0.011974626221;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.58272147179)) {
              sum += (float)-2.9281311035;
            } else {
              sum += (float)-0.23414774239;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            sum += (float)-1.6132566929;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0555934906)) {
              sum += (float)2.8513417244;
            } else {
              sum += (float)0.54205614328;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.59384310246)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4847527742)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6720634699)) {
              sum += (float)-0.29524889588;
            } else {
              sum += (float)-0.12712956965;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4713010788)) {
              sum += (float)0.17600044608;
            } else {
              sum += (float)0.019605359063;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.17576345801)) {
              sum += (float)-0.37601301074;
            } else {
              sum += (float)3.1788544655;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.17576345801)) {
              sum += (float)0.044095471501;
            } else {
              sum += (float)-1.0214139223;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.7412279844)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7470997572)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.090078398585)) {
              sum += (float)0.033396277577;
            } else {
              sum += (float)-0.3209913075;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.182929039)) {
              sum += (float)5.5748991966;
            } else {
              sum += (float)-0.23745295405;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.17333839834)) {
              sum += (float)-0.081852741539;
            } else {
              sum += (float)-0.79155004025;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.7539857626)) {
              sum += (float)-0.031542342156;
            } else {
              sum += (float)0.0012843561126;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.0944724083)) {
      sum += (float)-0.54830497503;
    } else {
      sum += (float)-0.30170693994;
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3870819807)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.81983458996)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.84957027435)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4849374294)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0409359932)) {
              sum += (float)0.012995792553;
            } else {
              sum += (float)-0.19699691236;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87356364727)) {
              sum += (float)0.084722302854;
            } else {
              sum += (float)1.9575403929;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.62097364664)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0582278967)) {
              sum += (float)-0.082423336804;
            } else {
              sum += (float)0.11147978902;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1446835995)) {
              sum += (float)-0.10061448067;
            } else {
              sum += (float)-0.23174647987;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
            sum += (float)0.28963902593;
          } else {
            sum += (float)1.4222364426;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
            sum += (float)0.40531912446;
          } else {
            sum += (float)-0.20341601968;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.242538929)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.3672046661)) {
            sum += (float)0.045831751078;
          } else {
            sum += (float)-0.44109386206;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9000916481)) {
            sum += (float)-0.28531253338;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.205222249)) {
              sum += (float)-0.1780076474;
            } else {
              sum += (float)-0.0083751017228;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1589416265)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70205450058)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4631131887)) {
              sum += (float)-0.063640549779;
            } else {
              sum += (float)-0.040443204343;
            }
          } else {
            sum += (float)0.020761212334;
          }
        } else {
          sum += (float)-0.11444023997;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3701212406)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0582278967)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.8100340366)) {
          sum += (float)0.67109364271;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.3781139851)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1886174679)) {
              sum += (float)-0.078371465206;
            } else {
              sum += (float)0.15804342926;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55167269707)) {
              sum += (float)-0.46725609899;
            } else {
              sum += (float)-0.13326331973;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55167269707)) {
          sum += (float)1.3828858137;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84266656637)) {
            sum += (float)-0.006805463694;
          } else {
            sum += (float)0.3518358469;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.298768878)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.72615945339)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2052025795)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2439707518)) {
              sum += (float)0.0048371581361;
            } else {
              sum += (float)-0.14544028044;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.75428187847)) {
              sum += (float)0.049882479012;
            } else {
              sum += (float)0.95731300116;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.62973964214)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.67794954777)) {
              sum += (float)-0.20591655374;
            } else {
              sum += (float)-0.14672116935;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.8994323015)) {
              sum += (float)-0.068110883236;
            } else {
              sum += (float)-0.023927470669;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2554895878)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.1261124611)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.79886078835)) {
              sum += (float)1.077029705;
            } else {
              sum += (float)-0.30341103673;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67419362068)) {
              sum += (float)-0.061689633876;
            } else {
              sum += (float)0.46337532997;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2819730043)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.58666485548)) {
              sum += (float)0.024572428316;
            } else {
              sum += (float)0.97879439592;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1952495575)) {
              sum += (float)-0.10352803022;
            } else {
              sum += (float)-0.00060354894958;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.92622482777)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3775281906)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.87707442045)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96824389696)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
              sum += (float)-0.021602023393;
            } else {
              sum += (float)-0.39602321386;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9029289484)) {
              sum += (float)-3.7757527828;
            } else {
              sum += (float)-0.20289294422;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96786105633)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
              sum += (float)-0.18300080299;
            } else {
              sum += (float)4.39361763;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.89927124977)) {
              sum += (float)0.079825237393;
            } else {
              sum += (float)-0.00047257039114;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.594758153)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.86618059874)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2991598845)) {
              sum += (float)0.22228515148;
            } else {
              sum += (float)-0.10792996734;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.43064773083)) {
              sum += (float)-0.18674947321;
            } else {
              sum += (float)0.45826610923;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1654261351)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
              sum += (float)-0.036278586835;
            } else {
              sum += (float)-0.23121134937;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.38387334347)) {
              sum += (float)-0.035932648927;
            } else {
              sum += (float)1.5899051428;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4044314623)) {
        sum += (float)5.8389549255;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.9504308701)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2242029905)) {
              sum += (float)-0.73603415489;
            } else {
              sum += (float)-0.1120800972;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.27419531345)) {
              sum += (float)-0.27329954505;
            } else {
              sum += (float)-0.14257159829;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6367483139)) {
              sum += (float)3.0760469437;
            } else {
              sum += (float)-0.043821647763;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.27419531345)) {
              sum += (float)-0.71724772453;
            } else {
              sum += (float)-0.032794728875;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.0491009951)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.79481488466)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.61036735773)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1347410679)) {
              sum += (float)0.081654965878;
            } else {
              sum += (float)-0.01896417886;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96654832363)) {
              sum += (float)-0.17425221205;
            } else {
              sum += (float)-0.078825853765;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.11014710367)) {
            sum += (float)5.8415403366;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.44435700774)) {
              sum += (float)0.0014466658467;
            } else {
              sum += (float)-0.12356442213;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.8783800602)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.57007712126)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.6244413853)) {
              sum += (float)-0.10310377181;
            } else {
              sum += (float)-0.29329195619;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.48674750328)) {
              sum += (float)2.7211897373;
            } else {
              sum += (float)-0.22291629016;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.665127039)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.93708097935)) {
              sum += (float)-0.028628464788;
            } else {
              sum += (float)-0.22713318467;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9294006824)) {
              sum += (float)-0.4110570848;
            } else {
              sum += (float)-0.14432671666;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.85193961859)) {
          sum += (float)-1.8350161314;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72502595186)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
              sum += (float)0.062647417188;
            } else {
              sum += (float)-2.5462224483;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.84297055006)) {
              sum += (float)-0.059935107827;
            } else {
              sum += (float)-0.25266671181;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.68646836281)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.025539299473)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3747227192)) {
              sum += (float)-0.016090795398;
            } else {
              sum += (float)-0.18801313639;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.21542099118)) {
              sum += (float)2.0458374023;
            } else {
              sum += (float)-0.32229539752;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72502595186)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
              sum += (float)-0.36926800013;
            } else {
              sum += (float)2.0531351566;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1726051569)) {
              sum += (float)-0.060583699495;
            } else {
              sum += (float)0.011051419191;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67364668846)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.69098556042)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.692024827)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.75764834881)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2497713566)) {
              sum += (float)0.00098128453828;
            } else {
              sum += (float)1.1983184814;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.79147577286)) {
              sum += (float)-0.07378821075;
            } else {
              sum += (float)2.5658135414;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.40511023998)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.96118581295)) {
              sum += (float)-0.062657490373;
            } else {
              sum += (float)-0.50839573145;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.98738789558)) {
              sum += (float)0.063786037266;
            } else {
              sum += (float)-0.042555917054;
            }
          }
        }
      } else {
        sum += (float)3.6023013592;
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.087378695607)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1242311001)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67960870266)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.7296962142)) {
              sum += (float)-0.098556727171;
            } else {
              sum += (float)-0.18187205493;
            }
          } else {
            sum += (float)0.077262930572;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9149813652)) {
            sum += (float)-0.42489567399;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0827999115)) {
              sum += (float)-0.35759890079;
            } else {
              sum += (float)-0.17913341522;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.61036741734)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.35100024939)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.68896174431)) {
              sum += (float)-0.27390655875;
            } else {
              sum += (float)-0.040196627378;
            }
          } else {
            sum += (float)0.014901931398;
          }
        } else {
          sum += (float)-0.10471319407;
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65045523643)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65094745159)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.66719245911)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.7296962142)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.90694642067)) {
              sum += (float)1.0558780432;
            } else {
              sum += (float)0.59396851063;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
              sum += (float)-0.32488167286;
            } else {
              sum += (float)-0.08014536649;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.55098199844)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.95448100567)) {
              sum += (float)0.0051042088307;
            } else {
              sum += (float)-0.15260146558;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.43774145842)) {
              sum += (float)0.68391263485;
            } else {
              sum += (float)-0.11143539101;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.29741764069)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
            sum += (float)-0.15915332735;
          } else {
            sum += (float)-0.08425629884;
          }
        } else {
          sum += (float)5.3541264534;
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.3158004284)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.68456470966)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.42696389556)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.193652153)) {
              sum += (float)-0.087569646537;
            } else {
              sum += (float)-0.25779056549;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70607197285)) {
              sum += (float)0.0072564883158;
            } else {
              sum += (float)-0.19359341264;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.5403188467)) {
            sum += (float)-0.9983958602;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.32842805982)) {
              sum += (float)-0.35143086314;
            } else {
              sum += (float)0.11882524192;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.7721605301)) {
          sum += (float)1.0132286549;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4631131887)) {
            sum += (float)-0.33479294181;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4467372894)) {
              sum += (float)0.74516224861;
            } else {
              sum += (float)0.0010764295002;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.67192673683)) {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.55943703651)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.74767094851)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3909797668)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3722643852)) {
              sum += (float)0.0020347347017;
            } else {
              sum += (float)4.2037463188;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.23180308938)) {
              sum += (float)-0.041462898254;
            } else {
              sum += (float)-0.22317297757;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75131624937)) {
              sum += (float)-0.54296755791;
            } else {
              sum += (float)45.865409851;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.45212444663)) {
              sum += (float)-5.7191343307;
            } else {
              sum += (float)0.13523156941;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.6779243946)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1839411259)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.405441761)) {
              sum += (float)-0.044162921607;
            } else {
              sum += (float)4.1844768524;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9460072517)) {
              sum += (float)-0.15332004428;
            } else {
              sum += (float)-0.050422888249;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8034563065)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.3063352406)) {
              sum += (float)0.13424360752;
            } else {
              sum += (float)1.0745670795;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.77994704247)) {
              sum += (float)-0.024091374129;
            } else {
              sum += (float)-0.18558618426;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.815325737)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.54828882217)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
            sum += (float)-1.6981927156;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.60362941027)) {
              sum += (float)-0.046353921294;
            } else {
              sum += (float)-0.15970733762;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.0015859499108)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.039710149169)) {
              sum += (float)-0.0047726524062;
            } else {
              sum += (float)0.24659477174;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
              sum += (float)-0.12132517993;
            } else {
              sum += (float)-0.67576706409;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.54828882217)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20723305643)) {
              sum += (float)-0.88779145479;
            } else {
              sum += (float)4.6504368782;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.50258487463)) {
              sum += (float)-0.22681604326;
            } else {
              sum += (float)-0.030298886821;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.90835112333)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4494652748)) {
              sum += (float)-0.13993771374;
            } else {
              sum += (float)3.1274526119;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0424060822)) {
              sum += (float)-0.083208441734;
            } else {
              sum += (float)0.3119969666;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9708147049)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.72382092476)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14954979718)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0547196865)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260761976)) {
              sum += (float)-0.036498527974;
            } else {
              sum += (float)0.12418764085;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
              sum += (float)-0.13027000427;
            } else {
              sum += (float)-0.69127303362;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.79147577286)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0499062538)) {
              sum += (float)-0.34785783291;
            } else {
              sum += (float)-0.84846478701;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.91596806049)) {
              sum += (float)-1.9680653811;
            } else {
              sum += (float)-1.078856349;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.48702913523)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0246363878)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.83262622356)) {
              sum += (float)-0.12405437231;
            } else {
              sum += (float)0.018819436431;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.62594938278)) {
              sum += (float)0.066633313894;
            } else {
              sum += (float)0.78815257549;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.019025249407)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.97447943687)) {
              sum += (float)-0.068448677659;
            } else {
              sum += (float)-0.25040370226;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.4559161663)) {
              sum += (float)-0.37733733654;
            } else {
              sum += (float)-0.055660024285;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96337592602)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.72969615459)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.2263400555)) {
              sum += (float)-0.60729891062;
            } else {
              sum += (float)-0.12911759317;
            }
          } else {
            sum += (float)12.980556488;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.2263400555)) {
            sum += (float)-1.3400176764;
          } else {
            sum += (float)0.038928106427;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2657215595)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.42441046238)) {
            sum += (float)-0.71071153879;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.91297602654)) {
              sum += (float)-0.043799296021;
            } else {
              sum += (float)1.970377326;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.619374156)) {
              sum += (float)-0.53469246626;
            } else {
              sum += (float)-0.069873616099;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9368829727)) {
              sum += (float)-0.01010876894;
            } else {
              sum += (float)0.2973357141;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1666289568)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1522983313)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.97765135765)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.694838047)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.665127039)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6296007633)) {
              sum += (float)-0.00098676688503;
            } else {
              sum += (float)0.068224571645;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3685789108)) {
              sum += (float)0.82297319174;
            } else {
              sum += (float)-0.082200787961;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1658332348)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1351143122)) {
              sum += (float)-0.049136515707;
            } else {
              sum += (float)2.5879905224;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.88996911049)) {
              sum += (float)-1.0825861692;
            } else {
              sum += (float)-0.047627415508;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.97890937328)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.134594202)) {
            sum += (float)-0.63053578138;
          } else {
            sum += (float)4.6711792946;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.72105062008)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.39809197187)) {
              sum += (float)7.573697567;
            } else {
              sum += (float)-0.29824990034;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91510391235)) {
              sum += (float)0.95175033808;
            } else {
              sum += (float)0.021014073864;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4624342918)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.080114603)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
              sum += (float)0.042193718255;
            } else {
              sum += (float)-0.11819434911;
            }
          } else {
            sum += (float)-0.31693866849;
          }
        } else {
          sum += (float)2.2394282818;
        }
      } else {
        sum += (float)2.2905380726;
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.75717818737)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.78175342083)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.063987202942)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.4700548649)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26883900166)) {
              sum += (float)-0.042340867221;
            } else {
              sum += (float)-0.21170164645;
            }
          } else {
            sum += (float)11.925338745;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.5251539946)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.70546865463)) {
              sum += (float)-0.57676231861;
            } else {
              sum += (float)-0.10552445799;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.1195186004)) {
              sum += (float)-0.0044816029258;
            } else {
              sum += (float)-0.07424724102;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.31637555361)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.42083024979)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50921499729)) {
              sum += (float)0.019715663046;
            } else {
              sum += (float)-0.063051350415;
            }
          } else {
            sum += (float)3.1834180355;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.70835495)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.073468051851)) {
              sum += (float)0.17872181535;
            } else {
              sum += (float)-0.26439195871;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.3471188545)) {
              sum += (float)2.6381897926;
            } else {
              sum += (float)-0.36017897725;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4488646984)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6185905933)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.56747198105)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.2672711611)) {
              sum += (float)0.02830660902;
            } else {
              sum += (float)-0.10114018619;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.99941813946)) {
              sum += (float)-0.28902992606;
            } else {
              sum += (float)-0.10524148494;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5253372192)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8207473755)) {
              sum += (float)1.3528718948;
            } else {
              sum += (float)-0.21477112174;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.8808888197)) {
              sum += (float)-0.14747159183;
            } else {
              sum += (float)0.0058737676591;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4606244564)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5613801479)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.025110989809)) {
              sum += (float)-0.015780247748;
            } else {
              sum += (float)-0.58323025703;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7775194645)) {
              sum += (float)0.99220865965;
            } else {
              sum += (float)-0.41311752796;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.10220660269)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.5374641418)) {
              sum += (float)-0.11348544806;
            } else {
              sum += (float)-0.35463732481;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.5743939877)) {
              sum += (float)-0.11485584825;
            } else {
              sum += (float)0.018367128447;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3851313591)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.381622076)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3167032003)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1839411259)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.0556092262)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8553296328)) {
              sum += (float)0.0024739976507;
            } else {
              sum += (float)-0.1020674482;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
              sum += (float)-0.060654718429;
            } else {
              sum += (float)0.8048414588;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52913761139)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57858359814)) {
              sum += (float)-0.00030840886757;
            } else {
              sum += (float)2.8301365376;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
              sum += (float)-0.039788097143;
            } else {
              sum += (float)-0.16661483049;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.5574367046)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.44835034013)) {
              sum += (float)0.52201265097;
            } else {
              sum += (float)-0.20031107962;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
              sum += (float)1.008936882;
            } else {
              sum += (float)-0.11592049897;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.6420764923)) {
            sum += (float)5.497071743;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.45096486807)) {
              sum += (float)0.95030921698;
            } else {
              sum += (float)-0.46616360545;
            }
          }
        }
      }
    } else {
      sum += (float)3.0269732475;
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40524876118)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87039124966)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87536859512)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5467493534)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.89374685287)) {
              sum += (float)-0.16027489305;
            } else {
              sum += (float)-0.031981214881;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
              sum += (float)-0.074678264558;
            } else {
              sum += (float)0.059251423925;
            }
          }
        } else {
          sum += (float)5.7902607918;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1178679466)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.86476612091)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4640866518)) {
              sum += (float)-0.54207831621;
            } else {
              sum += (float)-0.31939399242;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4202225208)) {
              sum += (float)-0.11147169024;
            } else {
              sum += (float)-0.2903496623;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6436371803)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.473023653)) {
              sum += (float)-0.21435938776;
            } else {
              sum += (float)-0.069071263075;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.6682639122)) {
              sum += (float)0.037329696119;
            } else {
              sum += (float)-0.13359108567;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.68001616001)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.56747198105)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.1406288147)) {
              sum += (float)-0.14588548243;
            } else {
              sum += (float)0.18897268176;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.75227642059)) {
              sum += (float)0.083052173257;
            } else {
              sum += (float)-0.04178031534;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4545922279)) {
            sum += (float)6.5595736504;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9343101978)) {
              sum += (float)-0.25110453367;
            } else {
              sum += (float)-2.0787274837;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3440036774)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.0613886118)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0541777611)) {
              sum += (float)0.03072222136;
            } else {
              sum += (float)0.61524432898;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.98257404566)) {
              sum += (float)-0.22414079309;
            } else {
              sum += (float)-0.066146947443;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.98153930902)) {
              sum += (float)2.5765686035;
            } else {
              sum += (float)0.077080249786;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3562912941)) {
              sum += (float)1.9471139908;
            } else {
              sum += (float)0.0011703444179;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.65887725353)) {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.32441049814)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.10892424732)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.4365804195)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26416015625)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26708444953)) {
              sum += (float)-0.004517482128;
            } else {
              sum += (float)0.52375352383;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65969896317)) {
              sum += (float)0.85503232479;
            } else {
              sum += (float)-0.20179355145;
            }
          }
        } else {
          sum += (float)10.136160851;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.15215206146)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26161530614)) {
              sum += (float)0.55420160294;
            } else {
              sum += (float)-0.044266372919;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.17946064472)) {
              sum += (float)5.2074794769;
            } else {
              sum += (float)-1.4233902693;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.17333839834)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.1673912406)) {
              sum += (float)0.019810937345;
            } else {
              sum += (float)0.66934508085;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2732579708)) {
              sum += (float)0.069504976273;
            } else {
              sum += (float)-0.28855440021;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.47002917528)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.81615191698)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.59811246395)) {
            sum += (float)-0.2070081681;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.49342340231)) {
              sum += (float)0.062124110758;
            } else {
              sum += (float)-0.1525259614;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.20680904388)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.19861771166)) {
              sum += (float)-0.1615512073;
            } else {
              sum += (float)-0.43655493855;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.27620065212)) {
              sum += (float)-0.63157200813;
            } else {
              sum += (float)-0.1368548274;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.21966280043)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7400509119)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.34518015385)) {
              sum += (float)-0.062505707145;
            } else {
              sum += (float)-0.41192159057;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52465248108)) {
              sum += (float)36.692020416;
            } else {
              sum += (float)-0.58603262901;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18121095002)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18443804979)) {
              sum += (float)0.15741667151;
            } else {
              sum += (float)4.3185367584;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1296865046)) {
              sum += (float)-0.28122735023;
            } else {
              sum += (float)-0.010725788772;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.63430202007)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.43025898933)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.48056674004)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.5163350105)) {
            sum += (float)0.067924976349;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.3262405396)) {
              sum += (float)-0.22227789462;
            } else {
              sum += (float)0.0039132842794;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.69511389732)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.53733742237)) {
              sum += (float)-0.035439964384;
            } else {
              sum += (float)-0.22792358696;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.34956783056)) {
              sum += (float)-0.038271062076;
            } else {
              sum += (float)-0.08699221164;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.59200340509)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
            sum += (float)-0.17522138357;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.64580965042)) {
              sum += (float)2.2085886002;
            } else {
              sum += (float)0.028551392257;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.41082829237)) {
              sum += (float)-0.28065004945;
            } else {
              sum += (float)1.0036425591;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.52930247784)) {
              sum += (float)-0.6335875988;
            } else {
              sum += (float)0.025956198573;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.3794260025)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.41460114717)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.071345902979)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.16463774443)) {
              sum += (float)-0.0030958077405;
            } else {
              sum += (float)0.066758409142;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.54120278358)) {
              sum += (float)-0.10102991015;
            } else {
              sum += (float)-0.0084960898384;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.22825306654)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.14640815556)) {
              sum += (float)-0.11584813148;
            } else {
              sum += (float)2.5656249523;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.76598769426)) {
              sum += (float)-0.14469522238;
            } else {
              sum += (float)0.25527000427;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.45929551125)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.012635200284)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.43965354562)) {
              sum += (float)-0.061746496707;
            } else {
              sum += (float)-0.15166386962;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.49868887663)) {
              sum += (float)-0.064419783652;
            } else {
              sum += (float)-0.0096272164956;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.47158312798)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.71264505386)) {
              sum += (float)0.0052386112511;
            } else {
              sum += (float)0.44347372651;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1666289568)) {
              sum += (float)0.0016764544416;
            } else {
              sum += (float)-0.029313502833;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3713860512)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3291018009)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3279497623)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0389993191)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6296007633)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3851313591)) {
              sum += (float)-0.00024028848566;
            } else {
              sum += (float)-0.09874676913;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6313552856)) {
              sum += (float)2.9636604786;
            } else {
              sum += (float)0.014134958386;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1132760048)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
              sum += (float)-0.39151957631;
            } else {
              sum += (float)-0.15300239623;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
              sum += (float)0.038050837815;
            } else {
              sum += (float)-0.070617705584;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.091015353799)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.088007003069)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.16772845387)) {
              sum += (float)0.12224595249;
            } else {
              sum += (float)-0.11813268811;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7775194645)) {
              sum += (float)53.080276489;
            } else {
              sum += (float)-14.127354622;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4423046112)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6098179817)) {
              sum += (float)-0.02430174686;
            } else {
              sum += (float)4.8663392067;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.356564045)) {
              sum += (float)1.0166330338;
            } else {
              sum += (float)0.040394276381;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.3713243008)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5283179283)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.11377679557)) {
            sum += (float)0.29530796409;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.6237167716)) {
              sum += (float)0.08296405524;
            } else {
              sum += (float)-0.03364681825;
            }
          }
        } else {
          sum += (float)-0.32222604752;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.516825676)) {
          sum += (float)12.996281624;
        } else {
          sum += (float)-0.75696915388;
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.4136703014)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.28423565626)) {
        sum += (float)-1.3225755692;
      } else {
        sum += (float)0.20370350778;
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1719770432)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1351143122)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.054395496845)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.2300029397)) {
              sum += (float)0.076839581132;
            } else {
              sum += (float)0.66097027063;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0599517822)) {
              sum += (float)-0.058669738472;
            } else {
              sum += (float)-0.44265881181;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4991779327)) {
            sum += (float)3.9390926361;
          } else {
            sum += (float)-0.71553426981;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70826929808)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.7041670084)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.19548630714)) {
              sum += (float)-0.56705641747;
            } else {
              sum += (float)-0.1212053895;
            }
          } else {
            sum += (float)-1.2625882626;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72057616711)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0974056721)) {
              sum += (float)-0.54939043522;
            } else {
              sum += (float)18.123680115;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.75268316269)) {
              sum += (float)-0.63811928034;
            } else {
              sum += (float)-0.029388085008;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.99695926905)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57420778275)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70898079872)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.5353320837)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14657625556)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1227273941)) {
              sum += (float)-0.00045367926941;
            } else {
              sum += (float)-0.05889018625;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.88537824154)) {
              sum += (float)0.78522604704;
            } else {
              sum += (float)-0.20241419971;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.01211379841)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0547196865)) {
              sum += (float)0.012105984613;
            } else {
              sum += (float)-0.23402942717;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.80515110493)) {
              sum += (float)-0.60929626226;
            } else {
              sum += (float)-1.3814547062;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.23608709872)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70624601841)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260761976)) {
              sum += (float)0.7874930501;
            } else {
              sum += (float)-0.014963299967;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.01211379841)) {
              sum += (float)0.015439511277;
            } else {
              sum += (float)0.68917059898;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20216549933)) {
            sum += (float)6.5111327171;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.9774338007)) {
              sum += (float)-0.56994897127;
            } else {
              sum += (float)-0.036783423275;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57114481926)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.99533116817)) {
          sum += (float)-0.11722972989;
        } else {
          sum += (float)-1.2914938927;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.7837306261)) {
          sum += (float)0.74720746279;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2554895878)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3765546083)) {
              sum += (float)0.11085468531;
            } else {
              sum += (float)-0.18329137564;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.36748328805)) {
              sum += (float)-0.020091120154;
            } else {
              sum += (float)-0.12057804316;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0636570454)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77675032616)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.79370629787)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0718450546)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5948765278)) {
              sum += (float)0.46793115139;
            } else {
              sum += (float)-0.097284071147;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
              sum += (float)1.8524413109;
            } else {
              sum += (float)-0.0036826187279;
            }
          }
        } else {
          sum += (float)2.0215528011;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.62660741806)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.80026644468)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7685457468)) {
              sum += (float)-0.3361094892;
            } else {
              sum += (float)-0.18391266465;
            }
          } else {
            sum += (float)-0.53018349409;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55949437618)) {
            sum += (float)-0.12097292393;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.56543034315)) {
              sum += (float)0.04673198238;
            } else {
              sum += (float)-0.018653329462;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.9738188982)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3011611104)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.90309458971)) {
            sum += (float)-0.12007782608;
          } else {
            sum += (float)4.991300106;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.60276389122)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25521576405)) {
              sum += (float)-1.1041291952;
            } else {
              sum += (float)-0.11404880136;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.59384310246)) {
              sum += (float)5.193230629;
            } else {
              sum += (float)-0.09344227612;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4645698071)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1813428402)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5596710443)) {
              sum += (float)0.13434019685;
            } else {
              sum += (float)-0.12255118042;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.54489058256)) {
              sum += (float)-0.20303012431;
            } else {
              sum += (float)-0.57779949903;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0402629375)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.81856167316)) {
              sum += (float)0.068477615714;
            } else {
              sum += (float)-0.13093332946;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.85954260826)) {
              sum += (float)0.039434880018;
            } else {
              sum += (float)-3.6486246245e-05;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.85547912121)) {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.92920482159)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.65384459496)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1135189533)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6033332348)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6374812126)) {
              sum += (float)-0.027057416737;
            } else {
              sum += (float)0.40818294883;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.081100344658)) {
              sum += (float)-0.026464387774;
            } else {
              sum += (float)0.030028892681;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5381851196)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5456238985)) {
              sum += (float)-0.33198854327;
            } else {
              sum += (float)7.9312930107;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.95448100567)) {
              sum += (float)-0.029907597229;
            } else {
              sum += (float)-0.1510527581;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.5320237875)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1182222366)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.57003939152)) {
              sum += (float)0.02729367651;
            } else {
              sum += (float)0.3527264595;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.17576339841)) {
              sum += (float)6.0634307861;
            } else {
              sum += (float)0.019276017323;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.47178375721)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18328940868)) {
              sum += (float)-0.23935730755;
            } else {
              sum += (float)-0.069135636091;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.46418058872)) {
              sum += (float)0.77812558413;
            } else {
              sum += (float)-0.0026260134764;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18782925606)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.31046965718)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.27702701092)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.27408733964)) {
              sum += (float)-0.093530446291;
            } else {
              sum += (float)0.35472300649;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.37663784623)) {
              sum += (float)-0.012787641026;
            } else {
              sum += (float)0.3680190742;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20625948906)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773935556)) {
              sum += (float)-3.5962116718;
            } else {
              sum += (float)-0.77432632446;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.13666173816)) {
              sum += (float)-0.31698310375;
            } else {
              sum += (float)0.21364732087;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.17984350026)) {
          sum += (float)3.0600717068;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.24807825685)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.12576119602)) {
              sum += (float)0.035956688225;
            } else {
              sum += (float)8.6157808304;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.1910533011)) {
              sum += (float)-0.21619349718;
            } else {
              sum += (float)-0.050872482359;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.83090376854)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.38569313288)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4472786188)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6634178162)) {
              sum += (float)-0.0063734943978;
            } else {
              sum += (float)-0.12814003229;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.97524368763)) {
              sum += (float)0.10908770561;
            } else {
              sum += (float)-0.010534073226;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.46597954631)) {
            sum += (float)-0.20071260631;
          } else {
            sum += (float)0.015778562054;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.54430574179)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.14350655675)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
              sum += (float)0.31632623076;
            } else {
              sum += (float)-0.13622054458;
            }
          } else {
            sum += (float)1.2703404427;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.12621539831)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.30274924636)) {
              sum += (float)-0.22183524072;
            } else {
              sum += (float)-0.088310010731;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.29889950156)) {
              sum += (float)-0.065029926598;
            } else {
              sum += (float)0.066693142056;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.81861621141)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.98338103294)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.80054330826)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1864767075)) {
              sum += (float)-0.073070816696;
            } else {
              sum += (float)-0.11767307669;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70205450058)) {
              sum += (float)-0.027678813785;
            } else {
              sum += (float)0.24253682792;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.42908930779)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773507148)) {
              sum += (float)-0.13634873927;
            } else {
              sum += (float)-0.33356824517;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.1550383568)) {
              sum += (float)-0.052856944501;
            } else {
              sum += (float)0.14721210301;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4256823063)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
            sum += (float)1.5634361506;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0474996567)) {
              sum += (float)-0.044251997024;
            } else {
              sum += (float)-0.25009328127;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4169095755)) {
            sum += (float)1.9861694574;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7893840075)) {
              sum += (float)-0.17847242951;
            } else {
              sum += (float)0.0033032118808;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7863577604)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7104598284)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7249196768)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.46295392513)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.43954366446)) {
              sum += (float)0.0019449341344;
            } else {
              sum += (float)0.24480740726;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70465928316)) {
              sum += (float)-0.050328213722;
            } else {
              sum += (float)-0.0019038224127;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
              sum += (float)20.495138168;
            } else {
              sum += (float)0.38391456008;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
              sum += (float)-0.12408438325;
            } else {
              sum += (float)-0.21536381543;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5123929977)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7003444433)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.51940155029)) {
              sum += (float)-0.056141644716;
            } else {
              sum += (float)0.011562136933;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
              sum += (float)-0.25911781192;
            } else {
              sum += (float)-0.025055661798;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5988488197)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5143842697)) {
              sum += (float)-1.1253100634;
            } else {
              sum += (float)-0.35351079702;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6819130182)) {
              sum += (float)0.01818619296;
            } else {
              sum += (float)-0.51010745764;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2272713184)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.134594202)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7342915535)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2589046955)) {
              sum += (float)-0.20830798149;
            } else {
              sum += (float)-0.34301427007;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
              sum += (float)-0.058252666146;
            } else {
              sum += (float)-0.31426596642;
            }
          }
        } else {
          sum += (float)-0.48595201969;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2949919701)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2674307823)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0468428135)) {
              sum += (float)0.31611725688;
            } else {
              sum += (float)5.6783332825;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.6420764923)) {
              sum += (float)0.034725207835;
            } else {
              sum += (float)-0.17168067396;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.3334543705)) {
              sum += (float)-0.023630289361;
            } else {
              sum += (float)0.44740590453;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3882997036)) {
              sum += (float)0.63188660145;
            } else {
              sum += (float)-0.0096003971994;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4764323235)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.74846887589)) {
        sum += (float)-1.1922889948;
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.66790920496)) {
          sum += (float)-0.16321767867;
        } else {
          sum += (float)0.004335728474;
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.21192085743)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.58956474066)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73807907104)) {
              sum += (float)-0.46775266528;
            } else {
              sum += (float)-0.19391842186;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.21676389873)) {
              sum += (float)-0.077056437731;
            } else {
              sum += (float)-0.02802577801;
            }
          }
        } else {
          sum += (float)-1.1159691811;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49161559343)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6988897324)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.22334624827)) {
              sum += (float)-1.1246439219;
            } else {
              sum += (float)2.7010936737;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
              sum += (float)-0.00042337385821;
            } else {
              sum += (float)-0.31552711129;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.14636899531)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.8296177387)) {
              sum += (float)-0.084283255041;
            } else {
              sum += (float)-0.60423469543;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.9473814964)) {
              sum += (float)-0.026304962113;
            } else {
              sum += (float)-0.32481974363;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.74136090279)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73835259676)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70826929808)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.57885658741)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.57847368717)) {
              sum += (float)0.00089284876594;
            } else {
              sum += (float)2.5101075172;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3881340027)) {
              sum += (float)-0.046853132546;
            } else {
              sum += (float)1.2136901617;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.6334309578)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.72031533718)) {
              sum += (float)0.69490379095;
            } else {
              sum += (float)-0.025777675211;
            }
          } else {
            sum += (float)15.406078339;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.73911833763)) {
          sum += (float)3.4239954948;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.88887107372)) {
            sum += (float)0.039196502417;
          } else {
            sum += (float)0.20830306411;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.85704469681)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6757692099)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.5574367046)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.77117073536)) {
              sum += (float)-0.005615697708;
            } else {
              sum += (float)-0.089954666793;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
              sum += (float)-0.25574728847;
            } else {
              sum += (float)-2.4270920753;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.2129426003)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.24004325271)) {
              sum += (float)-0.14044103026;
            } else {
              sum += (float)-0.25963822007;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.74611949921)) {
              sum += (float)-0.71136707067;
            } else {
              sum += (float)0.085069157183;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.86027187109)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.63175177574)) {
              sum += (float)0.13048388064;
            } else {
              sum += (float)4.6961622238;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2628521919)) {
              sum += (float)-0.067482985556;
            } else {
              sum += (float)0.19072051346;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.8685311079)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)-0.49519786239;
            } else {
              sum += (float)-0.084253057837;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.98041772842)) {
              sum += (float)-0.30515217781;
            } else {
              sum += (float)-0.0048899473622;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
        sum += (float)16.406095505;
      } else {
        sum += (float)-2.0835485458;
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359526873)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.152279377)) {
            sum += (float)-0.1530572474;
          } else {
            sum += (float)0.16415216029;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.21192076802)) {
            sum += (float)-0.86579507589;
          } else {
            sum += (float)-0.4239500463;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2270498276)) {
            sum += (float)0.91229110956;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.6739474535)) {
              sum += (float)-0.44579026103;
            } else {
              sum += (float)0.16303765774;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.39070248604)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3931541443)) {
              sum += (float)0.074857026339;
            } else {
              sum += (float)-0.11789458245;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2226743698)) {
              sum += (float)-0.45961382985;
            } else {
              sum += (float)-0.11156775802;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3279497623)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.52597904205)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44409936666)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26864284277)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.2487577498)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.76458466053)) {
              sum += (float)0.0031851802487;
            } else {
              sum += (float)-0.064033858478;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
              sum += (float)0.0053334590048;
            } else {
              sum += (float)3.2133677006;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.40688073635)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.091309502721)) {
              sum += (float)-0.059249632061;
            } else {
              sum += (float)0.26036345959;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.73780608177)) {
              sum += (float)-0.036445971578;
            } else {
              sum += (float)-0.092741794884;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44643878937)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808881402)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.98399662971)) {
              sum += (float)4.9801015854;
            } else {
              sum += (float)-0.093347474933;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180945933)) {
              sum += (float)1.2479815483;
            } else {
              sum += (float)-0.11049057543;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.51135766506)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.013783350587)) {
              sum += (float)0.14043773711;
            } else {
              sum += (float)-0.050134636462;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.12956574559)) {
              sum += (float)-0.064256802201;
            } else {
              sum += (float)0.55623781681;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.70085072517)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.064186647534)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.52273803949)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1273925304)) {
              sum += (float)-0.34876585007;
            } else {
              sum += (float)-0.055168025196;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.56345450878)) {
              sum += (float)-0.14130619168;
            } else {
              sum += (float)-0.25170212984;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.69692987204)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.026856400073)) {
              sum += (float)0.068061046302;
            } else {
              sum += (float)-0.041604612023;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7451703548)) {
              sum += (float)-0.12840081751;
            } else {
              sum += (float)-0.82923525572;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.091633096337)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.73828148842)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.71839642525)) {
              sum += (float)0.062584087253;
            } else {
              sum += (float)0.63280302286;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.074341952801)) {
              sum += (float)-0.02923380211;
            } else {
              sum += (float)0.6376478076;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.83653712273)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2334151268)) {
              sum += (float)-0.11957906932;
            } else {
              sum += (float)-0.0076427068561;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.88157099485)) {
              sum += (float)0.13573490083;
            } else {
              sum += (float)-0.0086112422869;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0821763277)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0728186369)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.99971175194)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.057250902057)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.0085380002856)) {
              sum += (float)0.036494035274;
            } else {
              sum += (float)0.38963016868;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.85725986958)) {
              sum += (float)-0.044185318053;
            } else {
              sum += (float)-0.16241133213;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5527346134)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8892965317)) {
              sum += (float)5.1352329254;
            } else {
              sum += (float)13.945179939;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0611214638)) {
              sum += (float)0.020974572748;
            } else {
              sum += (float)-1.0027612448;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7775194645)) {
          sum += (float)42.463001251;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.025488950312)) {
            sum += (float)-0.70409405231;
          } else {
            sum += (float)-12.009165764;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1909593344)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2641341686)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1295495033)) {
            sum += (float)-0.18012131751;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.165810585)) {
              sum += (float)-1.80134939e-05;
            } else {
              sum += (float)-0.080871887505;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3440036774)) {
            sum += (float)-1.4700715542;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.405441761)) {
              sum += (float)-0.29187944531;
            } else {
              sum += (float)-0.72778302431;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1904084682)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.52941060066)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1351143122)) {
              sum += (float)-0.14185039699;
            } else {
              sum += (float)2.84146595;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
              sum += (float)0.21944196522;
            } else {
              sum += (float)-0.12156675011;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9120857716)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.20188049972)) {
              sum += (float)-0.79373687506;
            } else {
              sum += (float)-0.031079486012;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9173493385)) {
              sum += (float)1.2104299068;
            } else {
              sum += (float)0.025389658287;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.4084216356)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0018820763)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5864195824)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.7647624016)) {
              sum += (float)-0.6938790679;
            } else {
              sum += (float)-0.17635130882;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
              sum += (float)0.21474763751;
            } else {
              sum += (float)-0.0013422783231;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32089108229)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.59986704588)) {
              sum += (float)-0.069906927645;
            } else {
              sum += (float)-0.27899992466;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.44752991199)) {
              sum += (float)0.011670248583;
            } else {
              sum += (float)0.061729859561;
            }
          }
        }
      } else {
        sum += (float)-2.0757391453;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0815752745)) {
        sum += (float)4.9064583778;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.111810565)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.95063537359)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1157608032)) {
              sum += (float)-0.30527245998;
            } else {
              sum += (float)-0.055351600051;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1399607658)) {
              sum += (float)-0.28018352389;
            } else {
              sum += (float)-0.61977398396;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5778670311)) {
            sum += (float)-0.7256680131;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.6375668049)) {
              sum += (float)0.24415609241;
            } else {
              sum += (float)0.028653932735;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.371781826)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3706121445)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3501420021)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3460481167)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.97600585222)) {
              sum += (float)-0.00090601411648;
            } else {
              sum += (float)0.013572404161;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.1665701866)) {
              sum += (float)-0.35201445222;
            } else {
              sum += (float)10.94849205;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9213657379)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
              sum += (float)-0.08714992553;
            } else {
              sum += (float)0.036082904786;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.30777233839)) {
              sum += (float)-0.015098507516;
            } else {
              sum += (float)-0.46200236678;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3460154533)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.7425043583)) {
              sum += (float)-0.49128782749;
            } else {
              sum += (float)1.2129956484;
            }
          } else {
            sum += (float)3.1840820312;
          }
        } else {
          sum += (float)-0.82922393084;
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6150815487)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.5369266272)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3317160606)) {
              sum += (float)-0.016732318327;
            } else {
              sum += (float)-0.3152410388;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6091265678)) {
              sum += (float)0.57748794556;
            } else {
              sum += (float)0.025324864313;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7342915535)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.19105798006;
            } else {
              sum += (float)1.5899795294;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3881340027)) {
              sum += (float)-0.094106443226;
            } else {
              sum += (float)3.6493287086;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.20413661)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.8477958441)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6757493019)) {
              sum += (float)-0.24408514798;
            } else {
              sum += (float)-0.074628733099;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.513767004)) {
              sum += (float)1.7263988256;
            } else {
              sum += (float)-0.034870997071;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.415060997)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
              sum += (float)-0.54937189817;
            } else {
              sum += (float)2.9105086327;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.10841695964;
            } else {
              sum += (float)0.090802118182;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.4335923195)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
      sum += (float)1.249725461;
    } else {
      sum += (float)0.053319707513;
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4118354321)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14657625556)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17272660136)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7048155069)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.8276836872)) {
              sum += (float)-0.031783886254;
            } else {
              sum += (float)0.11019960791;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6879017353)) {
              sum += (float)-0.88121527433;
            } else {
              sum += (float)-0.030154751614;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.57897531986)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
              sum += (float)-0.89500969648;
            } else {
              sum += (float)-0.42367982864;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
              sum += (float)-0.029476286843;
            } else {
              sum += (float)0.027958920226;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.28930771351)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.095413684845)) {
            sum += (float)-0.020526628941;
          } else {
            sum += (float)-0.45289167762;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.58666485548)) {
              sum += (float)-0.016905661672;
            } else {
              sum += (float)-0.27641350031;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4614454508)) {
              sum += (float)0.064637742937;
            } else {
              sum += (float)-0.0699807778;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4096474648)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4991519451)) {
          sum += (float)3.1331782341;
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.93910837173)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.69401949644)) {
              sum += (float)-0.0015371359186;
            } else {
              sum += (float)0.018246915191;
            }
          } else {
            sum += (float)0.070136748254;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2551288605)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2942371368)) {
              sum += (float)-0.037315886468;
            } else {
              sum += (float)0.18962232769;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.019025249407)) {
              sum += (float)1.3792481422;
            } else {
              sum += (float)0.063953533769;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0031405687)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0147362947)) {
              sum += (float)-0.017372101545;
            } else {
              sum += (float)-0.17892147601;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0021011829)) {
              sum += (float)0.28101727366;
            } else {
              sum += (float)0.0010982330423;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.8247974515)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57420778275)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60341590643)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.62042665482)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.59261202812)) {
              sum += (float)0.0013642357662;
            } else {
              sum += (float)0.18745239079;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2916584015)) {
              sum += (float)-0.045811917633;
            } else {
              sum += (float)-0.17601963878;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60177499056)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4645698071)) {
              sum += (float)-0.346960783;
            } else {
              sum += (float)3.3231592178;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1879115105)) {
              sum += (float)-0.055021811277;
            } else {
              sum += (float)0.39564201236;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.35055240989)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.36821943521)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1242311001)) {
              sum += (float)-0.017564853653;
            } else {
              sum += (float)-0.10633406043;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.49944204092)) {
              sum += (float)-0.23993326724;
            } else {
              sum += (float)-0.86090630293;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70205450058)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.3737988472)) {
              sum += (float)0.026057165116;
            } else {
              sum += (float)0.28904488683;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.97177219391)) {
              sum += (float)-0.027594929561;
            } else {
              sum += (float)-0.21990297735;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.904941082)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0990782976)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.92854428291)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.54938989878)) {
              sum += (float)-0.45998564363;
            } else {
              sum += (float)0.51960808039;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.35832184553)) {
              sum += (float)-0.026047477499;
            } else {
              sum += (float)0.17538940907;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.083361148834)) {
            sum += (float)4.8514294624;
          } else {
            sum += (float)0.017159482464;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.99116194248)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
            sum += (float)-1.3105268478;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.3147249222)) {
              sum += (float)-0.75102376938;
            } else {
              sum += (float)-0.0025168431457;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.96228194237)) {
            sum += (float)9.4383230209;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.56906628609)) {
              sum += (float)-1.0514948368;
            } else {
              sum += (float)0.10241862386;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50796997547)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.20795309544)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.61703544855)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.61796534061)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1503818035)) {
              sum += (float)0.075635328889;
            } else {
              sum += (float)-0.041841261089;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0152180195)) {
              sum += (float)1.7376638651;
            } else {
              sum += (float)-0.0051129218191;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57256686687)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.27960890532)) {
              sum += (float)-0.14298157394;
            } else {
              sum += (float)-0.308203578;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0897455215)) {
              sum += (float)-0.095678292215;
            } else {
              sum += (float)0.22978614271;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.25636088848)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.24758805335)) {
              sum += (float)0.017210928723;
            } else {
              sum += (float)0.46508160233;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.78149837255)) {
              sum += (float)5.3790559769;
            } else {
              sum += (float)-0.03733670339;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1304109097)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
              sum += (float)-0.065637767315;
            } else {
              sum += (float)0.59046489;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6988897324)) {
              sum += (float)2.0680451393;
            } else {
              sum += (float)-0.0035985177383;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49982008338)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50031232834)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3931541443)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.29574233294)) {
              sum += (float)0.51147574186;
            } else {
              sum += (float)-0.025458347052;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405244946)) {
              sum += (float)3.5110356808;
            } else {
              sum += (float)-0.90440112352;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.12450620532)) {
            sum += (float)2.6293034554;
          } else {
            sum += (float)-0.42609879375;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.49128741026)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.60317993164)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.65188604593)) {
              sum += (float)1.4587862492;
            } else {
              sum += (float)-0.07949873805;
            }
          } else {
            sum += (float)3.7730650902;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.42373675108)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
              sum += (float)0.058210130781;
            } else {
              sum += (float)-0.08284959197;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3508259058)) {
              sum += (float)0.086444683373;
            } else {
              sum += (float)-0.0026229543146;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.4575721025)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0018820763)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.5116560459)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
              sum += (float)-0.068264484406;
            } else {
              sum += (float)-0.38494953513;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
              sum += (float)0.36614155769;
            } else {
              sum += (float)-0.0066946297884;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1135187149)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.19103941321)) {
              sum += (float)0.089310109615;
            } else {
              sum += (float)-0.028128201142;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0355060101)) {
              sum += (float)-0.044475071132;
            } else {
              sum += (float)-0.26247528195;
            }
          }
        }
      } else {
        sum += (float)-1.5092126131;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0815752745)) {
        sum += (float)3.6451897621;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2760763168)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.1451427937)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.66010713577)) {
              sum += (float)-0.12918278575;
            } else {
              sum += (float)0.026233416051;
            }
          } else {
            sum += (float)-0.54296028614;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.43288272619)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9792537689)) {
              sum += (float)0.087120600045;
            } else {
              sum += (float)-0.059006903321;
            }
          } else {
            sum += (float)-0.33931142092;
          }
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.21917310357)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.22512024641)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.005962499883)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.094552204013)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.099230997264)) {
              sum += (float)0.0021979699377;
            } else {
              sum += (float)0.75979167223;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.98612976074)) {
              sum += (float)0.11513731629;
            } else {
              sum += (float)-0.069575764239;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.020381849259)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.16102729738)) {
              sum += (float)1.4740839005;
            } else {
              sum += (float)-0.45203387737;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.6498542428)) {
              sum += (float)0.078262321651;
            } else {
              sum += (float)-0.003245780943;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.19378140569)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.3162646294)) {
              sum += (float)0.078709691763;
            } else {
              sum += (float)-0.13116385043;
            }
          } else {
            sum += (float)-0.94292145967;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.47707509995)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42772346735)) {
              sum += (float)0.091493614018;
            } else {
              sum += (float)-0.017565719783;
            }
          } else {
            sum += (float)25.204458237;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.11212450266)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96906960011)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.96312659979)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.71008944511)) {
              sum += (float)0.18143486977;
            } else {
              sum += (float)-0.027375387028;
            }
          } else {
            sum += (float)0.36456367373;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8765940666)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.51458978653)) {
              sum += (float)-0.041571490467;
            } else {
              sum += (float)-0.11921146512;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5102572441)) {
              sum += (float)0.3127912879;
            } else {
              sum += (float)-0.19673588872;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.67004954815)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68642550707)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.072235703468)) {
              sum += (float)-0.12214808911;
            } else {
              sum += (float)0.24147483706;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.062666103244)) {
              sum += (float)0.24182012677;
            } else {
              sum += (float)-0.41064098477;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.82530319691)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1442379951)) {
              sum += (float)0.28370329738;
            } else {
              sum += (float)-0.058798566461;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.79021519423)) {
              sum += (float)0.20586960018;
            } else {
              sum += (float)-0.0010212156922;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.25246310234)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30334544182)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30568486452)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.61236131191)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.10892424732)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.11762654781)) {
              sum += (float)0.0021306176204;
            } else {
              sum += (float)-0.067561432719;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.23332825303)) {
              sum += (float)-0.011270442978;
            } else {
              sum += (float)0.23299913108;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94785583019)) {
            sum += (float)-4.0065937042;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.83515226841)) {
              sum += (float)-0.68583369255;
            } else {
              sum += (float)-0.043284706771;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.67953193188)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.74073463678)) {
              sum += (float)-0.24527917802;
            } else {
              sum += (float)-0.60690867901;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.74073463678)) {
              sum += (float)0.52757102251;
            } else {
              sum += (float)-0.507119596;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
            sum += (float)28.277357101;
          } else {
            sum += (float)-4.0774726868;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63864064217)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71751356125)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.29866659641)) {
            sum += (float)-0.30693134665;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.74103319645)) {
              sum += (float)-0.025163330138;
            } else {
              sum += (float)-0.20863197744;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.36662054062)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.087104797363)) {
              sum += (float)0.024992149323;
            } else {
              sum += (float)-0.21187336743;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050442934)) {
              sum += (float)0.30754885077;
            } else {
              sum += (float)-0.26785549521;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.3933826983)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.193652153)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.6815366745)) {
              sum += (float)0.77305185795;
            } else {
              sum += (float)0.11682461202;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26416015625)) {
              sum += (float)-0.043728880584;
            } else {
              sum += (float)-0.19799278677;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.29866659641)) {
            sum += (float)-0.30300927162;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26768666506)) {
              sum += (float)-0.092160314322;
            } else {
              sum += (float)-0.1971128732;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.079930797219)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.081100553274)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2497713566)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.34064549208)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2143182755)) {
              sum += (float)0.28373548388;
            } else {
              sum += (float)-0.052671153098;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.7972048521)) {
              sum += (float)0.030912069604;
            } else {
              sum += (float)0.42555394769;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.8892257214)) {
              sum += (float)10.326633453;
            } else {
              sum += (float)-0.43272486329;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1600658894)) {
              sum += (float)-0.013206978329;
            } else {
              sum += (float)1.4658112526;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.289401263)) {
          sum += (float)3.5952737331;
        } else {
          sum += (float)-0.80774480104;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.069792099297)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3747227192)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.61289072037)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.067452654243)) {
              sum += (float)-0.02995265089;
            } else {
              sum += (float)-0.34424555302;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.25646859407)) {
              sum += (float)-0.17758534849;
            } else {
              sum += (float)-0.091974526644;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.97108817101)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0081726313)) {
              sum += (float)-0.15097402036;
            } else {
              sum += (float)2.307312727;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.79009890556)) {
              sum += (float)-0.2176707238;
            } else {
              sum += (float)-0.50579041243;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.023098850623)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.067520901561)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20196935534)) {
              sum += (float)0.076171994209;
            } else {
              sum += (float)-0.0094948653132;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.39447396994)) {
              sum += (float)4.4815392494;
            } else {
              sum += (float)0.12706646323;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.17333839834)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.53592169285)) {
              sum += (float)-0.091447323561;
            } else {
              sum += (float)-0.0015633029398;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1361086369)) {
              sum += (float)0.21603426337;
            } else {
              sum += (float)0.00085404200945;
            }
          }
        }
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.79192435741)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8062269688)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7734749317)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2390909195)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.74869656563)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.32482844591)) {
              sum += (float)0.0008210343658;
            } else {
              sum += (float)-0.02443446964;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.76598763466)) {
              sum += (float)-0.27369764447;
            } else {
              sum += (float)-0.090352796018;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)4.380068779)) {
              sum += (float)4.8349895477;
            } else {
              sum += (float)0.027573032305;
            }
          } else {
            sum += (float)-0.1763253212;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7451703548)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.7730731964)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
              sum += (float)-0.12705121934;
            } else {
              sum += (float)0.0030937844422;
            }
          } else {
            sum += (float)-0.41028669477;
          }
        } else {
          sum += (float)-2.045576334;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8103208542)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1905374527)) {
          sum += (float)0.038255129009;
        } else {
          sum += (float)2.290979147;
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.70538669825)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8606183529)) {
              sum += (float)-0.1806846261;
            } else {
              sum += (float)0.023391917348;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0343203545)) {
              sum += (float)3.3687593937;
            } else {
              sum += (float)-1.7497185469;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.863542676)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.85403639078)) {
              sum += (float)-0.29977303743;
            } else {
              sum += (float)-1.1885564327;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40470176935)) {
              sum += (float)-0.25360554457;
            } else {
              sum += (float)-0.0098263695836;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94785583019)) {
      sum += (float)-3.2052750587;
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.5336227417)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.53717803955)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.66276204586)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.9976979494)) {
              sum += (float)0.10037340969;
            } else {
              sum += (float)-0.64995497465;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.055626600981)) {
              sum += (float)-1.0912567377;
            } else {
              sum += (float)-0.10949248821;
            }
          }
        } else {
          sum += (float)22.621887207;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.47646450996)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.78149837255)) {
            sum += (float)-3.0289797783;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.35656732321)) {
              sum += (float)-0.25995457172;
            } else {
              sum += (float)-0.06361502409;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.64607053995)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
              sum += (float)-0.35542014241;
            } else {
              sum += (float)0.14174607396;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.091015353799)) {
              sum += (float)0.062628954649;
            } else {
              sum += (float)0.0020086120348;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.65887725353)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.39932984114)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38743555546)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20840275288)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.32566481829)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.13914854825)) {
              sum += (float)-0.002126716543;
            } else {
              sum += (float)0.13288582861;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.64017176628)) {
              sum += (float)-0.13952840865;
            } else {
              sum += (float)-0.011831198819;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.78175342083)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.79404103756)) {
              sum += (float)0.022273745388;
            } else {
              sum += (float)-0.42128005624;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.3471188545)) {
              sum += (float)0.679649055;
            } else {
              sum += (float)-0.18258047104;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.31913655996)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.13486094773)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418972969)) {
              sum += (float)-0.068163186312;
            } else {
              sum += (float)-0.4249843657;
            }
          } else {
            sum += (float)2.7250490189;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.099431201816)) {
            sum += (float)-0.16095849872;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.75202679634)) {
              sum += (float)-0.0052804909647;
            } else {
              sum += (float)0.061341952533;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.1910533011)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15769129992)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.19050940871)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.22497490048)) {
              sum += (float)-0.023009048775;
            } else {
              sum += (float)-0.86964523792;
            }
          } else {
            sum += (float)2.1582832336;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.18319779634)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
              sum += (float)-0.099428676069;
            } else {
              sum += (float)0.022714683786;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
              sum += (float)-0.44401890039;
            } else {
              sum += (float)-0.21242311597;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.146227479)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.16356509924)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.81615191698)) {
              sum += (float)8.7775154114;
            } else {
              sum += (float)0.64251726866;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2052025795)) {
              sum += (float)-0.6365903616;
            } else {
              sum += (float)0.05008161068;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773507148)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.020381852984)) {
              sum += (float)0.0027472970542;
            } else {
              sum += (float)1.2868629694;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.27319008112)) {
              sum += (float)-0.044700153172;
            } else {
              sum += (float)0.015670828521;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.63430202007)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.32386028767)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.37308749557)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.47630172968)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.48056674004)) {
              sum += (float)0.02790154703;
            } else {
              sum += (float)-0.066608965397;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47032904625)) {
              sum += (float)-0.20453901589;
            } else {
              sum += (float)0.11251533031;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.048405248672)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
              sum += (float)-0.58803659678;
            } else {
              sum += (float)1.1201564074;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.48109260201)) {
              sum += (float)-0.78897583485;
            } else {
              sum += (float)0.25123733282;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.020759349689)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.68456476927)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.54489064217)) {
              sum += (float)0.031621303409;
            } else {
              sum += (float)-0.080451108515;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.16773405671)) {
              sum += (float)-0.25460830331;
            } else {
              sum += (float)-0.16265790164;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.66142445803)) {
              sum += (float)0.0064641749486;
            } else {
              sum += (float)-0.055242426693;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.0010060500354)) {
              sum += (float)0.022069882601;
            } else {
              sum += (float)0.055948764086;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.60972678661)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.83470243216)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.42016485333)) {
            sum += (float)-0.25147917867;
          } else {
            sum += (float)-0.051645897329;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.4261713028)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.75764834881)) {
              sum += (float)0.0075175915845;
            } else {
              sum += (float)-0.055220540613;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.41882497072)) {
              sum += (float)-0.18003481627;
            } else {
              sum += (float)-0.55689591169;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.081100344658)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.046696051955)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.17928555608)) {
              sum += (float)-0.0022027366795;
            } else {
              sum += (float)0.040517088026;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.40688073635)) {
              sum += (float)1.734484911;
            } else {
              sum += (float)0.021337497979;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.822696805)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.35793665051)) {
              sum += (float)0.17955641448;
            } else {
              sum += (float)-0.37986001372;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72502595186)) {
              sum += (float)0.18973459303;
            } else {
              sum += (float)-0.0042141904123;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42596885562)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.39204722643)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.71210157871)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.6116643548)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.43774145842)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.35286200047)) {
              sum += (float)0.0014350183774;
            } else {
              sum += (float)0.09614828229;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
              sum += (float)0.028963346034;
            } else {
              sum += (float)-0.040089052171;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.210157305)) {
              sum += (float)0.049981232733;
            } else {
              sum += (float)0.6653907299;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.6460044384)) {
              sum += (float)-0.1789021343;
            } else {
              sum += (float)-0.0042531546205;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64312577248)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65707355738)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.73299276829)) {
              sum += (float)-0.061665285379;
            } else {
              sum += (float)0.27135118842;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.29741764069)) {
              sum += (float)-0.12891107798;
            } else {
              sum += (float)3.5281867981;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63732796907)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109618932)) {
              sum += (float)-0.18374246359;
            } else {
              sum += (float)-1.605484724;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.64770931005)) {
              sum += (float)0.012331161648;
            } else {
              sum += (float)-0.092477396131;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.4790564775)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.1516585052)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)0.0011588257039;
            } else {
              sum += (float)-0.20194648206;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.6465896368)) {
              sum += (float)-0.069808229804;
            } else {
              sum += (float)-0.16195854545;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.2472667694)) {
            sum += (float)-0.60176503658;
          } else {
            sum += (float)-0.25559946895;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3394815922)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5613801479)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.40842318535)) {
              sum += (float)-0.053619202226;
            } else {
              sum += (float)0.020874781534;
            }
          } else {
            sum += (float)-0.19240151346;
          }
        } else {
          sum += (float)0.86610579491;
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.52597904205)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773507148)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44643878937)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44468420744)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42830830812)) {
              sum += (float)0.62992316484;
            } else {
              sum += (float)-0.0076343961991;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.98399662971)) {
              sum += (float)3.5074298382;
            } else {
              sum += (float)-0.068014569581;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.48445433378)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.37522774935)) {
              sum += (float)-0.012462957762;
            } else {
              sum += (float)-0.28524696827;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.31470876932)) {
              sum += (float)-0.072891563177;
            } else {
              sum += (float)0.65351426601;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1982176304)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.17456950247)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.76598769426)) {
              sum += (float)-0.034958194941;
            } else {
              sum += (float)0.28089344501;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.22996224463)) {
              sum += (float)0.042428359389;
            } else {
              sum += (float)-0.095096953213;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.28327476978)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.3990921974)) {
              sum += (float)0.46704480052;
            } else {
              sum += (float)-0.01431903895;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.32675874233)) {
              sum += (float)2.4067473412;
            } else {
              sum += (float)-0.42759245634;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1726051569)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1734175682)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.70085072517)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.59855914116)) {
              sum += (float)-0.10710840672;
            } else {
              sum += (float)-0.035212740302;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.78273046017)) {
              sum += (float)0.15390437841;
            } else {
              sum += (float)-0.062667600811;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.2225680351)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6988897324)) {
              sum += (float)-1.4067467451;
            } else {
              sum += (float)-0.28245949745;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3839615583)) {
              sum += (float)-0.14210820198;
            } else {
              sum += (float)0.13933420181;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.29945790768)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.0018594488502)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64504015446)) {
              sum += (float)0.0059949085116;
            } else {
              sum += (float)0.60739588737;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.025065198541)) {
              sum += (float)-0.14269904792;
            } else {
              sum += (float)0.024480188265;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.28825315833)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.30030560493)) {
              sum += (float)0.026309935376;
            } else {
              sum += (float)1.224326849;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.83653712273)) {
              sum += (float)-0.037883073092;
            } else {
              sum += (float)0.0084127923474;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4822171926)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4599926472)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7003444433)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.329570055)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2108443975)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3562912941)) {
              sum += (float)-0.00029308942612;
            } else {
              sum += (float)0.071816831827;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.5574367046)) {
              sum += (float)-0.099848210812;
            } else {
              sum += (float)0.60463678837;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3611521721)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
              sum += (float)-0.062279533595;
            } else {
              sum += (float)0.62692445517;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.92622482777)) {
              sum += (float)0.85805737972;
            } else {
              sum += (float)-0.019033871591;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.53198182583)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6988897324)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.25589895248)) {
              sum += (float)-1.1073192358;
            } else {
              sum += (float)3.3796160221;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
              sum += (float)0.011959855445;
            } else {
              sum += (float)-0.29960832;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2319298983)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.95836138725)) {
              sum += (float)-0.098693586886;
            } else {
              sum += (float)-0.22398035228;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.3432021141)) {
              sum += (float)-0.052511915565;
            } else {
              sum += (float)-0.37506565452;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.4673894644)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6478359699)) {
          sum += (float)0.82866936922;
        } else {
          sum += (float)-0.17367444932;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1101877689)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.7084387541)) {
            sum += (float)0.14376394451;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.9936587811)) {
              sum += (float)0.048449140042;
            } else {
              sum += (float)-0.090381249785;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.52391165495)) {
            sum += (float)-0.027951873839;
          } else {
            sum += (float)-0.22118015587;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4962537289)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.129101634)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4361608028)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.39422810078)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.9337730408)) {
              sum += (float)-0.015475965105;
            } else {
              sum += (float)-0.14705100656;
            }
          } else {
            sum += (float)-1.5209110975;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.58354198933)) {
            sum += (float)0.079637415707;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.4315867424)) {
              sum += (float)-0.31711354852;
            } else {
              sum += (float)-0.079968832433;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.63175189495)) {
          sum += (float)0.2068003267;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.39430934191)) {
            sum += (float)0.10587185621;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0254657269)) {
              sum += (float)-0.6200568676;
            } else {
              sum += (float)-0.25596657395;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87039124966)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87536859512)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.1796193123)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.56713950634)) {
              sum += (float)-0.05153201893;
            } else {
              sum += (float)0.057459682226;
            }
          } else {
            sum += (float)-0.15703040361;
          }
        } else {
          sum += (float)4.1197724342;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40470176935)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.9072030783)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2825655937)) {
              sum += (float)0.033962573856;
            } else {
              sum += (float)-0.07627850771;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2457027435)) {
              sum += (float)-0.46252855659;
            } else {
              sum += (float)-0.1447430253;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5319299698)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5284206867)) {
              sum += (float)0.12921434641;
            } else {
              sum += (float)1.1390662193;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40989798307)) {
              sum += (float)0.50506842136;
            } else {
              sum += (float)-0.0051796371117;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.4335923195)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
      sum += (float)0.99868994951;
    } else {
      sum += (float)0.038206715137;
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3870819807)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.81983458996)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.84957027435)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.87335884571)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0766561031)) {
              sum += (float)0.018844829872;
            } else {
              sum += (float)-0.032163668424;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4350399971)) {
              sum += (float)-0.10441292822;
            } else {
              sum += (float)-0.22933657467;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.300303936)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.18674772978;
            } else {
              sum += (float)0.99211078882;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4777345657)) {
              sum += (float)0.26807650924;
            } else {
              sum += (float)-0.16169497371;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5356785059)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.242538929)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.3672046661)) {
              sum += (float)-0.014923433773;
            } else {
              sum += (float)-0.32411551476;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9000916481)) {
              sum += (float)-0.21834555268;
            } else {
              sum += (float)-0.10932995379;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4596040249)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70205450058)) {
              sum += (float)-0.067900694907;
            } else {
              sum += (float)0.01951402612;
            }
          } else {
            sum += (float)-0.022955412045;
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3701212406)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0582278967)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.8100340366)) {
            sum += (float)0.46908664703;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.3781139851)) {
              sum += (float)0.06034829095;
            } else {
              sum += (float)-0.25953239202;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55167269707)) {
            sum += (float)0.86024552584;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84266656637)) {
              sum += (float)-0.014793164097;
            } else {
              sum += (float)0.22731085122;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.98635458946)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1043952703)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1636673212)) {
              sum += (float)0.026496049017;
            } else {
              sum += (float)-0.033357791603;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050498813)) {
              sum += (float)-0.12539862096;
            } else {
              sum += (float)0.40060040355;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.83864915371)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84668409824)) {
              sum += (float)0.013943727128;
            } else {
              sum += (float)0.3637996912;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0023747683)) {
              sum += (float)-0.022854264826;
            } else {
              sum += (float)0.0018007480539;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84030801058)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84293341637)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9143127799)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.064186647534)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418975949)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.89396202564)) {
              sum += (float)0.006392984651;
            } else {
              sum += (float)-0.033520951867;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.25869420171)) {
              sum += (float)1.0407116413;
            } else {
              sum += (float)0.050609175116;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.95194983482)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.52391165495)) {
              sum += (float)0.0016775088152;
            } else {
              sum += (float)0.10791475326;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.91393727064)) {
              sum += (float)-0.21799105406;
            } else {
              sum += (float)-0.040229041129;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.89943528175)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0999181271)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2363951206)) {
              sum += (float)0.20693917572;
            } else {
              sum += (float)-0.1423869729;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.74698734283)) {
              sum += (float)0.79908466339;
            } else {
              sum += (float)-0.1936506778;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.86760175228)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.8577952385)) {
              sum += (float)-0.12678937614;
            } else {
              sum += (float)3.5015363693;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4905064106)) {
              sum += (float)1.2499468327;
            } else {
              sum += (float)0.014716818929;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.25952985883)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260767937)) {
          sum += (float)-0.19925436378;
        } else {
          sum += (float)1.6078095436;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.97122621536)) {
          sum += (float)0.33101585507;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.14764103293)) {
            sum += (float)-0.1080743596;
          } else {
            sum += (float)0.076523534954;
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81066226959)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.51355683804)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3689575195)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.7666889429)) {
            sum += (float)-0.2121475935;
          } else {
            sum += (float)-1.8236621618;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.8554790616)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0336494446)) {
              sum += (float)-0.10470308363;
            } else {
              sum += (float)-0.2574030757;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.98538905382)) {
              sum += (float)-0.093978635967;
            } else {
              sum += (float)-0.012721177191;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.18415308)) {
          sum += (float)1.3363609314;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.83954226971)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.30777239799)) {
              sum += (float)0.020214328542;
            } else {
              sum += (float)-1.1958178282;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.4327758551)) {
              sum += (float)-0.017136404291;
            } else {
              sum += (float)0.086721539497;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77981328964)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78057909012)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.99695920944)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0895206928)) {
              sum += (float)-0.0059776362032;
            } else {
              sum += (float)0.14557862282;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.68646836281)) {
              sum += (float)-0.062774389982;
            } else {
              sum += (float)-0.0099454503506;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.76031148434)) {
            sum += (float)1.3893345594;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.26283535361)) {
              sum += (float)0.038396414369;
            } else {
              sum += (float)-0.00085730146384;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7181699276)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1706203222)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.83704769611)) {
              sum += (float)0.013786781579;
            } else {
              sum += (float)0.62283074856;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.025065248832)) {
              sum += (float)-0.13178169727;
            } else {
              sum += (float)0.017340069637;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7172948122)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.45072895288)) {
              sum += (float)2.489531517;
            } else {
              sum += (float)-0.44145894051;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71620082855)) {
              sum += (float)0.23956593871;
            } else {
              sum += (float)0.00010184149869;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1297497749)) {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.83497697115)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57655978203)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60341590643)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75219130516)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.75897371769)) {
              sum += (float)-0.0037863047328;
            } else {
              sum += (float)0.42851766944;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1446835995)) {
              sum += (float)-0.096859626472;
            } else {
              sum += (float)0.38188824058;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60177499056)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4645698071)) {
              sum += (float)-0.25024214387;
            } else {
              sum += (float)2.3798797131;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.58367037773)) {
              sum += (float)-0.18716391921;
            } else {
              sum += (float)0.31910252571;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50988429785)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57256686687)) {
            sum += (float)-0.30157014728;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0200996399)) {
              sum += (float)-0.065943010151;
            } else {
              sum += (float)-0.160122931;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40661621094)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.15769125521)) {
              sum += (float)-0.024062260985;
            } else {
              sum += (float)0.077946394682;
            }
          } else {
            sum += (float)-0.57259762287;
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.59261202812)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3995833397)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3356146812)) {
              sum += (float)-0.70801448822;
            } else {
              sum += (float)0.013909218833;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3395261765)) {
              sum += (float)-0.32233607769;
            } else {
              sum += (float)-0.10171671957;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.41212850809)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
              sum += (float)-0.33903631568;
            } else {
              sum += (float)-0.18601733446;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.5758616924)) {
              sum += (float)-0.79519999027;
            } else {
              sum += (float)-0.10812021792;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.61640059948)) {
          sum += (float)1.3624309301;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7975897789)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.68181920052)) {
              sum += (float)-0.164075315;
            } else {
              sum += (float)-0.54338425398;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7286169529)) {
              sum += (float)1.245303154;
            } else {
              sum += (float)-0.22877022624;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2554895878)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.96606761217)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.91912615299)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0895206928)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3046174049)) {
              sum += (float)-0.045005723834;
            } else {
              sum += (float)0.37661027908;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
              sum += (float)-0.081397131085;
            } else {
              sum += (float)0.031972847879;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4631130695)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1705117226)) {
              sum += (float)0.015439582057;
            } else {
              sum += (float)-0.22520904243;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.447906971)) {
              sum += (float)0.52760398388;
            } else {
              sum += (float)0.012145485729;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.56917572021)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.67419362068)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2648472786)) {
              sum += (float)0.24121171236;
            } else {
              sum += (float)-0.25904542208;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84668409824)) {
              sum += (float)0.75847989321;
            } else {
              sum += (float)0.60675019026;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.3765546083)) {
            sum += (float)0.16067360342;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84668409824)) {
              sum += (float)-0.15421696007;
            } else {
              sum += (float)-0.08958402276;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.153329134)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.4878719151)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1503818035)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.64982712269)) {
              sum += (float)0.061409097165;
            } else {
              sum += (float)0.30729737878;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.67794954777)) {
              sum += (float)0.030082635581;
            } else {
              sum += (float)-0.081741809845;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0048360825)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.081355854869)) {
              sum += (float)-0.10207364708;
            } else {
              sum += (float)-0.2993671;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.71008944511)) {
              sum += (float)1.4471764565;
            } else {
              sum += (float)-0.12399668247;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0455266237)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0513751507)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2283625603)) {
              sum += (float)0.042496155947;
            } else {
              sum += (float)-0.04816301167;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.6501817703)) {
              sum += (float)0.06818395853;
            } else {
              sum += (float)-0.43668141961;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96061265469)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
              sum += (float)0.0073229935952;
            } else {
              sum += (float)0.18090640008;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.82530319691)) {
              sum += (float)-0.041482698172;
            } else {
              sum += (float)0.0015381621197;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3713860512)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3291018009)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.4113879204)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.2678084373)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9909652472)) {
              sum += (float)0.0008091678028;
            } else {
              sum += (float)-0.042182669044;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.70835495)) {
              sum += (float)-0.17257130146;
            } else {
              sum += (float)0.80656939745;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.83262622356)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.7117518187)) {
              sum += (float)0.0083279618993;
            } else {
              sum += (float)-0.14123104513;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3781130314)) {
              sum += (float)-0.96565681696;
            } else {
              sum += (float)-0.082758665085;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
            sum += (float)11.850215912;
          } else {
            sum += (float)-1.6237876415;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359526873)) {
              sum += (float)0.0097792251036;
            } else {
              sum += (float)-0.48282653093;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
              sum += (float)0.19626522064;
            } else {
              sum += (float)-0.045429993421;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.3713243008)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5283179283)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.64982712269)) {
            sum += (float)0.25818789005;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.091396197677)) {
              sum += (float)0.073343791068;
            } else {
              sum += (float)0.0002461776312;
            }
          }
        } else {
          sum += (float)-0.26292091608;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.516825676)) {
          sum += (float)9.3058023453;
        } else {
          sum += (float)-0.7223354578;
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.4136703014)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.28423565626)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2916893959)) {
          sum += (float)-0.2922655344;
        } else {
          sum += (float)-1.0244749784;
        }
      } else {
        sum += (float)0.1082142666;
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1719770432)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1351143122)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.36060005426)) {
              sum += (float)0.17360445857;
            } else {
              sum += (float)-0.017635785043;
            }
          } else {
            sum += (float)0.43626710773;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4991779327)) {
            sum += (float)1.8536032438;
          } else {
            sum += (float)-0.40539875627;
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.4790564775)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2927241325)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.50616443157)) {
              sum += (float)-0.45625695586;
            } else {
              sum += (float)0.11667031795;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.7533941865)) {
              sum += (float)-0.95572501421;
            } else {
              sum += (float)0.075885877013;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.5253372192)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9187350273)) {
              sum += (float)-0.15627723932;
            } else {
              sum += (float)6.2572140694;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.19548630714)) {
              sum += (float)-0.23722577095;
            } else {
              sum += (float)-0.011814048514;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84030801058)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84293341637)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0659965277)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0166506767)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0205341578)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.89282774925)) {
              sum += (float)0.0034075141884;
            } else {
              sum += (float)0.14064329863;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2082580328)) {
              sum += (float)0.051703196019;
            } else {
              sum += (float)0.6196424365;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4713010788)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4905064106)) {
              sum += (float)0.23880401254;
            } else {
              sum += (float)-0.078246355057;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
              sum += (float)0.0041688387282;
            } else {
              sum += (float)-0.097381271422;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0636570454)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2819730043)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
              sum += (float)1.1226929426;
            } else {
              sum += (float)0.23783625662;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0200996399)) {
              sum += (float)-0.05002804473;
            } else {
              sum += (float)-0.51472151279;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84583234787)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.304323107)) {
              sum += (float)-0.021391028538;
            } else {
              sum += (float)0.017288371921;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0149999857)) {
              sum += (float)0.36790800095;
            } else {
              sum += (float)-0.024472022429;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.25952985883)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260767937)) {
          sum += (float)-0.16102993488;
        } else {
          sum += (float)1.1500407457;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.97122621536)) {
          sum += (float)0.2344609499;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.14764103293)) {
            sum += (float)-0.07899941504;
          } else {
            sum += (float)0.057594522834;
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81066226959)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.80838942528)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.98766297102)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.56545984745)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.98538905382)) {
              sum += (float)-0.098456852138;
            } else {
              sum += (float)-0.26228928566;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.80450379848)) {
              sum += (float)-0.031489491463;
            } else {
              sum += (float)-0.3913628161;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.78642171621)) {
            sum += (float)-1.336558342;
          } else {
            sum += (float)-0.30653765798;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2162930965)) {
          sum += (float)0.96152466536;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.84003448486)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.30777239799)) {
              sum += (float)0.016830079257;
            } else {
              sum += (float)-0.92728692293;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.82275032997)) {
              sum += (float)0.045324385166;
            } else {
              sum += (float)-0.036990188062;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77910220623)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.78057909012)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.1589415073)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.28521496058)) {
              sum += (float)-0.060818020254;
            } else {
              sum += (float)-0.24603372812;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.90309464931)) {
              sum += (float)0.13027563691;
            } else {
              sum += (float)-0.008862956427;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292406559)) {
            sum += (float)0.99225580692;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.13315173984)) {
              sum += (float)0.038170345128;
            } else {
              sum += (float)-0.0012839914998;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7071211338)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1128360033)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.360822916)) {
              sum += (float)-0.15140609443;
            } else {
              sum += (float)0.14222456515;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.048205547035)) {
              sum += (float)-0.10011028498;
            } else {
              sum += (float)0.047304518521;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70624601841)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260761976)) {
              sum += (float)0.53563761711;
            } else {
              sum += (float)-0.021742548794;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5296571255)) {
              sum += (float)0.29101940989;
            } else {
              sum += (float)-0.00026375122252;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1297497749)) {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1098330021)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57655978203)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60341590643)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.66396534443)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7614351511)) {
              sum += (float)-0.010021145456;
            } else {
              sum += (float)0.05059505254;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.046397902071)) {
              sum += (float)-0.092193543911;
            } else {
              sum += (float)-1.0780438185;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60177499056)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4645698071)) {
              sum += (float)-0.18603442609;
            } else {
              sum += (float)1.6982126236;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1654219627)) {
              sum += (float)-0.2512768209;
            } else {
              sum += (float)0.19593958557;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.35055240989)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.016570301726)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.3646094501)) {
              sum += (float)-0.082340836525;
            } else {
              sum += (float)-0.47668090463;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.19476795197)) {
              sum += (float)-0.045574009418;
            } else {
              sum += (float)-1.2649693489;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.153329134)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60454589128)) {
              sum += (float)-0.0028795301914;
            } else {
              sum += (float)0.069860741496;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.40661621094)) {
              sum += (float)-0.0481961146;
            } else {
              sum += (float)-0.52268540859;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.242410183)) {
        sum += (float)-0.91967195272;
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4386329651)) {
          sum += (float)-0.054439537227;
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.30564698577)) {
            sum += (float)-0.091984003782;
          } else {
            sum += (float)-0.35347503424;
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.8247974515)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0990782976)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.35175269842)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.60461878777)) {
              sum += (float)0.015333137475;
            } else {
              sum += (float)-0.45792990923;
            }
          } else {
            sum += (float)-0.98855048418;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.44254094362)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.8253031373)) {
              sum += (float)-0.069827020168;
            } else {
              sum += (float)5.7473993301;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3216949701)) {
              sum += (float)1.6670413017;
            } else {
              sum += (float)-0.24145843089;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.083361148834)) {
          sum += (float)3.8970856667;
        } else {
          sum += (float)0.0034369947389;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.69110441208)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.71625316143)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.39164024591)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.62572216988)) {
              sum += (float)-0.040929086506;
            } else {
              sum += (float)0.099215790629;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.032873049378)) {
              sum += (float)0.015656875446;
            } else {
              sum += (float)0.52128833532;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.063987202942)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.23984594643)) {
              sum += (float)-0.00044377447921;
            } else {
              sum += (float)-0.24868188798;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.17754310369)) {
              sum += (float)-0.17062707245;
            } else {
              sum += (float)-0.25407263637;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.688180089)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.29033115506)) {
            sum += (float)1.4483340979;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.58956480026)) {
              sum += (float)-0.16034966707;
            } else {
              sum += (float)-0.44242066145;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.82530319691)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.37663784623)) {
              sum += (float)-0.24531495571;
            } else {
              sum += (float)0.045586992055;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.80838942528)) {
              sum += (float)0.12176611274;
            } else {
              sum += (float)0.00038643935113;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.21917310357)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.22512024641)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.65367370844)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.71625316143)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.33044016361)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.82913017273)) {
              sum += (float)0.004092878662;
            } else {
              sum += (float)-0.045670308173;
            }
          } else {
            sum += (float)-1.5495696068;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.27567094564)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)-0.12397412956;
            } else {
              sum += (float)0.54203778505;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47032904625)) {
              sum += (float)-0.17066243291;
            } else {
              sum += (float)-0.31486308575;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.65191912651)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47032904625)) {
            sum += (float)-0.16123408079;
          } else {
            sum += (float)1.5400553942;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.63671284914)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.18011650443)) {
              sum += (float)-0.061816744506;
            } else {
              sum += (float)0.97789132595;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60747015476)) {
              sum += (float)-0.062572367489;
            } else {
              sum += (float)0.01092862431;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.19378140569)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.3162646294)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730372906)) {
              sum += (float)-0.014804420993;
            } else {
              sum += (float)0.06962838769;
            }
          } else {
            sum += (float)-0.046764403582;
          }
        } else {
          sum += (float)-1.1932235956;
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.47707509995)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42772346735)) {
            sum += (float)0.087570659816;
          } else {
            sum += (float)-0.093185476959;
          }
        } else {
          sum += (float)18.71931076;
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.11212450266)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96906960011)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.96312659979)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.71008944511)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.95113885403)) {
              sum += (float)-0.17515267432;
            } else {
              sum += (float)0.12060108781;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.28611898422)) {
              sum += (float)-0.0134364767;
            } else {
              sum += (float)-0.49159121513;
            }
          }
        } else {
          sum += (float)0.19591003656;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72659277916)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.66259741783)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.51458978653)) {
              sum += (float)-0.028202345595;
            } else {
              sum += (float)-0.092136099935;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.18646380305)) {
              sum += (float)-0.54065835476;
            } else {
              sum += (float)-0.1477330178;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.74436926842)) {
            sum += (float)2.01755023;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3747227192)) {
              sum += (float)-0.0023351211566;
            } else {
              sum += (float)-0.51860225201;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.67004954815)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.42001736164)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65696418285)) {
              sum += (float)-0.029074365273;
            } else {
              sum += (float)1.1592772007;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63207709789)) {
              sum += (float)-0.7006509304;
            } else {
              sum += (float)-0.13247406483;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12016919255)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.11756979674)) {
              sum += (float)0.26605218649;
            } else {
              sum += (float)-0.19220240414;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.092810154)) {
              sum += (float)0.038895729929;
            } else {
              sum += (float)-0.25538319349;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.26708444953)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.74698734283)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
              sum += (float)-0.0065621403046;
            } else {
              sum += (float)0.76026308537;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.049679502845)) {
              sum += (float)0.069621235132;
            } else {
              sum += (float)-0.038974560797;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.11148360372)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.27742266655)) {
              sum += (float)0.20844334364;
            } else {
              sum += (float)0.0028317107353;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20216549933)) {
              sum += (float)-0.23482353985;
            } else {
              sum += (float)0.00033302730299;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1135189533)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.7585191727)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0964534283)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.9754346609)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.934142828)) {
              sum += (float)0.069931522012;
            } else {
              sum += (float)0.10526032001;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.0271048546)) {
              sum += (float)-0.0028599523939;
            } else {
              sum += (float)-0.091654010117;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.9585210085)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.360922575)) {
              sum += (float)-0.033781278878;
            } else {
              sum += (float)-1.0046169758;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-2.2167344093)) {
              sum += (float)-0.44608804584;
            } else {
              sum += (float)-0.064928255975;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.5005438328)) {
          sum += (float)-0.37505215406;
        } else {
          sum += (float)-0.23715306818;
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.6564587355)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6202470064)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.7546365261)) {
            sum += (float)-0.51969045401;
          } else {
            sum += (float)2.8379135132;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5272216797)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6374812126)) {
              sum += (float)-0.032413516194;
            } else {
              sum += (float)-0.15275724232;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5596710443)) {
              sum += (float)0.023111328483;
            } else {
              sum += (float)-0.010387914255;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.45320177078)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0990782976)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.79993259907)) {
              sum += (float)0.01994629018;
            } else {
              sum += (float)-0.062635451555;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9913136363)) {
              sum += (float)0.057357560843;
            } else {
              sum += (float)3.1154847145;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.34929105639)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1049503535)) {
              sum += (float)0.49180936813;
            } else {
              sum += (float)-0.091447293758;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.174957037)) {
              sum += (float)0.0077132890001;
            } else {
              sum += (float)0.19434143603;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1012313366)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28721338511)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.896848321)) {
          sum += (float)-0.7108271122;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94727087021)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4933942556)) {
              sum += (float)-0.0077171074226;
            } else {
              sum += (float)0.075740508735;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
              sum += (float)-0.1710704416;
            } else {
              sum += (float)-0.04431867227;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.034811601043)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.66917717457)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.64982712269)) {
              sum += (float)0.023985439911;
            } else {
              sum += (float)-0.17093597353;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.59200340509)) {
              sum += (float)-0.58692699671;
            } else {
              sum += (float)-0.32673379779;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.12919674814)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.62594926357)) {
              sum += (float)-0.049032185227;
            } else {
              sum += (float)-0.19705618918;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.34064543247)) {
              sum += (float)0.063548482955;
            } else {
              sum += (float)-0.040128551424;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4531705379)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5400996208)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5436549187)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2765552998)) {
              sum += (float)0.080634333193;
            } else {
              sum += (float)-1.7488434315;
            }
          } else {
            sum += (float)6.0062866211;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.84957027435)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.456679821)) {
              sum += (float)-0.063999325037;
            } else {
              sum += (float)-0.39073190093;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2746431828)) {
              sum += (float)-0.042520232499;
            } else {
              sum += (float)0.17519333959;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1520131826)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.4591524601)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5135872364)) {
              sum += (float)0.22617711127;
            } else {
              sum += (float)-0.012292727828;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1640655994)) {
              sum += (float)0.035908073187;
            } else {
              sum += (float)0.67936587334;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0154185295)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.66053164005)) {
              sum += (float)-0.027489127591;
            } else {
              sum += (float)-0.13666693866;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4467372894)) {
              sum += (float)0.14405912161;
            } else {
              sum += (float)-0.00058157881722;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.524343729)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.1469101906)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4118354321)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17272660136)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.6256725788)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.6435139179)) {
              sum += (float)0.0047931792215;
            } else {
              sum += (float)1.6823740005;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.4257395267)) {
              sum += (float)-0.062462355942;
            } else {
              sum += (float)-0.0057290182449;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.57897531986)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001260042)) {
              sum += (float)-0.71626234055;
            } else {
              sum += (float)-0.33575218916;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
              sum += (float)-0.27914965153;
            } else {
              sum += (float)0.03537479043;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4096474648)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4991519451)) {
            sum += (float)2.276252985;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.10746614635)) {
              sum += (float)0.013509291224;
            } else {
              sum += (float)0.06561113894;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3959186077)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3967938423)) {
              sum += (float)0.038937244564;
            } else {
              sum += (float)1.2162134647;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1297497749)) {
              sum += (float)-0.013171871193;
            } else {
              sum += (float)0.0013734479435;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.036886692)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.4439940453)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6098179817)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884688616)) {
              sum += (float)0.024016927928;
            } else {
              sum += (float)-0.39529567957;
            }
          } else {
            sum += (float)-0.31575229764;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.2104640007)) {
            sum += (float)0.12936981022;
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
              sum += (float)0.02289279364;
            } else {
              sum += (float)0.069247707725;
            }
          }
        }
      } else {
        sum += (float)2.9187684059;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.87039124966)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.94401323795)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.1796193123)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050442934)) {
            sum += (float)0.017437836155;
          } else {
            sum += (float)-0.013542271219;
          }
        } else {
          sum += (float)-0.10894875973;
        }
      } else {
        sum += (float)2.9733388424;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.42647117376)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.39130103588)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1574177444)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
              sum += (float)-0.2950758636;
            } else {
              sum += (float)0.077293418348;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
              sum += (float)-0.013852029108;
            } else {
              sum += (float)0.096075318754;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
            sum += (float)0.66477614641;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4316966534)) {
              sum += (float)-0.3525763154;
            } else {
              sum += (float)-0.11500491202;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3460154533)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.1092238426)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.15858067572;
            } else {
              sum += (float)-0.048640064895;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7986453772)) {
              sum += (float)-0.3376249969;
            } else {
              sum += (float)-0.15773582458;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3135449886)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.7942285538)) {
              sum += (float)0.060305077583;
            } else {
              sum += (float)0.11272425205;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.3654508591)) {
              sum += (float)-0.078920729458;
            } else {
              sum += (float)-0.0054600820877;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.83864915371)) {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.84668409824)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.5021173954)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50299245119)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.2645445466)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.34326270223)) {
              sum += (float)0.011193628423;
            } else {
              sum += (float)-0.077908918262;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1995322704)) {
              sum += (float)-0.028584742919;
            } else {
              sum += (float)0.4559662044;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359520912)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4493073225)) {
              sum += (float)-0.043062306941;
            } else {
              sum += (float)0.69666862488;
            }
          } else {
            sum += (float)-0.57428002357;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.045752402395)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.94175100327)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.92855554819)) {
              sum += (float)0.041352141649;
            } else {
              sum += (float)-0.028268525377;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.92985677719)) {
              sum += (float)-0.50373417139;
            } else {
              sum += (float)-0.11126773804;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418975949)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1049503535)) {
              sum += (float)1.9028089046;
            } else {
              sum += (float)-0.088079616427;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.1158605963)) {
              sum += (float)-0.12320067734;
            } else {
              sum += (float)0.034479141235;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.38375335932)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47032904625)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.54572272301)) {
            sum += (float)-0.3582804203;
          } else {
            sum += (float)-0.25612866879;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.54572272301)) {
            sum += (float)-0.29066854715;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050457835)) {
              sum += (float)-0.036824312061;
            } else {
              sum += (float)0.0044011347927;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.54572272301)) {
            sum += (float)0.092108100653;
          } else {
            sum += (float)-0.39236214757;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
            sum += (float)1.0431308746;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.65359526873)) {
              sum += (float)-0.6814186573;
            } else {
              sum += (float)0.0025397664867;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.79043924809)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1485568881)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.9923017621)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.7931014299)) {
            sum += (float)-0.78776562214;
          } else {
            sum += (float)-0.32038843632;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1196627617)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.99639880657)) {
              sum += (float)0.037725403905;
            } else {
              sum += (float)-0.079804413021;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0548841953)) {
              sum += (float)-0.36044308543;
            } else {
              sum += (float)-0.16608056426;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.68661630154)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.051469951868)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.80650913715)) {
              sum += (float)-0.043876118958;
            } else {
              sum += (float)-0.14343470335;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.3230428696)) {
              sum += (float)0.033484458923;
            } else {
              sum += (float)-0.060502972454;
            }
          }
        } else {
          sum += (float)-0.18726480007;
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2732579708)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4905064106)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.73017692566)) {
              sum += (float)-0.16540651023;
            } else {
              sum += (float)-0.066426731646;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.7638964653)) {
              sum += (float)-0.015839114785;
            } else {
              sum += (float)0.027666052803;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55227440596)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.35793662071)) {
              sum += (float)0.07409530133;
            } else {
              sum += (float)0.27459543943;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.46038365364)) {
              sum += (float)-0.082657724619;
            } else {
              sum += (float)0.087914787233;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.0959222317)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1098330021)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.9400203228)) {
              sum += (float)-0.034876998514;
            } else {
              sum += (float)0.0058876741678;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.242410183)) {
              sum += (float)-0.69407486916;
            } else {
              sum += (float)-0.28100776672;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2283625603)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.96061265469)) {
              sum += (float)0.15617059171;
            } else {
              sum += (float)0.0014617198613;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.263497591)) {
              sum += (float)0.051687274128;
            } else {
              sum += (float)-0.0018002541037;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.5060465336)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91627365351)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91919791698)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.6564587355)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0772547722)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0798802376)) {
              sum += (float)-0.01219248306;
            } else {
              sum += (float)2.0580310822;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4991519451)) {
              sum += (float)-0.18348696828;
            } else {
              sum += (float)0.031020017341;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3167302608)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.7929713726)) {
              sum += (float)0.058427579701;
            } else {
              sum += (float)-0.041246153414;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.6286270618)) {
              sum += (float)-0.89929115772;
            } else {
              sum += (float)-0.10494235903;
            }
          }
        }
      } else {
        sum += (float)0.83128541708;
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.95448100567)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.9092553854)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3564822674)) {
            sum += (float)-0.039798155427;
          } else {
            sum += (float)-0.17942115664;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30919399858)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.529186964)) {
              sum += (float)0.030774408951;
            } else {
              sum += (float)-0.22298775613;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2916582823)) {
              sum += (float)0.032516978681;
            } else {
              sum += (float)-0.2345521301;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.7721605301)) {
          sum += (float)0.51420760155;
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.8109139204)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50921499729)) {
              sum += (float)-0.19663541019;
            } else {
              sum += (float)-0.54478341341;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.48702913523)) {
              sum += (float)-0.068311795592;
            } else {
              sum += (float)-0.0034786076285;
            }
          }
        }
      }
    }
  } else {
    if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.4597659111)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5863730907)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.6010866165)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50118005276)) {
            sum += (float)0.05183327198;
          } else {
            sum += (float)-0.2469226867;
          }
        } else {
          sum += (float)-1.9429603815;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5433813334)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.8882026672)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3689575195)) {
              sum += (float)0.030657745898;
            } else {
              sum += (float)-0.55840790272;
            }
          } else {
            sum += (float)4.1583213806;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.4245126247)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2604854107)) {
              sum += (float)0.0046260613017;
            } else {
              sum += (float)-0.14976538718;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.3461568356)) {
              sum += (float)1.2327692509;
            } else {
              sum += (float)0.12489246577;
            }
          }
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.4366255999)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1520131826)) {
          sum += (float)-0.43937173486;
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.5067296028)) {
            sum += (float)-0.14095035195;
          } else {
            sum += (float)-0.2707324028;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2551288605)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2934713364)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
              sum += (float)-0.0082038454711;
            } else {
              sum += (float)0.17380182445;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.66917717457)) {
              sum += (float)0.2645522058;
            } else {
              sum += (float)-0.15455147624;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1649885178)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.15044289827)) {
              sum += (float)-0.021145820618;
            } else {
              sum += (float)-0.11981484294;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.1310217381)) {
              sum += (float)0.11195869744;
            } else {
              sum += (float)-0.00057431933237;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.9367890358)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5942533016)) {
      sum += (float)-0.57843977213;
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-2.1641099453)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-2.569601059)) {
          sum += (float)-0.50196754932;
        } else {
          sum += (float)-0.17676621675;
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7505626678)) {
          sum += (float)0.13728198409;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.264502883)) {
            sum += (float)-0.050666149706;
          } else {
            sum += (float)0.053145784885;
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4255886078)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4127216339)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.406288147)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2109465599)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9998140335)) {
              sum += (float)0.00044833440916;
            } else {
              sum += (float)-0.055078722537;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2127013206)) {
              sum += (float)0.77667844296;
            } else {
              sum += (float)0.034530073404;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4080429077)) {
            sum += (float)-0.38824513555;
          } else {
            sum += (float)0.020999774337;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.415060997)) {
          sum += (float)2.2577552795;
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6757692099)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.134594202)) {
              sum += (float)0.047431990504;
            } else {
              sum += (float)0.2881231606;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2155573368)) {
              sum += (float)-0.12838052213;
            } else {
              sum += (float)0.016771266237;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6150815487)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8207473755)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3992979527)) {
              sum += (float)-0.03236746788;
            } else {
              sum += (float)-0.40925642848;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4577555656)) {
              sum += (float)0.39103350043;
            } else {
              sum += (float)0.038864191622;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
              sum += (float)-0.093045644462;
            } else {
              sum += (float)4.0454473495;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3881340027)) {
              sum += (float)0.035137027502;
            } else {
              sum += (float)2.3354921341;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5528931618)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7342916727)) {
            sum += (float)-0.3311740458;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4259374142)) {
              sum += (float)-0.062475346029;
            } else {
              sum += (float)0.0067788399756;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6389063597)) {
            sum += (float)0.096266873181;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7064882517)) {
              sum += (float)-0.10321826488;
            } else {
              sum += (float)-0.028385078534;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.1176805496)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.0753962994)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8481516838)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4816827774)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4584367275)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.378852725)) {
              sum += (float)0.0003439806751;
            } else {
              sum += (float)-0.086551479995;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5613801479)) {
              sum += (float)-0.047050356865;
            } else {
              sum += (float)0.59991270304;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.5237994194)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4115855694)) {
              sum += (float)-0.11976125091;
            } else {
              sum += (float)-0.27482798696;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0887598991)) {
              sum += (float)-0.049367722124;
            } else {
              sum += (float)0.53785520792;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8514335155)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6046080589)) {
            sum += (float)-0.25192645192;
          } else {
            sum += (float)2.0103616714;
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2764217854)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.4400799274)) {
              sum += (float)0.024287350476;
            } else {
              sum += (float)0.35754874349;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3553036451)) {
              sum += (float)-0.75866794586;
            } else {
              sum += (float)-0.073173962533;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6819130182)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.79912078381)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1101875305)) {
            sum += (float)-0.15169039369;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6294686794)) {
              sum += (float)-0.002193483524;
            } else {
              sum += (float)0.057125940919;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.3592712879)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1560306549)) {
              sum += (float)0.17210006714;
            } else {
              sum += (float)0.031394887716;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9275846481)) {
              sum += (float)-0.2306624949;
            } else {
              sum += (float)-1.3801174164;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.88485360146)) {
            sum += (float)0.74212127924;
          } else {
            sum += (float)17.410209656;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1580429077)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2184436321)) {
              sum += (float)0.15084466338;
            } else {
              sum += (float)0.063508428633;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.60095405579)) {
              sum += (float)0.078052103519;
            } else {
              sum += (float)-0.047743756324;
            }
          }
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.7612257004)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.270277977)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2798573971)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.825781703)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.48912757635)) {
              sum += (float)-0.0048613264225;
            } else {
              sum += (float)-0.73070919514;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32615479827)) {
              sum += (float)-0.16161963344;
            } else {
              sum += (float)0.01018141862;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3447761536)) {
            sum += (float)1.3286081553;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.516138792)) {
              sum += (float)0.19355265796;
            } else {
              sum += (float)-0.26640722156;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0278199911)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.47881600261)) {
            sum += (float)-1.7751535177;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5143842697)) {
              sum += (float)-0.0068693100475;
            } else {
              sum += (float)-0.48504787683;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.6853046417)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5123929977)) {
              sum += (float)-0.12242333591;
            } else {
              sum += (float)-0.54044485092;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.96133494377)) {
              sum += (float)0.00062976690242;
            } else {
              sum += (float)-0.12716507912;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.796908617)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2530260086)) {
          sum += (float)-0.50283300877;
        } else {
          sum += (float)1.3985054493;
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70826929808)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.3083629608)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.61993390322)) {
              sum += (float)0.03915745765;
            } else {
              sum += (float)-0.17611978948;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.6634815931)) {
              sum += (float)-0.38871487975;
            } else {
              sum += (float)-0.11301893741;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.71073067188)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0974056721)) {
              sum += (float)-0.43978247046;
            } else {
              sum += (float)12.150425911;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.98640280962)) {
              sum += (float)0.098019368947;
            } else {
              sum += (float)-0.050520759076;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3562912941)) {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2825655937)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3453611135)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2593873739)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.2088398933)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.97982668877)) {
              sum += (float)-0.00031870874227;
            } else {
              sum += (float)-0.058618031442;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.119772315)) {
              sum += (float)0.06363696605;
            } else {
              sum += (float)-0.21011143923;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3394815922)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
              sum += (float)-0.063085369766;
            } else {
              sum += (float)-0.23209524155;
            }
          } else {
            sum += (float)0.95216876268;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3892252445)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7400509119)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.2946374416)) {
              sum += (float)1.9434672594;
            } else {
              sum += (float)-0.15204812586;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.8169109821)) {
              sum += (float)0.44112214446;
            } else {
              sum += (float)1.197753191;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.7365611792)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5123929977)) {
              sum += (float)0.0022493796423;
            } else {
              sum += (float)-0.18898260593;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.97348129749)) {
              sum += (float)-0.02606065385;
            } else {
              sum += (float)-0.19535474479;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.70538669825)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.65987426043)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.37879174948)) {
              sum += (float)0.20494636893;
            } else {
              sum += (float)-0.091798312962;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.94583547115)) {
              sum += (float)-0.34962695837;
            } else {
              sum += (float)0.042893566191;
            }
          }
        } else {
          sum += (float)2.4134471416;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)3.3997039795)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.85403639078)) {
              sum += (float)-0.11682581902;
            } else {
              sum += (float)-0.8526301384;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0916361809)) {
              sum += (float)-0.084488213062;
            } else {
              sum += (float)-0.0047501176596;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4749244452)) {
            sum += (float)-0.21715345979;
          } else {
            sum += (float)1.8683289289;
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.815325737)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2447659969)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0529334545)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.5477392673)) {
              sum += (float)0.022969482467;
            } else {
              sum += (float)-0.087125606835;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0780823231)) {
              sum += (float)-0.81941813231;
            } else {
              sum += (float)-0.044286843389;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2465205193)) {
            sum += (float)1.3210375309;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.46257150173)) {
              sum += (float)0.15690970421;
            } else {
              sum += (float)-0.00047418809845;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.2129426003)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4184679985)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.20188055933)) {
              sum += (float)-0.54857522249;
            } else {
              sum += (float)-0.30507159233;
            }
          } else {
            sum += (float)-1.256315589;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3296723366)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2042880058)) {
              sum += (float)-0.12611731887;
            } else {
              sum += (float)-0.27529603243;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.1918489933)) {
              sum += (float)0.099897496402;
            } else {
              sum += (float)-0.20137009025;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.171659112)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.75694954395)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0546882153)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.6356401443)) {
              sum += (float)-0.12866948545;
            } else {
              sum += (float)0.049830824137;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.62371683121)) {
              sum += (float)5.1127533913;
            } else {
              sum += (float)0.38375002146;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.4749245644)) {
            sum += (float)7.7694115639;
          } else {
            sum += (float)-1.872977376;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.71428596973)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.67545115948)) {
              sum += (float)0.2397004813;
            } else {
              sum += (float)2.1250317097;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2949919701)) {
              sum += (float)-0.20728264749;
            } else {
              sum += (float)-0.76240867376;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.97600585222)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.407127142)) {
              sum += (float)-0.03861278668;
            } else {
              sum += (float)-1.1288440228;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4272408485)) {
              sum += (float)-0.077500805259;
            } else {
              sum += (float)0.013733498752;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.1715786457)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.1176805496)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.0753962994)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8004140854)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.7667760849)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.70406663418)) {
              sum += (float)0.0013008628739;
            } else {
              sum += (float)-0.010383867659;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.111810565)) {
              sum += (float)-0.17492228746;
            } else {
              sum += (float)-1.4508905411;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.82459127903)) {
              sum += (float)0.13255535066;
            } else {
              sum += (float)10.077933311;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.77994704247)) {
              sum += (float)0.00082491681678;
            } else {
              sum += (float)-0.36552080512;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6972978115)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1442732811)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
              sum += (float)0.5405600071;
            } else {
              sum += (float)0.0091025577858;
            }
          } else {
            sum += (float)14.796618462;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.90092355013)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5176047087)) {
              sum += (float)-0.22660447657;
            } else {
              sum += (float)0.070830784738;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9275846481)) {
              sum += (float)-0.085540398955;
            } else {
              sum += (float)-1.1643071175;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3317160606)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.84090912342)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2798573971)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32206079364)) {
              sum += (float)-0.10256701708;
            } else {
              sum += (float)0.054119829088;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.5890301466)) {
              sum += (float)0.68238735199;
            } else {
              sum += (float)-0.11482875049;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5988488197)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.4951019287)) {
              sum += (float)-0.028940981254;
            } else {
              sum += (float)-0.27120372653;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
              sum += (float)0.081593193114;
            } else {
              sum += (float)-0.023538032547;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.7017543316)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3870103359)) {
            sum += (float)-0.94912725687;
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0278199911)) {
              sum += (float)-0.26197654009;
            } else {
              sum += (float)-0.083144031465;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.2703170776)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.5678267479)) {
              sum += (float)-0.2431063354;
            } else {
              sum += (float)-0.061473153532;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.796908617)) {
              sum += (float)0.8096588254;
            } else {
              sum += (float)0.022857155651;
            }
          }
        }
      }
    }
  } else {
    if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.4867517948)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4255886078)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4914550781)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5886608362)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.35865584016)) {
              sum += (float)-0.14983510971;
            } else {
              sum += (float)0.091587424278;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.0741006136)) {
              sum += (float)-0.44567361474;
            } else {
              sum += (float)-0.034301336855;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.52065902948)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.87452369928)) {
              sum += (float)-0.10719677806;
            } else {
              sum += (float)0.021836349741;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3882997036)) {
              sum += (float)0.3018784523;
            } else {
              sum += (float)-0.028232017532;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.5160303116)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6150815487)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.3556091785)) {
              sum += (float)-0.30603334308;
            } else {
              sum += (float)0.025745715946;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
              sum += (float)1.1917033195;
            } else {
              sum += (float)0.10332538188;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.95619022846)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
              sum += (float)0.097316168249;
            } else {
              sum += (float)-0.18390475214;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0352038145)) {
              sum += (float)-0.27709418535;
            } else {
              sum += (float)-0.01106036175;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.48068383336)) {
        sum += (float)-0.53938019276;
      } else {
        sum += (float)-1.7728197575;
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42596885562)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26864284277)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.16687804461)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.11833509803)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.11073195189)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2497713566)) {
              sum += (float)-0.0011125205783;
            } else {
              sum += (float)0.18896313012;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.0034682005644)) {
              sum += (float)0.061192382127;
            } else {
              sum += (float)3.4304082394;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.1621992588)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.072643503547)) {
              sum += (float)-0.11978158355;
            } else {
              sum += (float)-0.027176702395;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47032904625)) {
              sum += (float)0.022376250476;
            } else {
              sum += (float)-0.33321613073;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17389634252)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17214176059)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
              sum += (float)0.54529953003;
            } else {
              sum += (float)-0.13175135851;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.51355689764)) {
              sum += (float)-0.66264098883;
            } else {
              sum += (float)9.1730270386;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0426459312)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.31431940198)) {
              sum += (float)0.074593298137;
            } else {
              sum += (float)-0.061259906739;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.63978683949)) {
              sum += (float)-0.080291420221;
            } else {
              sum += (float)2.0569224358;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7602283955)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.59445929527)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.45929551125)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.36099457741)) {
              sum += (float)-0.059505306184;
            } else {
              sum += (float)0.035701550543;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.18349024653)) {
              sum += (float)-0.055653419346;
            } else {
              sum += (float)-0.12055715173;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.63746595383)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.35100024939)) {
              sum += (float)0.023572197184;
            } else {
              sum += (float)0.45980516076;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26309210062)) {
              sum += (float)-0.014882771298;
            } else {
              sum += (float)-0.094683915377;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.3471188545)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
            sum += (float)1.751434803;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.55098199844)) {
              sum += (float)-0.1232785508;
            } else {
              sum += (float)0.57510209084;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.444205761)) {
            sum += (float)-0.30599185824;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.812101841)) {
              sum += (float)-0.12859076262;
            } else {
              sum += (float)0.0090019777417;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.52597904205)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773507148)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.056666150689)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44643878937)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.98399662971)) {
              sum += (float)1.2222838402;
            } else {
              sum += (float)-0.091115236282;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.49088779092)) {
              sum += (float)-0.040064185858;
            } else {
              sum += (float)-0.20162017643;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.013783350587)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.34256321192)) {
              sum += (float)1.8431943655;
            } else {
              sum += (float)0.34712994099;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
              sum += (float)-0.10655365139;
            } else {
              sum += (float)0.72281873226;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1982176304)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.70197916031)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.22996224463)) {
              sum += (float)0.03564113006;
            } else {
              sum += (float)-0.074898563325;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.74956548214)) {
              sum += (float)0.40460705757;
            } else {
              sum += (float)-0.042991127819;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.28327476978)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.51491641998)) {
              sum += (float)0.48680102825;
            } else {
              sum += (float)-0.020255098119;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.32675874233)) {
              sum += (float)1.7211279869;
            } else {
              sum += (float)-0.3053406775;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1726051569)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.38869035244)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.16102729738)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.45297020674)) {
              sum += (float)-0.0090779094025;
            } else {
              sum += (float)1.0251196623;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.27589070797)) {
              sum += (float)-0.31744360924;
            } else {
              sum += (float)-0.00036671382259;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.69995582104)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
              sum += (float)0.013745347969;
            } else {
              sum += (float)0.57434296608;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.74129056931)) {
              sum += (float)-0.022642895579;
            } else {
              sum += (float)-0.095254279673;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.29945790768)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7104598284)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.59967076778)) {
              sum += (float)0.28556886315;
            } else {
              sum += (float)-0.010292774998;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55872857571)) {
              sum += (float)1.9748570919;
            } else {
              sum += (float)-0.18902389705;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.28825315833)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.30030560493)) {
              sum += (float)0.017362644896;
            } else {
              sum += (float)0.86609250307;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.83653712273)) {
              sum += (float)-0.027039533481;
            } else {
              sum += (float)0.0073695504107;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.85725986958)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.39932984114)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38743555546)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38148838282)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.37554126978)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.61568188667)) {
              sum += (float)0.00068773777457;
            } else {
              sum += (float)-0.044669255614;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.52391171455)) {
              sum += (float)0.037006922066;
            } else {
              sum += (float)1.0305576324;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60571551323)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1446835995)) {
              sum += (float)-0.025589644909;
            } else {
              sum += (float)-1.2063233852;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.81615191698)) {
              sum += (float)0.20911844075;
            } else {
              sum += (float)-0.053381845355;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.31913655996)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.13486094773)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418972969)) {
              sum += (float)-0.037591613829;
            } else {
              sum += (float)-0.356079638;
            }
          } else {
            sum += (float)1.9385470152;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.3933827281)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.066401697695)) {
              sum += (float)-0.11502263695;
            } else {
              sum += (float)-0.01257096231;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.068699494004)) {
              sum += (float)0.41857811809;
            } else {
              sum += (float)0.027562590316;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.20231634378)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.62594938278)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.85937976837)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.8253031373)) {
              sum += (float)-0.022499252111;
            } else {
              sum += (float)1.2798681259;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.92101097107)) {
              sum += (float)-0.026266543195;
            } else {
              sum += (float)-0.13916185498;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.5913670063)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18695929646)) {
              sum += (float)0.58611857891;
            } else {
              sum += (float)-0.05410252884;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.96118581295)) {
              sum += (float)0.069763876498;
            } else {
              sum += (float)-0.13944938779;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.28579980135)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.084523305297)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.48231109977)) {
              sum += (float)-0.41130098701;
            } else {
              sum += (float)-0.14711143076;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
              sum += (float)2.077082634;
            } else {
              sum += (float)-0.20283438265;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.27550828457)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.10647089779)) {
              sum += (float)0.5961176157;
            } else {
              sum += (float)-0.0066483756527;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.1910533011)) {
              sum += (float)-0.27846592665;
            } else {
              sum += (float)-0.016792617738;
            }
          }
        }
      }
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.86915421486)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.025488950312)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0424060822)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.32127979398)) {
              sum += (float)0.59773677588;
            } else {
              sum += (float)-0.087432071567;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.32127979398)) {
              sum += (float)-0.40984633565;
            } else {
              sum += (float)-0.089625999331;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.99941802025)) {
            sum += (float)-0.32133233547;
          } else {
            sum += (float)-1.8013190031;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.15938639641)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7775194645)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.91296231747)) {
              sum += (float)-4.989882946;
            } else {
              sum += (float)32.915222168;
            }
          } else {
            sum += (float)-10.999173164;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.02511099726)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.55757951736)) {
              sum += (float)1.4761172533;
            } else {
              sum += (float)-0.086131557822;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.82650667429)) {
              sum += (float)-0.15609806776;
            } else {
              sum += (float)-1.5699281693;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.0041470528)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9810650349)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20216549933)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.1218854189)) {
              sum += (float)-0.15147297084;
            } else {
              sum += (float)-0.41748598218;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.16356509924)) {
              sum += (float)0.44392800331;
            } else {
              sum += (float)0.0029842909425;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.56713950634)) {
            sum += (float)0.003951898776;
          } else {
            sum += (float)1.1320803165;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2069118023)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.18673434854)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.22887268662)) {
              sum += (float)-0.0058021415025;
            } else {
              sum += (float)0.054490633309;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)-0.21998973191;
            } else {
              sum += (float)-0.3747151494;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.5556209087)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.9013395309)) {
              sum += (float)-0.071804881096;
            } else {
              sum += (float)-0.1674399823;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.7054820061)) {
              sum += (float)0.071650385857;
            } else {
              sum += (float)0.041450936347;
            }
          }
        }
      }
    }
  }
  if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.89234191179)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.42045494914)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50299245119)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.69692987204)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57409840822)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
              sum += (float)0.00092068064259;
            } else {
              sum += (float)0.17596763372;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.52391165495)) {
              sum += (float)-0.062122188509;
            } else {
              sum += (float)-0.44886931777;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.3487790823)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9029289484)) {
              sum += (float)-2.5082936287;
            } else {
              sum += (float)0.031900111586;
            }
          } else {
            sum += (float)17.898683548;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.85913050175)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.55658769608)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0950875282)) {
              sum += (float)0.010666175745;
            } else {
              sum += (float)-0.12644325197;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.43690019846)) {
              sum += (float)-0.35147532821;
            } else {
              sum += (float)-0.20752128959;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.80750632286)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.25646853447)) {
              sum += (float)1.5888581276;
            } else {
              sum += (float)2.9587666988;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.76610517502)) {
              sum += (float)0.30442795157;
            } else {
              sum += (float)-0.01051911246;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.13050690293)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24544480443)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.13488270342)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.37663784623)) {
              sum += (float)-0.0036087560002;
            } else {
              sum += (float)-0.11629056185;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.51323252916)) {
              sum += (float)-1.1503320932;
            } else {
              sum += (float)-0.25912711024;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21152320504)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.17808879912)) {
              sum += (float)-0.717258811;
            } else {
              sum += (float)-0.13274344802;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17272660136)) {
              sum += (float)-0.010690767318;
            } else {
              sum += (float)0.34914696217;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12202890217)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051774010062)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.25611320138)) {
              sum += (float)0.095668390393;
            } else {
              sum += (float)1.8652801514;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.25611320138)) {
              sum += (float)0.042911887169;
            } else {
              sum += (float)-0.18441960216;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.46904009581)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.22540549934)) {
              sum += (float)0.10921885073;
            } else {
              sum += (float)-0.030962018296;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.022468550131)) {
              sum += (float)-0.11874393374;
            } else {
              sum += (float)-0.015932556242;
            }
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.60542500019)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730372906)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.36296856403)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.66142445803)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.22263544798)) {
              sum += (float)0.011483157054;
            } else {
              sum += (float)-0.25941762328;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.39164024591)) {
              sum += (float)-0.10984925926;
            } else {
              sum += (float)-0.0085218949243;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.36187458038)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.0755190849)) {
              sum += (float)-0.25745496154;
            } else {
              sum += (float)0.73436927795;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.45929551125)) {
              sum += (float)-0.0042442479171;
            } else {
              sum += (float)0.11720123887;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25220739841)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60001266003)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.30977889895)) {
              sum += (float)0.54307550192;
            } else {
              sum += (float)-0.053358651698;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.76170617342)) {
              sum += (float)0.07659188658;
            } else {
              sum += (float)0.43193164468;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.46473154426)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.37333190441)) {
              sum += (float)0.05493478477;
            } else {
              sum += (float)0.022961257026;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.071871452034)) {
              sum += (float)-0.060437794775;
            } else {
              sum += (float)0.025666801259;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.68642550707)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65504974127)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.58369129896)) {
              sum += (float)0.039740756154;
            } else {
              sum += (float)-0.38516891003;
            }
          } else {
            sum += (float)1.6228442192;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.632350564)) {
            sum += (float)-0.91346400976;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1399607658)) {
              sum += (float)-0.0053539108485;
            } else {
              sum += (float)-0.10275177658;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.67180413008)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.25418975949)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.5333199501)) {
              sum += (float)0.067821234465;
            } else {
              sum += (float)0.24591219425;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.33463561535)) {
              sum += (float)0.23531679809;
            } else {
              sum += (float)-0.14143817127;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.63788253069)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.99941813946)) {
              sum += (float)-0.10063001513;
            } else {
              sum += (float)0.1291578114;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.80632859468)) {
              sum += (float)0.024753237143;
            } else {
              sum += (float)-0.0015378521057;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0659965277)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.84221684933)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.83344304562)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.164252162)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1654219627)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.298768878)) {
              sum += (float)-0.010657344013;
            } else {
              sum += (float)0.022365197539;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.3781139851)) {
              sum += (float)-0.074104331434;
            } else {
              sum += (float)0.38110083342;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.70783221722)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4070219994)) {
              sum += (float)0.10105246305;
            } else {
              sum += (float)-0.077671959996;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.69826030731)) {
              sum += (float)0.32046204805;
            } else {
              sum += (float)-0.052921961993;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.135594368)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.55823630095)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.303645134)) {
              sum += (float)0.026343958452;
            } else {
              sum += (float)-0.08185467124;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.5172137022)) {
              sum += (float)0.084288977087;
            } else {
              sum += (float)-0.046883251518;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.81235790253)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.84654712677)) {
              sum += (float)0.0043624211103;
            } else {
              sum += (float)-0.1231834814;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.6739320755)) {
              sum += (float)0.072607167065;
            } else {
              sum += (float)0.70327866077;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.3162646294)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.31067836285)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9913136363)) {
              sum += (float)-0.027680279687;
            } else {
              sum += (float)0.073728576303;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.0432398319)) {
              sum += (float)0.40925765038;
            } else {
              sum += (float)0.065384246409;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.268941164)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2905808687)) {
              sum += (float)-0.056307349354;
            } else {
              sum += (float)-0.36151844263;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.38621473312)) {
              sum += (float)-0.010416210629;
            } else {
              sum += (float)-0.16818338633;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.79886078835)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71603679657)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.78642177582)) {
              sum += (float)0.017935456708;
            } else {
              sum += (float)-0.26203814149;
            }
          } else {
            sum += (float)-0.41228249669;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.69401955605)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
              sum += (float)-0.15317092836;
            } else {
              sum += (float)-0.074309833348;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.77866464853)) {
              sum += (float)0.010696711019;
            } else {
              sum += (float)0.13773646951;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.239784956)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0478659868)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.61465811729)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.66187959909)) {
            sum += (float)0.09013018012;
          } else {
            sum += (float)0.79357773066;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.86672651768)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.30834057927)) {
              sum += (float)0.17096121609;
            } else {
              sum += (float)0.055563036352;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.70205450058)) {
              sum += (float)0.13982586563;
            } else {
              sum += (float)-0.19343048334;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.59261202812)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0535881519)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.7325824499)) {
              sum += (float)0.1563616544;
            } else {
              sum += (float)-0.0032120244578;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.41212850809)) {
              sum += (float)-0.10624625534;
            } else {
              sum += (float)-0.5382835269;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.61640059948)) {
            sum += (float)0.98152714968;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.317595005)) {
              sum += (float)-0.087631590664;
            } else {
              sum += (float)-0.4252744019;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0478659868)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0513751507)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0766561031)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2977836132)) {
              sum += (float)0.016969157383;
            } else {
              sum += (float)0.090013921261;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.9783551693)) {
              sum += (float)-0.083449706435;
            } else {
              sum += (float)-0.021647349;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.95448100567)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3810100555)) {
              sum += (float)-0.079866595566;
            } else {
              sum += (float)-0.0092173879966;
            }
          } else {
            sum += (float)-0.28912377357;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91627365351)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91744333506)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.0583291054)) {
              sum += (float)0.0067150373943;
            } else {
              sum += (float)0.53285527229;
            }
          } else {
            sum += (float)0.58332568407;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.89814305305)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.7535362244)) {
              sum += (float)-0.39867976308;
            } else {
              sum += (float)-0.11180634797;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.4597659111)) {
              sum += (float)-0.074044078588;
            } else {
              sum += (float)0.00057509960607;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.8369984627)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.8266443014)) {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.8232206106)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7249196768)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8553296328)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8004140854)) {
              sum += (float)4.4442058424e-06;
            } else {
              sum += (float)0.18105122447;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.22009985149)) {
              sum += (float)-0.13605125248;
            } else {
              sum += (float)-0.013841609471;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
            sum += (float)12.575716972;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.9072030783)) {
              sum += (float)0.15661492944;
            } else {
              sum += (float)-0.097512803972;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.60865819454)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0618848801)) {
              sum += (float)0.0051815602928;
            } else {
              sum += (float)-0.1802547127;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
              sum += (float)-0.48763483763;
            } else {
              sum += (float)1.4279952049;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2593405247)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
              sum += (float)-0.22490888834;
            } else {
              sum += (float)-0.78534698486;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6641792059)) {
              sum += (float)-0.18170057237;
            } else {
              sum += (float)-0.029298972338;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.65904259682)) {
        sum += (float)-0.6580812335;
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.070886895061)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.017065649852)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.1719770432)) {
              sum += (float)-0.19630582631;
            } else {
              sum += (float)-0.075783841312;
            }
          } else {
            sum += (float)-0.3760150671;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.5232591629)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.4460582733)) {
              sum += (float)-0.066747881472;
            } else {
              sum += (float)-0.13782998919;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.9197912216)) {
              sum += (float)0.031838882715;
            } else {
              sum += (float)0.0657498613;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.7228958607)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.22996224463)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.057050801814)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9634286165)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.4928956032)) {
              sum += (float)-0.041544236243;
            } else {
              sum += (float)0.18022020161;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.9842436314)) {
              sum += (float)0.55792057514;
            } else {
              sum += (float)0.031631395221;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63574171066)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.63885951042)) {
              sum += (float)-0.004330673255;
            } else {
              sum += (float)1.4665170908;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22196009755)) {
              sum += (float)-0.22256964445;
            } else {
              sum += (float)-0.021691914648;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.35100024939)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3751887083)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.60609602928)) {
              sum += (float)-0.17534729838;
            } else {
              sum += (float)1.0433466434;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.6927235126)) {
              sum += (float)-0.21860310435;
            } else {
              sum += (float)0.15536524355;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1973927021)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.75582718849)) {
              sum += (float)-0.045384690166;
            } else {
              sum += (float)0.17477020621;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3108546734)) {
              sum += (float)-0.069345653057;
            } else {
              sum += (float)0.0141694583;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)3.5966584682)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.7128109932)) {
          sum += (float)-0.13612470031;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.1233422756)) {
            sum += (float)-0.24335053563;
          } else {
            sum += (float)-0.47252464294;
          }
        }
      } else {
        sum += (float)-0.058225855231;
      }
    }
  }
  if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3020131588)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.068582654)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.99077254534)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.85244333744)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9515287876)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8062269688)) {
              sum += (float)-0.0014090728946;
            } else {
              sum += (float)0.038850221783;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9846203327)) {
              sum += (float)0.79018336535;
            } else {
              sum += (float)0.0011655150447;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4115855694)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.91510391235)) {
              sum += (float)0.42555317283;
            } else {
              sum += (float)-0.045446254313;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.93025350571)) {
              sum += (float)-0.41368812323;
            } else {
              sum += (float)-0.056212913245;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7921903133)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7582688332)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.16359853745)) {
              sum += (float)-0.093772761524;
            } else {
              sum += (float)0.12139295042;
            }
          } else {
            sum += (float)3.7061209679;
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7567404509)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6294686794)) {
              sum += (float)-0.080678232014;
            } else {
              sum += (float)-0.26609891653;
            }
          } else {
            sum += (float)-0.79427546263;
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.54828882217)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.57286399603)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.66186159849)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.111810565)) {
              sum += (float)-0.39150798321;
            } else {
              sum += (float)0.028720872477;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.1884980202)) {
              sum += (float)0.015579541214;
            } else {
              sum += (float)-0.31907194853;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.26103970408)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.20723305643)) {
              sum += (float)-0.75049757957;
            } else {
              sum += (float)1.4604645967;
            }
          } else {
            sum += (float)-0.13270880282;
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0605742931)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.8759269714)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7451703548)) {
              sum += (float)-0.11577990651;
            } else {
              sum += (float)-0.56120145321;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)3.284740448)) {
              sum += (float)2.8586192131;
            } else {
              sum += (float)-0.20792807639;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.30030560493)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2414940596)) {
              sum += (float)-0.0550407134;
            } else {
              sum += (float)-0.21789503098;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3945910931)) {
              sum += (float)-0.018572553992;
            } else {
              sum += (float)0.084501639009;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.094734698534)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.088007003069)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.14226675034)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.66818237305)) {
            sum += (float)0.94155913591;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.61565804482)) {
              sum += (float)-0.37530252337;
            } else {
              sum += (float)0.028593234718;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.13832855225)) {
            sum += (float)-1.3361190557;
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.90092360973)) {
              sum += (float)-0.17855711281;
            } else {
              sum += (float)-0.049447610974;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.93708097935)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7775194645)) {
            sum += (float)26.332365036;
          } else {
            sum += (float)-9.328745842;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.8410160542)) {
            sum += (float)-0.092168688774;
          } else {
            sum += (float)0.74527966976;
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.23021879792)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.22584304214)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.12438040227)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7104598284)) {
              sum += (float)-0.11635775119;
            } else {
              sum += (float)-0.75424391031;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.8980100155)) {
              sum += (float)-0.10631110519;
            } else {
              sum += (float)0.07521212101;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.17777556181)) {
            sum += (float)-0.20042401552;
          } else {
            sum += (float)-1.1575703621;
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7249196768)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.025111000985)) {
              sum += (float)0.02560098283;
            } else {
              sum += (float)0.97006541491;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.061268404126)) {
              sum += (float)-0.60392397642;
            } else {
              sum += (float)-0.0051749632694;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.3554058075)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7372072935)) {
              sum += (float)10.689359665;
            } else {
              sum += (float)0.10105273873;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.6911125183)) {
              sum += (float)-0.046222239733;
            } else {
              sum += (float)0.035136371851;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.2204861641)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.2643852234)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.3355007172)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9988415241)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9515287876)) {
              sum += (float)1.528379471e-05;
            } else {
              sum += (float)0.21806882322;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.32201701403)) {
              sum += (float)-0.033189553767;
            } else {
              sum += (float)-0.10602668673;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.038050450385)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.89282774925)) {
              sum += (float)7.3191561699;
            } else {
              sum += (float)-0.026046995074;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5075223446)) {
              sum += (float)0.1199856475;
            } else {
              sum += (float)-0.00094104051823;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.83262622356)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.43942055106)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.0887601376)) {
              sum += (float)-0.15059654415;
            } else {
              sum += (float)0.023541694507;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8715200424)) {
              sum += (float)0.012961084954;
            } else {
              sum += (float)-0.11598847806;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3781130314)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)-0.68561434746;
            } else {
              sum += (float)-0.26371619105;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
              sum += (float)-0.012847150676;
            } else {
              sum += (float)-0.075539119542;
            }
          }
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.77399992943)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6478359699)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.0177249908)) {
              sum += (float)-0.12775346637;
            } else {
              sum += (float)-0.30575099587;
            }
          } else {
            sum += (float)0.56254541874;
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.46703475714)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.1502008438)) {
              sum += (float)-0.076393827796;
            } else {
              sum += (float)0.1645822823;
            }
          } else {
            sum += (float)-0.39307013154;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
          sum += (float)8.5414171219;
        } else {
          sum += (float)-0.98525065184;
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.6739474535)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.63534700871)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.51545166969)) {
            sum += (float)0.083789855242;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.59440720081)) {
              sum += (float)-0.52441602945;
            } else {
              sum += (float)-0.24339295924;
            }
          }
        } else {
          sum += (float)-0.9066503644;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
          sum += (float)0.4957036078;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0599371195)) {
            sum += (float)0.15341693163;
          } else {
            sum += (float)-0.55001854897;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1518764496)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3931541443)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9446716309)) {
              sum += (float)0.00037489677197;
            } else {
              sum += (float)-0.067196503282;
            }
          } else {
            sum += (float)-0.56173700094;
          }
        } else {
          sum += (float)0.098746277392;
        }
      } else {
        sum += (float)0.33202973008;
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7001972198)) {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.2367353439)) {
      sum += (float)0.78173011541;
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7035883665)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-2.3506689072)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5015347004)) {
            sum += (float)-0.021890640259;
          } else {
            sum += (float)-0.086999900639;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.0870512724)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2609703541)) {
              sum += (float)0.054722122848;
            } else {
              sum += (float)0.010958213359;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.22146575153)) {
              sum += (float)0.097794353962;
            } else {
              sum += (float)0.037623785436;
            }
          }
        }
      } else {
        sum += (float)0.1605912596;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4118354321)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14657625556)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.081278346479)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.55816024542)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2283625603)) {
              sum += (float)-0.0073152035475;
            } else {
              sum += (float)-0.088324420154;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5231435299)) {
              sum += (float)-0.0091408668086;
            } else {
              sum += (float)0.046441372484;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.02912850678)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.70981240273)) {
              sum += (float)0.023173831403;
            } else {
              sum += (float)-0.013355314732;
            }
          } else {
            sum += (float)-0.38197219372;
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.86776673794)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109618932)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.34077620506)) {
              sum += (float)0.0045468304306;
            } else {
              sum += (float)0.072475522757;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.079066298902)) {
              sum += (float)-0.097617506981;
            } else {
              sum += (float)-0.027303995565;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.77292400599)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2438242435)) {
              sum += (float)-0.31617388129;
            } else {
              sum += (float)-0.13065847754;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2765334845)) {
              sum += (float)-0.048836093396;
            } else {
              sum += (float)0.0089577119797;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4096474648)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.4991519451)) {
          sum += (float)1.632291317;
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.1551202536)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.77436929941)) {
              sum += (float)0.024732500315;
            } else {
              sum += (float)0.082682646811;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.5523271561)) {
              sum += (float)-0.0069193360396;
            } else {
              sum += (float)0.016836129129;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3959186077)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.3967938423)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-1.2361346483)) {
              sum += (float)0.26062199473;
            } else {
              sum += (float)-0.018429914489;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.2830127478)) {
              sum += (float)0.94686108828;
            } else {
              sum += (float)-0.21403557062;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7048155069)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2630730867)) {
              sum += (float)-0.15221606195;
            } else {
              sum += (float)-0.010193767957;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6879017353)) {
              sum += (float)1.4604084492;
            } else {
              sum += (float)0.00013985236001;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.8388898373)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7492603064)) {
      sum += (float)0.62538415194;
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-3.3325028419)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.2221529484)) {
          sum += (float)-0.16303358972;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5596710443)) {
            sum += (float)-0.086785979569;
          } else {
            sum += (float)-0.008594959043;
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.5322778225)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-2.3853793144)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.2367353439)) {
              sum += (float)0.0081206355244;
            } else {
              sum += (float)-0.0088778706267;
            }
          } else {
            sum += (float)0.039081208408;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.7239367962)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.27498134971)) {
              sum += (float)0.079214408994;
            } else {
              sum += (float)0.11780245602;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.618041873)) {
              sum += (float)-0.003832136048;
            } else {
              sum += (float)0.081501215696;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.9113185406)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.8316682577)) {
        sum += (float)0.13612399995;
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.6879017353)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.9836332798)) {
            sum += (float)-0.52740651369;
          } else {
            sum += (float)-0.035396527499;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.6028988361)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.080053091)) {
              sum += (float)0.011366892606;
            } else {
              sum += (float)0.12299120426;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.28112512827)) {
              sum += (float)-0.17981623113;
            } else {
              sum += (float)-0.077668264508;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.5856077671)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.94083756208)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.92985677719)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.76555585861)) {
              sum += (float)-0.010261001065;
            } else {
              sum += (float)-0.43956425786;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.93506884575)) {
              sum += (float)-0.29814729095;
            } else {
              sum += (float)-0.078603774309;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.201854229)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.2102775574)) {
              sum += (float)0.0017729903338;
            } else {
              sum += (float)3.5435607433;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.14954979718)) {
              sum += (float)0.011609810404;
            } else {
              sum += (float)-0.80871164799;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1135189533)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.5948765278)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.1648370028)) {
              sum += (float)0.55741280317;
            } else {
              sum += (float)-0.38173446059;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1872446537)) {
              sum += (float)-0.00051941414131;
            } else {
              sum += (float)0.028257414699;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1012313366)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.60161721706)) {
              sum += (float)-0.17845323682;
            } else {
              sum += (float)-0.011876660399;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5176045895)) {
              sum += (float)0.24627456069;
            } else {
              sum += (float)-0.00038367052912;
            }
          }
        }
      }
    }
  }
  if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.815325737)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.76458466053)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.88800442219)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.87864673138)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.80056995153)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.6244413853)) {
              sum += (float)-0.0013767002383;
            } else {
              sum += (float)0.040358539671;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.50682127476)) {
              sum += (float)1.8826992512;
            } else {
              sum += (float)0.012582664378;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.5232796073)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.017076000571)) {
              sum += (float)0.74300825596;
            } else {
              sum += (float)0.50679630041;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.3864951134)) {
              sum += (float)-0.058678895235;
            } else {
              sum += (float)0.07556643337;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.74869656563)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.1786773205)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0663852692)) {
              sum += (float)-0.0073983417824;
            } else {
              sum += (float)-0.13365700841;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1383099556)) {
              sum += (float)0.05389405787;
            } else {
              sum += (float)-0.036659099162;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.4829087257)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.67289847136)) {
              sum += (float)-0.23272313178;
            } else {
              sum += (float)-0.10328406096;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5116245747)) {
              sum += (float)0.4590986073;
            } else {
              sum += (float)-0.36133670807;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.83653342724)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.53255724907)) {
          sum += (float)-0.90838116407;
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6366188526)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.9385124445)) {
              sum += (float)-0.0045407116413;
            } else {
              sum += (float)-0.089934997261;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6512403488)) {
              sum += (float)0.21291774511;
            } else {
              sum += (float)-0.040378846228;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1526812315)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.85403639078)) {
            sum += (float)-0.23240783811;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0495266914)) {
              sum += (float)-0.62572789192;
            } else {
              sum += (float)-0.35093057156;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.2235136032)) {
            sum += (float)-0.036219943315;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2746958733)) {
              sum += (float)-0.19222532213;
            } else {
              sum += (float)-0.38531923294;
            }
          }
        }
      }
    }
  } else {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.84069633484)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7921903133)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.7442322969)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6214127541)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.53908771276)) {
              sum += (float)-0.053978465497;
            } else {
              sum += (float)0.094172693789;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.5353320837)) {
              sum += (float)-0.10756433755;
            } else {
              sum += (float)1.5161088705;
            }
          }
        } else {
          sum += (float)-1.6341538429;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
          sum += (float)1.4434086084;
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.53131461143)) {
            sum += (float)0.088191829622;
          } else {
            sum += (float)-0.27270942926;
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.97600585222)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4115855694)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.44059026241)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.085108548403)) {
              sum += (float)0.037298526615;
            } else {
              sum += (float)-0.11121657491;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.51837599277)) {
              sum += (float)0.3915848434;
            } else {
              sum += (float)-0.036858029664;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
            sum += (float)-2.4216704369;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6214127541)) {
              sum += (float)-0.27872139215;
            } else {
              sum += (float)-0.56293451786;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.64431595802)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.111810565)) {
            sum += (float)-0.27711898088;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.7077126503)) {
              sum += (float)0.051596786827;
            } else {
              sum += (float)-0.11966946721;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.091015353799)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.089647904038)) {
              sum += (float)0.015577397309;
            } else {
              sum += (float)11.834751129;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.23185969889)) {
              sum += (float)-0.091350756586;
            } else {
              sum += (float)0.0029674135149;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.45880129933)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.6779243946)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.5595285892)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38743555546)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.38148838282)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.92622482777)) {
              sum += (float)0.0029131984338;
            } else {
              sum += (float)-0.010681461543;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.60571551323)) {
              sum += (float)-0.59737420082;
            } else {
              sum += (float)-0.030210833997;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32323050499)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.13486094773)) {
              sum += (float)0.022869313136;
            } else {
              sum += (float)1.3277792931;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.018268499523)) {
              sum += (float)-0.039880223572;
            } else {
              sum += (float)0.022940639406;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.589756012)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.055925950408)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.48679453135)) {
              sum += (float)0.065854340792;
            } else {
              sum += (float)-0.031828261912;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5613801479)) {
              sum += (float)-0.39321056008;
            } else {
              sum += (float)-0.22668722272;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7064882517)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6301856041)) {
              sum += (float)0.04033947736;
            } else {
              sum += (float)-0.003248949768;
            }
          } else {
            sum += (float)-0.065615586936;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8207473755)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.32537382841)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.36709463596)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.35675030947)) {
              sum += (float)-0.028449324891;
            } else {
              sum += (float)0.065845832229;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.54045987129)) {
              sum += (float)-0.32249546051;
            } else {
              sum += (float)-0.14861644804;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)3.3471188545)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.049215901643)) {
              sum += (float)1.245952487;
            } else {
              sum += (float)0.24549037218;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.38678359985)) {
              sum += (float)-0.22755713761;
            } else {
              sum += (float)-0.1446647495;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.915848732)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.3922533989)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.16120259464)) {
              sum += (float)0.018042879179;
            } else {
              sum += (float)-0.031935803592;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.4893403053)) {
              sum += (float)-0.54955506325;
            } else {
              sum += (float)-0.13652512431;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6367483139)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.608032465)) {
              sum += (float)0.024302301928;
            } else {
              sum += (float)1.6929169893;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.7082595825)) {
              sum += (float)-0.083068139851;
            } else {
              sum += (float)0.026270050555;
            }
          }
        }
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.40627995133)) {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.80026638508)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.64520430565)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.71548974514)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.01211379841)) {
              sum += (float)0.031967002898;
            } else {
              sum += (float)-0.36077710986;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.42710119486)) {
              sum += (float)-0.2800103724;
            } else {
              sum += (float)0.50638437271;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.098569497466)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.42710119486)) {
              sum += (float)0.019157161936;
            } else {
              sum += (float)-0.084263041615;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.70560777187)) {
              sum += (float)-0.65983057022;
            } else {
              sum += (float)-0.14219783247;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.71240508556)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.79993259907)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.79021519423)) {
              sum += (float)-0.15141217411;
            } else {
              sum += (float)0.56007581949;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.081710577)) {
              sum += (float)-0.67827033997;
            } else {
              sum += (float)-0.34020239115;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.6342420578)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.48231109977)) {
              sum += (float)-0.23642279208;
            } else {
              sum += (float)-0.087737672031;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.79567533731)) {
              sum += (float)0.10093974322;
            } else {
              sum += (float)-0.099180422723;
            }
          }
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.3158004284)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.317595005)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.58870249987)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2051677704)) {
              sum += (float)0.036479435861;
            } else {
              sum += (float)-0.15524463356;
            }
          } else {
            sum += (float)0.24003702402;
          }
        } else {
          sum += (float)0.6977571249;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.1879115105)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.67289841175)) {
            sum += (float)-0.063115105033;
          } else {
            sum += (float)-0.49253311753;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.2143182755)) {
            sum += (float)0.85250502825;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.5599027276)) {
              sum += (float)-0.02363445051;
            } else {
              sum += (float)0.0019332809607;
            }
          }
        }
      }
    }
  }
  if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8062269688)) {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2390909195)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6483160257)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.6296007633)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.5793031454)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.99971175194)) {
              sum += (float)-0.0006093744887;
            } else {
              sum += (float)0.010270517319;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2949919701)) {
              sum += (float)-0.033173013479;
            } else {
              sum += (float)-0.20553044975;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.2587852478)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.99332582951)) {
              sum += (float)1.078912735;
            } else {
              sum += (float)0.14133256674;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3037312031)) {
              sum += (float)-0.054626759142;
            } else {
              sum += (float)-0.41332861781;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.86606687307)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.129948616)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.79192435741)) {
              sum += (float)-0.016706764698;
            } else {
              sum += (float)-0.20835013688;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.69692987204)) {
              sum += (float)-0.17408216;
            } else {
              sum += (float)-1.1599773169;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.0098333359)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2186598778)) {
              sum += (float)-0.036469474435;
            } else {
              sum += (float)2.6785161495;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.041180953383)) {
              sum += (float)0.5286257267;
            } else {
              sum += (float)-0.07185677439;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)4.380068779)) {
          sum += (float)2.4459342957;
        } else {
          sum += (float)0.11333416402;
        }
      } else {
        sum += (float)-0.078883603215;
      }
    }
  } else {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.813830018)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.86973452568)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1905374527)) {
          sum += (float)0.081318877637;
        } else {
          sum += (float)1.0206459761;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8114905357)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2628521919)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.1624150276)) {
              sum += (float)-0.0080660302192;
            } else {
              sum += (float)-0.14007425308;
            }
          } else {
            sum += (float)-0.39958417416;
          }
        } else {
          sum += (float)0.61372792721;
        }
      }
    } else {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.70538669825)) {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.66310244799)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)3.2836945057)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8647124767)) {
              sum += (float)-0.077992446721;
            } else {
              sum += (float)0.041902001947;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.21742020547)) {
              sum += (float)-0.31320628524;
            } else {
              sum += (float)-0.082065112889;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0343203545)) {
            sum += (float)1.6991425753;
          } else {
            sum += (float)-1.4765979052;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.1291017532)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9594590664)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)-0.14759899676;
            } else {
              sum += (float)-0.056286167353;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9805138111)) {
              sum += (float)0.14479969442;
            } else {
              sum += (float)-0.034730009735;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2641685009)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2553956509)) {
              sum += (float)0.027397418395;
            } else {
              sum += (float)0.90630692244;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
              sum += (float)-0.030264779925;
            } else {
              sum += (float)0.046177364886;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.10507290065)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12366980314)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.14111810923)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.18405514956)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22398385406)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22611699998)) {
              sum += (float)0.0007302313461;
            } else {
              sum += (float)0.12306001037;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.92920482159)) {
              sum += (float)-0.19286631048;
            } else {
              sum += (float)-0.021984020248;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.1831253022)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.23332366347)) {
              sum += (float)1.588724494;
            } else {
              sum += (float)-0.16351781785;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.2628521919)) {
              sum += (float)0.01297903154;
            } else {
              sum += (float)0.45750203729;
            }
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8207473755)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.68345248699)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.18403500319)) {
              sum += (float)-0.041714217514;
            } else {
              sum += (float)0.15358702838;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.21652320027)) {
              sum += (float)-0.23458974063;
            } else {
              sum += (float)-0.022415952757;
            }
          }
        } else {
          sum += (float)-1.0220628977;
        }
      }
    } else {
      if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.11377680302)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.15233704448)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.1177502498)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.23689860106)) {
              sum += (float)0.16258296371;
            } else {
              sum += (float)0.057131737471;
            }
          } else {
            sum += (float)-0.074835367501;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.38990402222)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.16079768538)) {
              sum += (float)-0.32468056679;
            } else {
              sum += (float)-0.069516152143;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.35344684124)) {
              sum += (float)0.069224707782;
            } else {
              sum += (float)-0.046520765871;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.064186647534)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.34064543247)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.073320835829)) {
              sum += (float)0.15865476429;
            } else {
              sum += (float)-0.054733328521;
            }
          } else {
            sum += (float)1.3092619181;
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11688739806)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.56713950634)) {
              sum += (float)-0.085496917367;
            } else {
              sum += (float)-0.26347538829;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.2378771305)) {
              sum += (float)0.12354787439;
            } else {
              sum += (float)0.044084653258;
            }
          }
        }
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.041733451188)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.040913000703)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.9783551693)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24076594412)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.090031251311)) {
              sum += (float)0.085753105581;
            } else {
              sum += (float)-0.12140976638;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.23608709872)) {
              sum += (float)-0.77724933624;
            } else {
              sum += (float)-0.11244898289;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.95377999544)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.2109619081)) {
              sum += (float)0.86985635757;
            } else {
              sum += (float)-0.31710374355;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.42129004002)) {
              sum += (float)-0.041223470122;
            } else {
              sum += (float)0.018036177382;
            }
          }
        }
      } else {
        sum += (float)-0.94262361526;
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.097797751427)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.097250804305)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.665127039)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.61903452873)) {
              sum += (float)0.058832619339;
            } else {
              sum += (float)-0.097780272365;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.6271833181)) {
              sum += (float)9.4011688232;
            } else {
              sum += (float)-0.89630329609;
            }
          }
        } else {
          sum += (float)14.208963394;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.42090135813)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.037295550108)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.1179487705)) {
              sum += (float)-0.09201503545;
            } else {
              sum += (float)0.025038281456;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1049503535)) {
              sum += (float)0.34666594863;
            } else {
              sum += (float)-0.033326260746;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.52085649967)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.47897458076)) {
              sum += (float)-0.0012013667729;
            } else {
              sum += (float)0.60124057531;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.08955720067)) {
              sum += (float)-0.045031264424;
            } else {
              sum += (float)0.001118435408;
            }
          }
        }
      }
    }
  }
  if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.10746610165)) {
    if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.054209250957)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)2.5589373112)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.17214176059)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.080515652895)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.10215529799)) {
              sum += (float)-0.0014019210357;
            } else {
              sum += (float)0.22914707661;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.44516456127)) {
              sum += (float)-0.054594002664;
            } else {
              sum += (float)-0.18871456385;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.22809380293)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7336001396)) {
              sum += (float)-0.014978083782;
            } else {
              sum += (float)0.22175908089;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.1516585052)) {
              sum += (float)2.7680830956;
            } else {
              sum += (float)10.798812866;
            }
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.50921499729)) {
          sum += (float)6.2279391289;
        } else {
          sum += (float)0.063032157719;
        }
      }
    } else {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.56584990025)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.36099457741)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.1049503535)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.0705122948)) {
              sum += (float)0.95297825336;
            } else {
              sum += (float)0.053738500923;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.5969427824)) {
              sum += (float)-0.033827181906;
            } else {
              sum += (float)0.035138290375;
            }
          }
        } else {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2630730867)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.49001455307)) {
              sum += (float)-0.11224187165;
            } else {
              sum += (float)1.1082010269;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.57847368717)) {
              sum += (float)-0.028407884762;
            } else {
              sum += (float)0.016181822866;
            }
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.29866659641)) {
          if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.032785601914)) {
            sum += (float)-0.46934184432;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.32030624151)) {
              sum += (float)-0.11311563104;
            } else {
              sum += (float)-0.27120745182;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.1012313366)) {
            sum += (float)-0.12360925227;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.049322150648)) {
              sum += (float)-0.077061474323;
            } else {
              sum += (float)0.016663724557;
            }
          }
        }
      }
    }
  } else {
    if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.087378695607)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.31215515733)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.53908771276)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)-0.57159763575)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.044355798513)) {
              sum += (float)-0.090271234512;
            } else {
              sum += (float)-0.22076326609;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.43142876029)) {
              sum += (float)-0.48876401782;
            } else {
              sum += (float)-0.032036624849;
            }
          }
        } else {
          sum += (float)-2.2572870255;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.20625948906)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.21620205045)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-0.0019249022007)) {
              sum += (float)-0.017111549154;
            } else {
              sum += (float)-0.14384526014;
            }
          } else {
            sum += (float)1.1257263422;
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.86023342609)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.2574582994)) {
              sum += (float)0.31009224057;
            } else {
              sum += (float)-0.063837960362;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773935556)) {
              sum += (float)-0.18092115223;
            } else {
              sum += (float)0.7944431901;
            }
          }
        }
      }
    } else {
      if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.007633799687)) {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.019921399653)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.18051666021)) {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.15569144487)) {
              sum += (float)0.23867528141;
            } else {
              sum += (float)-0.083956599236;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)-1.7470997572)) {
              sum += (float)-0.20243068039;
            } else {
              sum += (float)0.0051210406236;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.49810221791)) {
            sum += (float)-0.59548568726;
          } else {
            sum += (float)1.3513026237;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.33063745499)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.16921745241)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.16395381093)) {
              sum += (float)-0.0087525527924;
            } else {
              sum += (float)0.24241445959;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.92622482777)) {
              sum += (float)-0.094175994396;
            } else {
              sum += (float)0.0073198652826;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.21968704462)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.48620894551)) {
              sum += (float)-0.64919376373;
            } else {
              sum += (float)0.35100567341;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.74698734283)) {
              sum += (float)-0.22244644165;
            } else {
              sum += (float)0.00013736847905;
            }
          }
        }
      }
    }
  }
  if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6641790867)) {
    if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9120857716)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.2108443975)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0652154684)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0125784874)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.99971175194)) {
              sum += (float)0.00067367270822;
            } else {
              sum += (float)0.13678120077;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0535184145)) {
              sum += (float)-0.10091124475;
            } else {
              sum += (float)-0.022442832589;
            }
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)1.6356401443)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0821763277)) {
              sum += (float)2.881957531;
            } else {
              sum += (float)0.058310177177;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3562912941)) {
              sum += (float)-0.16415345669;
            } else {
              sum += (float)-1.9500206709;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.10909854621)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.4898202419)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3512096405)) {
              sum += (float)-0.21067345142;
            } else {
              sum += (float)-0.4148516953;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.51756978035)) {
              sum += (float)-0.020423753187;
            } else {
              sum += (float)-0.13782314956;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.35100024939)) {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)0.92622482777)) {
              sum += (float)1.3905977011;
            } else {
              sum += (float)0.018744053319;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.594758153)) {
              sum += (float)-0.016174888238;
            } else {
              sum += (float)-0.11646046489;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.9155948162)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8207473755)) {
          sum += (float)1.2224582434;
        } else {
          sum += (float)-0.41816619039;
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2641685009)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2553956509)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9619626999)) {
              sum += (float)0.015101623721;
            } else {
              sum += (float)1.8364280462;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.7285261154)) {
              sum += (float)8.9491214752;
            } else {
              sum += (float)-0.13355015218;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.9645280838)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.89294272661)) {
              sum += (float)-0.0019899532199;
            } else {
              sum += (float)-0.076347015798;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.513767004)) {
              sum += (float)1.3651317358;
            } else {
              sum += (float)0.036727584898;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.43745595217)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.27319008112)) {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.046382702887)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.47977548838)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.43766593933)) {
              sum += (float)-0.016394015402;
            } else {
              sum += (float)0.16371622682;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.7104598284)) {
              sum += (float)-0.071148365736;
            } else {
              sum += (float)0.0033657080494;
            }
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.81138837337)) {
            sum += (float)0.37575665116;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.4391999245)) {
              sum += (float)0.063602127135;
            } else {
              sum += (float)-0.15188379586;
            }
          }
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6988897324)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.552493155)) {
            sum += (float)2.1246240139;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)2.3761632442)) {
              sum += (float)0.066728971899;
            } else {
              sum += (float)-0.98020017147;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)1.1070399284)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.0798368454)) {
              sum += (float)0.2804235816;
            } else {
              sum += (float)0.082523562014;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.61337077618)) {
              sum += (float)-0.41699758172;
            } else {
              sum += (float)-0.049337662756;
            }
          }
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.21717560291)) {
        sum += (float)-1.2108972073;
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.54505431652)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.91296237707)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.7832788229)) {
              sum += (float)-0.13597658277;
            } else {
              sum += (float)-0.37914225459;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.65874117613)) {
              sum += (float)0.0085606146604;
            } else {
              sum += (float)0.090799383819;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.46497815847)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.69682312012)) {
              sum += (float)0.28367444873;
            } else {
              sum += (float)-0.090242654085;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.3412671089)) {
              sum += (float)-0.051764011383;
            } else {
              sum += (float)0.0025143390521;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6485081911)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6391550303)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.7631144524)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.7025957108)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.2191627026)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.0389993191)) {
              sum += (float)0.00066881021485;
            } else {
              sum += (float)-0.015330527909;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.3882997036)) {
              sum += (float)0.12202269584;
            } else {
              sum += (float)-0.0046781604178;
            }
          }
        } else {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.4914550781)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.1998343468)) {
              sum += (float)-0.012862642296;
            } else {
              sum += (float)-0.13187424839;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.7925015688)) {
              sum += (float)-0.24299772084;
            } else {
              sum += (float)0.17452207208;
            }
          }
        }
      } else {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.4444668889)) {
            sum += (float)-0.33714428544;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)3.1608109474)) {
              sum += (float)0.52154183388;
            } else {
              sum += (float)-0.01124570705;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)2.4637265205)) {
              sum += (float)0.1386577338;
            } else {
              sum += (float)10.046813965;
            }
          } else {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)1.6526089907)) {
              sum += (float)-4.9373145103;
            } else {
              sum += (float)0.050670869648;
            }
          }
        }
      }
    } else {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.86476612091)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.18179304898)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.095413699746)) {
            sum += (float)-0.014905530028;
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6478359699)) {
              sum += (float)0.02045452036;
            } else {
              sum += (float)0.043077025563;
            }
          }
        } else {
          sum += (float)0.094963140786;
        }
      } else {
        sum += (float)7.6067528725;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.6498756409)) {
      sum += (float)-0.83351159096;
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8481516838)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.3826674819)) {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.26080304384)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.16181054711)) {
              sum += (float)-0.042675007135;
            } else {
              sum += (float)0.023652015254;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.40476030111)) {
              sum += (float)-0.71106302738;
            } else {
              sum += (float)-0.12389140576;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.7358591557)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.731045723)) {
              sum += (float)-0.02992599085;
            } else {
              sum += (float)0.17753045261;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)1.0053782463)) {
              sum += (float)-0.036891952157;
            } else {
              sum += (float)-0.09075819701;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.8514335155)) {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.0077414513)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6046080589)) {
              sum += (float)-0.19322942197;
            } else {
              sum += (float)1.1042357683;
            }
          } else {
            sum += (float)-0.30412083864;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.06569635123)) {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.21025234461)) {
              sum += (float)-0.063296414912;
            } else {
              sum += (float)0.25854197145;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)1.9818855524)) {
              sum += (float)-0.095191583037;
            } else {
              sum += (float)-0.0066678756848;
            }
          }
        }
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.265337944)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.9929475784)) {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.6899266243)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.7631144524)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.632042408)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)2.2384347916)) {
              sum += (float)-0.00017444367404;
            } else {
              sum += (float)0.025705166161;
            }
          } else {
            if (!(data[3].missing != -1) || (data[3].fvalue < (float)2.1430511475)) {
              sum += (float)0.013338784687;
            } else {
              sum += (float)-0.07564149797;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)2.2786271572)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.4444668889)) {
              sum += (float)-0.25285822153;
            } else {
              sum += (float)0.018282780424;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.72878062725)) {
              sum += (float)5.7717671394;
            } else {
              sum += (float)-1.3668141365;
            }
          }
        }
      } else {
        if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.52985739708)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8715200424)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)4.8064308167)) {
              sum += (float)-0.043666183949;
            } else {
              sum += (float)0.28510388732;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.16371101141)) {
              sum += (float)-0.010872574523;
            } else {
              sum += (float)-0.14710326493;
            }
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.31035262346)) {
              sum += (float)-0.074303582311;
            } else {
              sum += (float)-1.2306953669;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.9360260963)) {
              sum += (float)-0.035209514201;
            } else {
              sum += (float)-0.20692846179;
            }
          }
        }
      }
    } else {
      if (!(data[7].missing != -1) || (data[7].fvalue < (float)5.002245903)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.8639752865)) {
          sum += (float)6.825732708;
        } else {
          sum += (float)-0.81501483917;
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.6478359699)) {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.3884687424)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.95515632629)) {
              sum += (float)-0.35931044817;
            } else {
              sum += (float)-0.12795446813;
            }
          } else {
            sum += (float)0.39929583669;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.40900802612)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)2.3654184341)) {
              sum += (float)0.036248732358;
            } else {
              sum += (float)0.17588815093;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)0.46703475714)) {
              sum += (float)-0.11263687909;
            } else {
              sum += (float)-0.28531941772;
            }
          }
        }
      }
    }
  } else {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.5786713362)) {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.6739474535)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.63534700871)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.51545166969)) {
            sum += (float)0.066599860787;
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)0.59440720081)) {
              sum += (float)-0.38557377458;
            } else {
              sum += (float)-0.17718058825;
            }
          }
        } else {
          sum += (float)-0.77129662037;
        }
      } else {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.22947844863)) {
          sum += (float)0.36713296175;
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.0599371195)) {
            sum += (float)0.097120001912;
          } else {
            sum += (float)-0.35766321421;
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)6.7573685646)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)5.8409380913)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)1.3931541443)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)1.8395637274)) {
              sum += (float)-0.020243925974;
            } else {
              sum += (float)0.084101624787;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)1.7948106527)) {
              sum += (float)-0.4552154839;
            } else {
              sum += (float)-0.0070313592441;
            }
          }
        } else {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.46904009581)) {
            sum += (float)-0.057214453816;
          } else {
            sum += (float)-0.45227196813;
          }
        }
      } else {
        sum += (float)0.25635224581;
      }
    }
  }
  if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25937271118)) {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.26708495617)) {
      if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.18106199801)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.019025249407)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.28305643797)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.31986743212)) {
              sum += (float)0.0032452838495;
            } else {
              sum += (float)-0.051293499768;
            }
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)0.45582771301)) {
              sum += (float)0.04796852544;
            } else {
              sum += (float)0.779910326;
            }
          }
        } else {
          if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2798583508)) {
            sum += (float)-1.1485430002;
          } else {
            if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.1965985298)) {
              sum += (float)0.73377501965;
            } else {
              sum += (float)-0.051014009863;
            }
          }
        }
      } else {
        if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.21488940716)) {
          sum += (float)0.76492959261;
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.54866433144)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.57212924957)) {
              sum += (float)0.0015906370245;
            } else {
              sum += (float)-0.16947388649;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.688180089)) {
              sum += (float)0.53331774473;
            } else {
              sum += (float)0.032133683562;
            }
          }
        }
      }
    } else {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.082987502217)) {
        if (!(data[4].missing != -1) || (data[4].fvalue < (float)-0.81686103344)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.9672087431)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.0676459074)) {
              sum += (float)-0.087322622538;
            } else {
              sum += (float)0.00027607439552;
            }
          } else {
            sum += (float)-0.57554870844;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.90260761976)) {
            sum += (float)-0.34052446485;
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.25952985883)) {
              sum += (float)0.075036622584;
            } else {
              sum += (float)-0.042563319206;
            }
          }
        }
      } else {
        sum += (float)1.4573253393;
      }
    }
  } else {
    if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.25767710805)) {
      if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.48068380356)) {
        if (!(data[2].missing != -1) || (data[2].fvalue < (float)0.40303093195)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.49716258049)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.9717721343)) {
              sum += (float)-0.0024168726522;
            } else {
              sum += (float)-0.044498931617;
            }
          } else {
            sum += (float)-0.56201016903;
          }
        } else {
          sum += (float)-0.12544187903;
        }
      } else {
        sum += (float)0.12391611934;
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.67004954815)) {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.6858407259)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22513249516)) {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.22950825095)) {
              sum += (float)-0.027105359361;
            } else {
              sum += (float)3.4184122086;
            }
          } else {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.92095243931)) {
              sum += (float)0.053471554071;
            } else {
              sum += (float)-0.061103288084;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12016919255)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-0.30030554533)) {
              sum += (float)0.44837802649;
            } else {
              sum += (float)0.13123001158;
            }
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)0.46563410759)) {
              sum += (float)-0.109600164;
            } else {
              sum += (float)0.14963412285;
            }
          }
        }
      } else {
        if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.12613120675)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.91077339649)) {
            if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.24719934165)) {
              sum += (float)-0.07367067039;
            } else {
              sum += (float)-0.35052537918;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.80018484592)) {
              sum += (float)0.076053932309;
            } else {
              sum += (float)-0.021852063015;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-0.11798134446)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)0.0051773507148)) {
              sum += (float)0.50660020113;
            } else {
              sum += (float)-0.010018590838;
            }
          } else {
            if (!(data[6].missing != -1) || (data[6].fvalue < (float)-0.9783551693)) {
              sum += (float)-0.038800351322;
            } else {
              sum += (float)0.00012948410586;
            }
          }
        }
      }
    }
  }
  if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2887790203)) {
    if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.029404900968)) {
      if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.3036470413)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-2.4335923195)) {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.7180831432)) {
            sum += (float)0.49937364459;
          } else {
            sum += (float)0.0048319343477;
          }
        } else {
          if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.1158605963)) {
            if (!(data[2].missing != -1) || (data[2].fvalue < (float)-1.2630730867)) {
              sum += (float)0.023556696251;
            } else {
              sum += (float)-0.026189854369;
            }
          } else {
            sum += (float)0.082171887159;
          }
        }
      } else {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.257076025)) {
          if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.4894822836)) {
            sum += (float)-0.00052510102978;
          } else {
            sum += (float)0.05439504981;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-0.72678053379)) {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730378866)) {
              sum += (float)0.16165915132;
            } else {
              sum += (float)0.44729706645;
            }
          } else {
            if (!(data[1].missing != -1) || (data[1].fvalue < (float)-0.61730378866)) {
              sum += (float)0.13307990134;
            } else {
              sum += (float)-0.0014142268337;
            }
          }
        }
      }
    } else {
      sum += (float)-0.84705042839;
    }
  } else {
    if (!(data[4].missing != -1) || (data[4].fvalue < (float)-2.2739112377)) {
      if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.2444154024)) {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5216221809)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.821044445)) {
            sum += (float)0.0240784958;
          } else {
            sum += (float)0.066346041858;
          }
        } else {
          if (!(data[3].missing != -1) || (data[3].fvalue < (float)0.20643255115)) {
            sum += (float)-0.30566862226;
          } else {
            sum += (float)-0.04601290077;
          }
        }
      } else {
        if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.1520131826)) {
          sum += (float)-0.26014786959;
        } else {
          sum += (float)-0.10863571614;
        }
      }
    } else {
      if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.8643237352)) {
        if (!(data[1].missing != -1) || (data[1].fvalue < (float)-1.8536205292)) {
          if (!(data[6].missing != -1) || (data[6].fvalue < (float)-1.2855455875)) {
            sum += (float)0.04302123934;
          } else {
            if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.4982018471)) {
              sum += (float)-0.0053316750564;
            } else {
              sum += (float)0.01259232033;
            }
          }
        } else {
          if (!(data[7].missing != -1) || (data[7].fvalue < (float)-1.0785127878)) {
            sum += (float)-0.10035888851;
          } else {
            sum += (float)-0.20903019607;
          }
        }
      } else {
        if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.8075928688)) {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.8151959181)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.007383585)) {
              sum += (float)0.041157040745;
            } else {
              sum += (float)-0.30734992027;
            }
          } else {
            sum += (float)1.496260643;
          }
        } else {
          if (!(data[5].missing != -1) || (data[5].fvalue < (float)-1.6034784317)) {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.3488701582)) {
              sum += (float)-0.02937326394;
            } else {
              sum += (float)-0.40835955739;
            }
          } else {
            if (!(data[0].missing != -1) || (data[0].fvalue < (float)-1.5818845034)) {
              sum += (float)-0.1338635087;
            } else {
              sum += (float)0.00021846202435;
            }
          }
        }
      }
    }
  }

  sum = sum + (float)(0.5);
  if (!pred_margin) {
    return pred_transform(sum);
  } else {
    return sum;
  }
}
